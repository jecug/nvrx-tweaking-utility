#pragma once
#include <string>
#include <vector>

namespace nvrx {

enum class Page : int {
    Overview = 0,
    Tweaks,
    Count
};

struct Category {
    Page page;
    const char* name;
    const char* title;
    const char* sub;
    const char* note;
};

struct Group {
    Page page;
    const char* name;
    const char* note;
};

struct Tweak {
    const char* id;
    Page page;
    const char* group;
    const char* title;
    const char* desc;
    bool recommended;
    bool interactive;
};

const std::vector<Category>& categories();
const std::vector<Group>& groups();
const std::vector<Tweak>& tweaks();
const Category* find_category(Page p);

inline const char* page_name(Page p) {
    for (auto& c : categories())
        if (c.page == p) return c.name;
    return "?";
}

}
