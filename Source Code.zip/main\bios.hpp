#pragma once
#include <string>
#include <vector>

namespace nvrx::bios {

const char* script(const char* id);

const std::string& work_dir();

bool loaded();
void reset();

struct Item {
    std::string title;
    std::string detail;
    std::string group;
    bool manual = false;
    bool typed = false;
    std::string current;
    std::string recommended;
    int pick = -1;
    bool changed = false;
    std::vector<std::string> options;
};

int item_count();
const Item* item(int index);
int option_count(int index);
std::string option(int index, int optionIndex);

bool load(const std::string& dumpPath);
void mark_import_sent();

int changed_count();
void recommend_all();
void pick(int index, int optionIndex);

bool write_import();

std::string status_text();

}
