#include "bios.hpp"
#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstring>

#ifdef min
#undef min
#endif

namespace nvrx::bios {
namespace {

const char* S_bios_export = R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - BIOS Export Via SCEWIN
echo [Nvrx] === BIOS Export Via SCEWIN ===
set "BDIR=C:\Nvrx\BIOS"
if not exist "%BDIR%" mkdir "%BDIR%"
set "TOOL=%BDIR%\SCEWIN_64.exe"
if exist "%TOOL%" goto have_tool
echo [Nvrx] Tool missing - downloading jecug Scewin.zip ...
curl -L -A "Nvrx/3.0" -o "%BDIR%\Scewin.zip" "https://www.dropbox.com/scl/fi/cb1542vay6s3gdo87exb1/Scewin.zip?rlkey=qq6e5motmu9mbuh0y7bvx4sl4&st=qeiq7b3l&dl=1"
if errorlevel 1 (
  echo [Nvrx] FAILED: download - check your internet connection and retry.
  exit /b 2
)
echo [Nvrx] Unpacking Scewin.zip ...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$z='%BDIR%\Scewin.zip'; $d='%BDIR%\Scewin'; if (Test-Path $d) { Remove-Item $d -Recurse -Force }; Expand-Archive -Path $z -DestinationPath $d -Force; Remove-Item $z -Force; $exe=(Get-ChildItem -Path $d -Recurse -Filter 'SCEWIN_64.exe' | Select-Object -First 1); if ($exe) { Copy-Item $exe.FullName '%BDIR%' -Force; $sub=Split-Path $exe.FullName; foreach($f in @('amifldrv64.sys','amigendrv64.sys')) { $src=Join-Path $sub $f; if (Test-Path $src) { Copy-Item $src '%BDIR%' -Force } } }"
if not exist "%TOOL%" (
  echo [Nvrx] FAILED: no SCEWIN_64.exe inside the downloaded zip.
  exit /b 3
)
echo [Nvrx] Tool staged in C:\Nvrx\BIOS
:have_tool
echo [Nvrx] Exporting current BIOS settings to nvram.txt ...
"%TOOL%" /O /S "%BDIR%\nvram.txt"
if errorlevel 1 (
  echo [Nvrx] FAILED: export - NVRAM may be locked on this board. Configure it manually in BIOS setup.
  exit /b 4
)
echo [Nvrx] nvram.txt written - reopening the BIOS page loads it.
exit /b 0)NVRXBAT";

const char* S_bios_import = R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - BIOS Import Via SCEWIN
echo [Nvrx] === BIOS Import Via SCEWIN ===
set "BDIR=C:\Nvrx\BIOS"
set "TOOL=%BDIR%\SCEWIN_64.exe"
if not exist "%TOOL%" (
  echo [Nvrx] FAILED: run BIOS Export first so the tool is staged.
  exit /b 1
)
if not exist "%BDIR%\bios_import.txt" (
  echo [Nvrx] FAILED: no import plan - open the BIOS page, pick values, then Import.
  exit /b 2
)
if exist "%BDIR%\nvram.txt" copy /Y "%BDIR%\nvram.txt" "%BDIR%\nvram.txt.bak" >nul 2>&1
echo [Nvrx] Importing picked values into BIOS NVRAM.
echo [Nvrx] To revert: import C:\Nvrx\BIOS\nvram.txt.bak the same way.
"%TOOL%" /I /S "%BDIR%\bios_import.txt"
if errorlevel 1 (
  echo [Nvrx] FAILED: the import was refused by the BIOS.
  exit /b 3
)
echo [Nvrx] Done - the new settings are stored in BIOS NVRAM.
exit /b 0)NVRXBAT";

constexpr const char* kDir = "C:\\Nvrx\\BIOS";

std::string Lower(const std::string& v) {
    std::string o = v;
    for (char& c : o) c = (char)std::tolower((unsigned char)c);
    return o;
}

std::string Trim(const std::string& v) {
    size_t a = 0, b = v.size();
    while (a < b && (v[a] == ' ' || v[a] == '\t')) ++a;
    while (b > a && (v[b - 1] == ' ' || v[b - 1] == '\t')) --b;
    return v.substr(a, b - a);
}

std::string NoComment(const std::string& v) {
    const size_t p = v.find("//");
    return Trim(p == std::string::npos ? v : v.substr(0, p));
}

std::string AfterEq(const std::string& line, const char* key) {
    if (line.compare(0, std::strlen(key), key) != 0) return "";
    const size_t p = line.find('=');
    if (p == std::string::npos) return "";
    return line.substr(p + 1);
}

bool KeyLine(const std::string& line, const char* key) {
    const size_t n = std::strlen(key);
    if (line.compare(0, n, key) != 0) return false;
    size_t p = n;
    while (p < line.size() && (line[p] == ' ' || line[p] == '\t')) ++p;
    return p < line.size() && line[p] == '=';
}

bool CiEq(const std::string& a, const char* b) { return Lower(a) == Lower(b); }
bool CiHas(const std::string& a, const char* b) {
    return Lower(a).find(Lower(b)) != std::string::npos;
}

bool LabelEq(const std::string& a, const char* b) {
    std::string x, y;
    for (char c : a) if (c != '#') x.push_back(c);
    for (const char* p = b; *p; ++p) if (*p != '#') y.push_back(*p);
    return Lower(x) == Lower(y);
}

bool ParseOptionLine(const std::string& line, std::string& label, bool& selected) {
    size_t i = 0;
    while (i < line.size() && (line[i] == ' ' || line[i] == '\t')) ++i;
    selected = false;
    if (i < line.size() && line[i] == '*') {
        selected = true;
        while (++i < line.size() && (line[i] == ' ' || line[i] == '\t')) {}
    }
    if (i >= line.size() || line[i] != '[') return false;
    const size_t close = line.find(']', i);
    if (close == std::string::npos) return false;
    std::string body = line.substr(close + 1);
    const size_t c = body.find("//");
    if (c != std::string::npos) body = body.substr(0, c);
    label = Trim(body);
    return !label.empty();
}

bool DropMarker(std::string& line) {
    size_t start = 0;
    if (KeyLine(line, "Options")) {
        const size_t eq = line.find('=');
        if (eq == std::string::npos) return false;
        start = eq + 1;
    }
    while (start < line.size() && (line[start] == ' ' || line[start] == '\t')) ++start;
    if (start < line.size() && line[start] == '*') {
        line.erase(start, 1);
        return true;
    }
    return false;
}

bool AddMarker(std::string& line) {
    if (KeyLine(line, "Options")) {
        const size_t eq = line.find('=');
        if (eq == std::string::npos) return false;
        line.insert(eq + 1, 1, '*');
        return true;
    }
    const size_t brace = line.find('[');
    if (brace == std::string::npos) return false;
    line.insert(brace, 1, '*');
    return true;
}

struct Entry {
    std::string name;
    std::string orig;
    size_t optionsLine = 0;
    int currentLine = -1;
    int currentIndex = -1;
    std::vector<std::string> labels;
    bool typed = false;
    std::string value;
};

enum MMode {
    M_EQ, M_HAS, M_STARTS, M_ASPM, M_PEP, M_DBG, M_CLKREQ, M_PXE,
    M_NATIVE, M_OBFF, M_PLL, M_D3, M_SATALPM, M_DEVSLEEP, M_XHCIL1,
    M_VMD, M_HOTPLUG, M_SRIOV, M_C1E, M_C610, M_AUTODEMO, M_UNDEMO, M_PKG,
    M_RING, M_SAGV, M_DPTF, M_S0IX, M_SLEEP, M_READY, M_SMART, M_ERP, M_EEE,
    M_DMISS, M_DRAMSS, M_FIVR, M_CPUTH, M_ACPIDBG, M_PTRACE,
    M_COMPUTRACE, M_AMT, M_SGX, M_TME, M_TXT, M_GNA, M_SERIAL, M_TB, M_VTX,
    M_VTD, M_CSM, M_SATA, M_PREFHW, M_ADJCL, M_DCUS, M_DCUIP, M_MLC,
    M_PKGCS, M_MCR, M_MRCFAST, M_EEP, M_MMIO,
    M_WLESS, M_PCIE_LS, M_DMI_LS, M_RINGMODE, M_PLIM, M_XMP, M_BCLKSS,
    M_RGB, M_EXTRAC
};

bool MatchName(int mode, const std::string& name, const char* arg) {
    switch (mode) {
    case M_EQ: return CiEq(name, arg);
    case M_HAS: return CiHas(name, arg);
    case M_STARTS: return name.compare(0, std::strlen(Lower(arg).c_str()), Lower(arg).c_str()) == 0;
    case M_ASPM: {

        if (CiEq(name, "aspm") || CiEq(name, "aspm support")) return true;
        if (name.compare(0, 5, "aspm ") == 0) {
            const std::string rest = Trim(name.substr(5));
            if (rest.empty()) return false;
            for (char c : rest)
                if (!std::isdigit((unsigned char)c)) return false;
            return true;
        }
        return false;
    }
    case M_PEP: return name.compare(0, 3, "pep") == 0;
    case M_DBG: return CiEq(name, "Platform Debug Consent") || CiHas(name, "Intel Enhanced Debug");
    case M_CLKREQ: return name.compare(0, 6, "clkreq") == 0 || CiHas(name, "Clock Power Management");
    case M_PXE: return CiHas(name, "PXE Support") || CiEq(name, "Realtek PXE OPROM");
    case M_NATIVE: return CiEq(name, "Native ASPM") || CiHas(name, "Native Power Management");
    case M_OBFF: return CiEq(name, "OBFF") || CiHas(name, "Optimized Buffer Flush");
    case M_PLL: return CiHas(name, "SSC") && !CiEq(name, "PCIe Spread Spectrum Clocking");
    case M_D3: return CiHas(name, "D3Cold") || CiHas(name, "D3 Cold") || CiHas(name, "RTD3");
    case M_SATALPM: return (CiHas(name, "LPM") && CiHas(name, "SATA")) || CiHas(name, "ALPM")
                            || CiHas(name, "Aggressive LPM") || CiHas(name, "Aggressive Link Power");
    case M_DEVSLEEP: return CiHas(name, "DevSlp") || CiHas(name, "DevSleep") || CiHas(name, "Dev Sleep");
    case M_XHCIL1: return CiHas(name, "xHCI Idle") || CiHas(name, "USB LPM");
    case M_VMD: return CiHas(name, "VMD");
    case M_HOTPLUG: return !CiHas(name, "Display") && !CiHas(name, "HDMI")
                           && !CiHas(name, "HPD")
                           && (CiHas(name, "Hot Plug") || CiHas(name, "Hotplug"));
    case M_SRIOV: return CiHas(name, "SR-IOV") || CiHas(name, "Sriov") || CiHas(name, "SR Iov");
    case M_C1E: return CiHas(name, "C1E") || CiHas(name, "Enhanced C");
    case M_C610: return CiHas(name, "C6/C7") || CiHas(name, "C10 Report")
                        || CiEq(name, "C6 Report") || CiEq(name, "C7 Report") || CiEq(name, "C7s Report");
    case M_AUTODEMO: return !CiHas(name, "Package") && (CiHas(name, "Auto Demotion")
                        || CiHas(name, "Auto-Demotion") || CiHas(name, "Autodemotion"));
    case M_UNDEMO: return !CiHas(name, "Package") && (CiHas(name, "Un-Demotion")
                        || CiHas(name, "Undemotion") || CiHas(name, "Un demotion"));
    case M_PKG: return CiHas(name, "Package") && CiHas(name, "Demotion");
    case M_RING: return CiEq(name, "Ring Down Bin");
    case M_SAGV: return CiHas(name, "SA GV") || CiHas(name, "Geyserville");
    case M_DPTF: return CiHas(name, "DPTF") || CiHas(name, "Dynamic Tuning")
                        || CiHas(name, "Thermal Framework");
    case M_S0IX: return CiHas(name, "Low Power S0") || CiHas(name, "S0ix") || CiHas(name, "Modern Standby");
    case M_SLEEP: return CiEq(name, "ACPI Sleep State") || CiHas(name, "Sensor Standby")
                        || CiHas(name, "EC Low Power");
    case M_READY: return CiHas(name, "Ready Mode");
    case M_SMART: return CiHas(name, "Smart Connect");
    case M_ERP: return CiHas(name, "ErP") || CiHas(name, "Deep Sleep");
    case M_EEE: return CiHas(name, "Energy Efficient Ethernet") || CiEq(name, "EEE")
                        || CiHas(name, "Green Ethernet") || CiHas(name, "Advanced EEE");
    case M_DMISS: return CiHas(name, "DMI Spread Spectrum");
    case M_DRAMSS: return CiHas(name, "DRAM Spread Spectrum") || CiHas(name, "Memory Spread Spectrum");
    case M_FIVR: return CiEq(name, "RFI Spread Spectrum") || CiHas(name, "FIVR Spread Spectrum");
    case M_CPUTH: return CiHas(name, "CPU Trace Hub");
    case M_ACPIDBG: return CiHas(name, "ACPI Debug");
    case M_PTRACE: return (CiHas(name, "Probeless") || CiHas(name, "Memory Trace"))
                        && !CiHas(name, "Processor Trace");
    case M_COMPUTRACE: return CiHas(name, "Computrace") || CiHas(name, "Absolute Persistence");
    case M_AMT: return CiHas(name, "Intel AMT") || CiEq(name, "AMT")
                        || CiHas(name, "AMT Bios") || CiHas(name, "AMT Support")
                        || CiHas(name, "Provisioning of AMT");
    case M_SGX: return CiHas(name, "SGX") || CiHas(name, "Software Guard Extensions");
    case M_TME: return CiHas(name, "Total Memory Encryption") || CiEq(name, "TME") || CiHas(name, "Intel TME");
    case M_TXT: return CiEq(name, "TXT") || CiHas(name, "Intel TXT")
                        || CiHas(name, "TXT Support") || CiHas(name, "Trusted Execution");
    case M_GNA: return CiHas(name, "GNA");
    case M_SERIAL: return CiHas(name, "Serial Port") || CiHas(name, "Parallel Port")
                        || CiEq(name, "LPT Port") || CiHas(name, "COM Port");
    case M_TB: return CiHas(name, "Thunderbolt");
    case M_VTX: return CiHas(name, "VT-x") || CiHas(name, "VMX")
                        || CiEq(name, "Intel Virtualization Technology");
    case M_VTD: return CiHas(name, "VT-d") || CiHas(name, "Directed I/O") || CiHas(name, "DMA Remapping");
    case M_CSM: return CiEq(name, "CSM Support") || CiEq(name, "Launch CSM")
                        || CiHas(name, "Compatibility Support Module");
    case M_SATA: return CiEq(name, "SATA Mode") || CiEq(name, "SATA Mode Selection");
    case M_PREFHW: return CiHas(name, "Hardware Prefetcher");
    case M_ADJCL: return CiHas(name, "Adjacent Cache");
    case M_DCUS: return CiHas(name, "DCU Streamer");
    case M_DCUIP: return CiHas(name, "DCU IP") || CiEq(name, "DCU Prefetcher");
    case M_MLC: return CiHas(name, "MLC Streamer") || CiHas(name, "MLC Spatial") || CiHas(name, "MLC Prefetcher");
    case M_PKGCS: return CiHas(name, "Package C-State Limit") || CiEq(name, "Package C State Limit");
    case M_MCR: return CiHas(name, "Memory Context Restore");
    case M_MRCFAST: return CiHas(name, "MRC Fast Boot") || CiEq(name, "Fast Boot");
    case M_EEP: return CiEq(name, "Energy Efficient P-state") || CiEq(name, "Energy Efficient Turbo");
    case M_MMIO: return CiHas(name, "Above 4GB") || CiHas(name, "Above 4G MMIO");
    case M_WLESS: return CiEq(name, "Bluetooth") || CiEq(name, "Discrete Bluetooth Module")
                        || CiEq(name, "Connectivity mode (Wi-Fi & Bluetooth)");
    case M_PCIE_LS: return (CiHas(name, "Link Speed") && (CiHas(name, "PCIEX") || CiHas(name, "M.2")
                        || CiHas(name, "PEG"))) || CiEq(name, "Max Link Speed") || CiEq(name, "Target Link Speed");
    case M_DMI_LS: return CiHas(name, "DMI") && CiHas(name, "Link Speed");
    case M_RINGMODE: return CiHas(name, "Ring Ratio") || CiHas(name, "Cache Ratio")
                        || CiEq(name, "Ring Max OC Ratio");
    case M_PLIM: return CiEq(name, "Platform PL1 Enable") || CiEq(name, "Platform PL1 Power")
                        || CiEq(name, "Platform PL2 Enable") || CiEq(name, "Platform PL2 Power")
                        || CiEq(name, "Power Limit 1 Override") || CiEq(name, "Power Limit 2 Override");
    case M_XMP: return CiEq(name, "XMP") || CiEq(name, "Memory profile")
                        || CiHas(name, "Extreme Memory Profile") || CiEq(name, "EXPO");
    case M_BCLKSS: return CiEq(name, "Spread %") || (CiHas(name, "BCLK") && CiHas(name, "Spread"));
    case M_RGB: return CiEq(name, "RGB-Strip Lighting Control") || CiEq(name, "Q-LED Core");
    case M_EXTRAC: return CiEq(name, "eMMC 5.0 Controller") || CiEq(name, "SDCard 3.0 Controller")
                        || CiEq(name, "UFS 2.0 Controller");
    }
    return false;
}

struct Rule {
    const char* title;
    const char* detail;
    int mode;
    const char* arg;
    const char* want[2];
    bool manualAdvice;
    const char* group;
};

const Rule* Rules(size_t* count) {
    static const Rule all[] = {
        { "PEG ASPM", "ASPM on the PEG port off - this knob covers L0s, L1 and L0sL1 states.", M_EQ, "PEG - ASPM", { "Disabled", "Auto" }, false, "Disable" },
        { "PCH ASPM", "ASPM L0s / L1 on the PCH ports off for lower latency.", M_ASPM, "", { "Disabled", "" }, false, "Disable" },
        { "DMI ASPM", "ASPM on the CPU-PCH DMI link - off for lower latency.", M_EQ, "DMI Link ASPM Control", { "Disabled", "" }, false, "Disable" },
        { "Native ASPM / PCI Express Native Power Management", "No OS-controlled ASPM; the BIOS sets it instead.", M_NATIVE, "", { "Disabled", "" }, true, "Disable" },
        { "L1 Substates (L1.1, L1.2)", "PCIe L1.1 / L1.2 power saving off for lower latency.", M_EQ, "L1 Substates", { "Disabled", "" }, false, "Disable" },
        { "CLKREQ# / Clock Power Management", "Keeps PCIe clocks always-on instead of a CLKREQ handshake.", M_CLKREQ, "", { "Disabled", "" }, false, "Disable" },
        { "PCI Express Clock Gating", "Clock gating for power off; PCIe clocks stay active.", M_EQ, "PCI Express Clock Gating", { "Disabled", "" }, false, "Disable" },
        { "Optimized Buffer Flush/Fill (OBFF)", "PCIe in-band power management messages off.", M_OBFF, "", { "Disabled", "" }, false, "Disable" },
        { "Power Down Unused Lanes", "Unused PCIe lanes stay powered for faster link rises.", M_EQ, "Power Down Unused Lanes", { "Disabled", "Auto" }, false, "Disable" },
        { "PCIe Spread Spectrum Clocking", "Spread spectrum clocking on PCIe off for a clean signal.", M_EQ, "PCIe Spread Spectrum Clocking", { "Disabled", "" }, false, "Disable" },
        { "PCIe PLL SSC (set 0.0%)", "PLL spread set to 0.0% for a clean PCIe reference clock.", M_PLL, "", { "0.0%", "Disabled" }, true, "Disable" },
        { "ACPI D3Cold Support (RTD3)", "PCIe d3cold power gating off for instant device wake.", M_D3, "", { "Disabled", "" }, true, "Disable" },
        { "SATA Aggressive LPM / ALPM", "SATA link power management off for instant disk access.", M_SATALPM, "", { "Disabled", "" }, true, "Disable" },
        { "SATA DevSleep", "SATA device sleep state off; drives stay ready.", M_DEVSLEEP, "", { "Disabled", "" }, true, "Disable" },
        { "xHCI Idle L1", "USB link idle power state off for lower USB latency.", M_XHCIL1, "", { "Disabled", "" }, true, "Disable" },
        { "VMD (Volume Management Device)", "Intel VMD storage layer off; SATA controllers stay native.", M_VMD, "", { "Disabled", "" }, true, "Disable" },
        { "Hot Plug on unused slots", "Hot plug detection on free slots off for lower link latency.", M_HOTPLUG, "", { "Disabled", "" }, true, "Disable" },
        { "SR-IOV (if no virtualization)", "PCIe single-root I/O virtualization off when you run no VMs.", M_SRIOV, "", { "Disabled", "" }, true, "Disable" },
        { "C1E / Enhanced C-states", "C1E halt state off; cores stay in C0 for instant wake.", M_C1E, "", { "Disabled", "" }, true, "Disable" },
        { "CPU C6 / C7 / C10 Report (deeper than C1)", "Deep core C-state reporting off; keep cores above C1.", M_C610, "", { "Disabled", "" }, true, "Disable" },
        { "C-State Auto Demotion", "Cores never slide down into deeper C-states.", M_AUTODEMO, "", { "Disabled", "" }, true, "Disable" },
        { "C-State Un-demotion", "No walk back up from deeper C-states; plain wake paths only.", M_UNDEMO, "", { "Disabled", "" }, true, "Disable" },
        { "Package C-State Demotion / Un-demotion", "Package-level C-state demotion and un-demotion off.", M_PKG, "", { "Disabled", "" }, true, "Disable" },
        { "Ring Down Bin", "Ring downbin power crouch off for stable uncore latency.", M_RING, "", { "Disabled", "" }, true, "Disable" },
        { "SA GV (Disabled or Fixed High)", "System agent Geyserville off or fixed high; no voltage swings.", M_SAGV, "", { "Fixed High", "Disabled" }, true, "Disable" },
        { "Intel Dynamic Tuning / DPTF", "Dynamic platform thermal framework off; no OS power clips.", M_DPTF, "", { "Disabled", "" }, true, "Disable" },
        { "Modern Standby / Low Power S0 Idle Capability", "S0 low power idle off; no driver-level power dips.", M_S0IX, "", { "Disabled", "" }, true, "Disable" },
        { "PEP - Power Engine Plugin / Platform Extension Plug-ins", "Windows power engine plugin off for lower latency.", M_PEP, "", { "Disabled", "" }, false, "Disable" },
        { "Sleep/Standby (Sensor Standby, EC Low Power Mode)", "Sleep and standby states off; sensor and EC idle modes too.", M_SLEEP, "", { "Suspend Disabled", "" }, true, "Disable" },
        { "Intel Ready Mode", "Ready Mode idle tech off; cores stay responsive.", M_READY, "", { "Disabled", "" }, true, "Disable" },
        { "Smart Connect", "Smart Connect background updates off.", M_SMART, "", { "Disabled", "" }, true, "Disable" },
        { "ErP / Deep Sleep", "ErP deep-sleep power off; standard power states stay.", M_ERP, "", { "Disabled", "" }, true, "Disable" },
        { "Energy Efficient Ethernet (EEE)", "EEE link power down on the LAN chip off; not on every board.", M_EEE, "", { "Disabled", "" }, true, "Disable" },
        { "Energy Efficient P-state / Turbo", "Intel energy-efficient P-state and Turbo off for fixed clocks.", M_EEP, "", { "Disabled", "" }, true, "Disable" },
        { "BCLK / CPU Spread Spectrum (0% = Off)", "Set the spread to 0 or Disabled; non-zero spread perturbs the CPU base clock.", M_BCLKSS, "", { "", "" }, true, "Disable" },
        { "DMI Spread Spectrum", "Spread on the DMI link clock off for a clean signal.", M_DMISS, "", { "Disabled", "" }, true, "Disable" },
        { "DRAM Spread Spectrum", "Spread on the memory clock off for stable RAM timing.", M_DRAMSS, "", { "Disabled", "" }, true, "Disable" },
        { "FIVR Spread Spectrum", "Clock spread on the CPU FIVR rail as low as possible.", M_FIVR, "", { "Disabled", "0.5%" }, false, "Disable" },
        { "Debug Interface", "Intel DCI / Enhanced Debug access off.", M_DBG, "", { "Disabled", "" }, false, "Disable" },
        { "PMC Debug Message Enable", "PMC firmware debug traffic off for lower latency.", M_EQ, "PMC Debug Message Enable", { "Disabled", "" }, false, "Disable" },
        { "PCH Trace Hub Enable Mode", "Trace hub debug endpoint off for lower latency.", M_EQ, "PCH Trace Hub Enable Mode", { "Disabled", "" }, false, "Disable" },
        { "CPU Trace Hub", "CPU-side trace hub debug endpoint off.", M_CPUTH, "", { "Disabled", "" }, true, "Disable" },
        { "Processor Trace", "CPU tracing memory allocation disabled.", M_HAS, "Processor trace", { "Disabled", "" }, false, "Disable" },
        { "ACPI Debug", "ACPI debug output off for less overhead.", M_ACPIDBG, "", { "Disabled", "" }, true, "Disable" },
        { "Probeless Trace / Memory Trace", "Probeless and memory tracing endpoints off.", M_PTRACE, "", { "Disabled", "" }, true, "Disable" },
        { "Launch PXE OpROM policy", "Network boot ROMs at POST off for faster boot.", M_PXE, "", { "Disabled", "" }, false, "Disable" },
        { "Computrace", "Computrace anti-theft agent off.", M_COMPUTRACE, "", { "Disabled", "" }, true, "Disable" },
        { "Intel AMT", "Active management technology off; no ME power states.", M_AMT, "", { "Disabled", "" }, true, "Disable" },
        { "Intel SGX", "Software guard extensions off to free core features.", M_SGX, "", { "Disabled", "" }, true, "Disable" },
        { "Intel TME", "Total memory encryption off; lower memory latency.", M_TME, "", { "Disabled", "" }, true, "Disable" },
        { "Intel TXT", "Trusted execution technology off for a plain boot path.", M_TXT, "", { "Disabled", "" }, true, "Disable" },
        { "Intel GNA", "Neural accelerate engine off; no background work.", M_GNA, "", { "Disabled", "" }, true, "Disable" },

        { "Wi-Fi / Bluetooth controller", "Disable the onboard Wi-Fi and Bluetooth module if you go ethernet only.", M_WLESS, "", { "Disabled", "" }, true, "Disable Only If Unused" },
        { "Thunderbolt", "No on/off entry for the controller on this board; TBT RTD3 entries in the D3Cold row gate its power.", M_TB, "", { "Disabled", "" }, true, "Disable Only If Unused" },
        { "Serial / parallel ports", "Legacy COM and LPT ports off when you do not use them.", M_SERIAL, "", { "Disabled", "" }, true, "Disable Only If Unused" },
        { "Extra USB / SATA controllers", "Disable the extra SCS controllers (eMMC, SDCard, UFS) you never use.", M_EXTRAC, "", { "Disabled", "" }, true, "Disable Only If Unused" },
        { "Onboard RGB controller", "Turn off the RGB strip lighting and Q-LED POST indicator if you don't use them.", M_RGB, "", { "Off", "" }, true, "Disable Only If Unused" },
        { "Intel VT-x", "Only if no VMs, WSL or Memory Integrity - otherwise keep it on.", M_VTX, "", { "Disabled", "" }, true, "Disable Only If Unused" },
        { "Intel VT-d (only if no VMs, WSL, Memory Integrity)", "Directed I/O remapping off is only for plain systems with no VM use.", M_VTD, "", { "Disabled", "" }, true, "Disable Only If Unused" },

        { "Hardware Prefetcher", "CPU hardware prefetcher on for memory bandwidth.", M_PREFHW, "", { "Enabled", "" }, false, "Enable" },
        { "Adjacent Cache Line Prefetch", "Fetches the paired cache line; keep on for locality.", M_ADJCL, "", { "Enabled", "" }, false, "Enable" },
        { "DCU Streamer Prefetcher", "L1 data cache streamer prefetch on.", M_DCUS, "", { "Enabled", "" }, true, "Enable" },
        { "DCU IP Prefetcher", "L1 instruction-pointer-based prefetch on.", M_DCUIP, "", { "Enabled", "" }, true, "Enable" },
        { "MLC Streamer / Spatial Prefetcher", "Mid-level cache prefetchers on for throughput.", M_MLC, "", { "Enabled", "" }, true, "Enable" },
        { "Corrector Branch Predictor", "Branch predictor correction on for stable performance.", M_HAS, "Branch", { "Enabled", "" }, true, "Enable" },
        { "Above 4G Decoding", "64-bit PCIe device decode above 4G; prep for ReBAR.", M_EQ, "Above 4G Decoding", { "Enabled", "" }, false, "Enable" },
        { "Above 4G MMIO Limit (Auto)", "MMIO limit above 4G; usually locked to the second Above-4G entry.", M_MMIO, "", { "Auto", "" }, true, "Enable" },
        { "Re-Size BAR Support (Enabled / Auto)", "ReBAR for modern GPUs; Auto lets it engage.", M_EQ, "Re-Size BAR Support", { "Auto", "Enabled" }, false, "Enable" },
        { "PCIe Ten Bit Tag Support", "Extended tag values for high-throughput PCIe.", M_HAS, "Ten bit", { "Enabled", "" }, true, "Enable" },
        { "SATA Mode = AHCI", "AHCI mode for a clean standard SATA controller.", M_SATA, "", { "AHCI", "" }, true, "Enable" },
        { "CSM = Disabled (needed for Above 4G / ReBAR)", "Legacy boot off; required for Above 4G and ReBAR.", M_CSM, "", { "Disabled", "" }, true, "Enable" },

        { "Package C-State Limit = C0/C1", "Package C-state ceiling at C0 or C1; no deep package idle.", M_PKGCS, "", { "C0/C1", "C1" }, true, "Set" },
        { "PCIe Link Speed (Auto)", "Auto negotiates the max Gen each device supports - never pin a lower Gen.", M_PCIE_LS, "", { "Auto", "" }, true, "Set" },
        { "DMI Max Link Speed (Auto)", "Auto keeps the CPU-PCH link at the platform ceiling; never pin below.", M_DMI_LS, "", { "Auto", "" }, true, "Set" },
        { "Ring / Cache Ratio (Auto on locked CPUs)", "Max stable ratio only on unlocked CPUs; locked chips stay on Auto.", M_RINGMODE, "", { "", "" }, true, "Set" },
        { "PL1 / PL2 Power Limits", "Enable Override and type your watts in BIOS; raise step by step, watch temps.", M_PLIM, "", { "", "" }, true, "Set" },
        { "13th/14th gen Intel: microcode 0x12B or newer", "Adaptive or Lite Load, medium LLC, never a hard Vcore.", M_HAS, "zzz-nomatch", { "", "" }, true, "Set" },

        { "XMP / EXPO Memory Profile", "Pick the profile that matches your RAM kit; skip on boards with locked memory.", M_XMP, "", { "Profile #1", "" }, true, "Memory" },
        { "Gear mode = Gear 1 if it is stable", "No Gear entry on this board; check the DRAM clock gear on newer platforms.", M_HAS, "zzz-nomatch", { "", "" }, true, "Memory" },
        { "Memory Context Restore = Disabled while tuning", "Off while you tune memory for clean retraining each boot.", M_MCR, "", { "Disabled", "" }, true, "Memory" },
        { "MRC Fast Boot / Fast Boot = Disabled while tuning", "Off while tuning so every boot retrains memory the same way.", M_MRCFAST, "", { "Disabled", "" }, true, "Memory" },
    };
    *count = sizeof(all) / sizeof(all[0]);
    return all;
}

struct Row {
    std::string title;
    std::string detail;
    std::string group;
    bool manual = false;
    bool typed = false;
    std::vector<int> entries;
    std::vector<std::string> labels;
    int currentIndex = -1;
    int wantIndex = -1;
    int pickIndex = -1;
};

bool g_ready = false;
bool g_importSent = false;
std::vector<std::string> g_raw;
std::vector<Entry> g_entries;
std::vector<Row> g_rows;

void BuildRows() {
    g_rows.clear();
    size_t ruleCount = 0;
    const Rule* rules = Rules(&ruleCount);
    for (size_t r = 0; r < ruleCount; ++r) {
        const Rule& rule = rules[r];
        Row row;
        row.title = rule.title;
        row.group = rule.group ? rule.group : "";

        std::string mapped;
        for (size_t e = 0; e < g_entries.size(); ++e) {
            const Entry& en = g_entries[e];
            if (!MatchName(rule.mode, en.name, rule.arg)) continue;
            row.entries.push_back((int)e);
            if (!mapped.empty()) mapped += ", ";
            mapped += en.orig;
        }

        for (int e : row.entries) {
            for (const std::string& lb : g_entries[(size_t)e].labels) {
                if (std::none_of(row.labels.begin(), row.labels.end(),
                                 [&](const std::string& x) { return x == lb; }))
                    row.labels.push_back(lb);
            }
        }

        for (int e : row.entries) {
            const Entry& en = g_entries[(size_t)e];
            if (en.currentIndex < 0) continue;
            const std::string& cur = en.labels[(size_t)en.currentIndex];
            for (size_t li = 0; li < row.labels.size(); ++li) {
                if (!row.labels[li].compare(cur)) { row.currentIndex = (int)li; break; }
            }
            break;
        }

        for (const char* w : rule.want) {
            if (!w || !*w) continue;
            for (size_t li = 0; li < row.labels.size(); ++li) {
                if (LabelEq(row.labels[li], w)) row.wantIndex = (int)li;
            }
            if (row.wantIndex >= 0) break;
        }

        if (row.entries.empty()) {
            if (!rule.manualAdvice) continue;
            row.manual = true;
        }

        row.typed = !row.entries.empty() && row.labels.empty();
        if (row.typed) row.manual = false;

        row.detail = rule.detail;
        if (!mapped.empty()) {
            if (row.entries.size() > 1)
                row.detail += std::string(" / Board: ") + mapped + " (+" +
                              std::to_string(row.entries.size() - 1) + " More)";
            else
                row.detail += std::string(" / Board: ") + mapped;
        }

        g_rows.push_back(std::move(row));
    }
}

const Row* RowAt(int index) {
    if (index < 0 || index >= (int)g_rows.size()) return nullptr;
    return &g_rows[(size_t)index];
}

bool FileExists(const char* path) {
    std::FILE* f = nullptr;
    const bool ok = fopen_s(&f, path, "rb") == 0 && f;
    if (f) fclose(f);
    return ok;
}

bool ReadFile(const char* path, std::string& data) {
    std::FILE* f = nullptr;
    if (fopen_s(&f, path, "rb") != 0 || !f) return false;
    data.clear();
    char buf[65536];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), f)) > 0) data.append(buf, n);
    fclose(f);
    return true;
}

bool WriteFile(const char* path, const std::string& data) {
    std::FILE* f = nullptr;
    if (fopen_s(&f, path, "wb") != 0 || !f) return false;
    fwrite(data.data(), 1, data.size(), f);
    fclose(f);
    return true;
}

}

const char* script(const char* id) {
    if (!id || !*id) return nullptr;
    if (std::strcmp(id, "bios_export") == 0) return S_bios_export;
    if (std::strcmp(id, "bios_import") == 0) return S_bios_import;
    return nullptr;
}

const std::string& work_dir() {
    static const std::string dir = kDir;
    return dir;
}

bool loaded() { return g_ready; }

void reset() {
    g_ready = false;
    g_importSent = false;
    g_raw.clear();
    g_entries.clear();
    g_rows.clear();
}

void mark_import_sent() { g_importSent = true; }

bool load(const std::string& dumpPath) {
    reset();
    std::string data;
    if (!ReadFile(dumpPath.c_str(), data)) return false;
    if (data.size() >= 3 && (unsigned char)data[0] == 0xEF && (unsigned char)data[1] == 0xBB
        && (unsigned char)data[2] == 0xBF)
        data.erase(0, 3);
    if (data.find("Setup Question") == std::string::npos) return false;

    size_t a = 0;
    while (a < data.size()) {
        size_t b = data.find('\n', a);
        const size_t end = (b == std::string::npos) ? data.size() : b;
        const size_t len = (end > a && data[end - 1] == '\r') ? end - a - 1 : end - a;
        g_raw.push_back(data.substr(a, len));
        if (b == std::string::npos) break;
        a = b + 1;
    }

    for (size_t i = 0; i < g_raw.size(); ++i) {
        const std::string& line = g_raw[i];
        if (!KeyLine(line, "Setup Question")) continue;

        Entry en;
        en.orig = Trim(AfterEq(line, "Setup Question"));
        en.name = Lower(en.orig);
        if (en.orig.empty()) continue;

        for (size_t j = i + 1; j < g_raw.size(); ++j) {
            const std::string& l2 = g_raw[j];
            if (KeyLine(l2, "Setup Question")) break;
            if (KeyLine(l2, "Value")) {
                en.value = Trim(AfterEq(l2, "Value"));
                if (en.value.size() > 1 && en.value.front() == '"' && en.value.back() == '"')
                    en.value = en.value.substr(1, en.value.size() - 2);
                break;
            }

            if (KeyLine(l2, "Options")) {

                en.optionsLine = j;
                bool sel = false;
                std::string label;
                if (ParseOptionLine(AfterEq(l2, "Options"), label, sel)) {
                    en.labels.push_back(label);
                    if (sel) { en.currentLine = (int)j; en.currentIndex = 0; }
                }
                int ordinal = 1;
                for (size_t k = j + 1; k < g_raw.size(); ++k) {
                    const std::string& l3 = g_raw[k];
                    if (KeyLine(l3, "Setup Question")) break;
                    if (l3.empty() || (l3[0] != ' ' && l3[0] != '\t')) break;
                    bool sel2 = false;
                    if (!ParseOptionLine(l3, label, sel2)) break;
                    en.labels.push_back(label);
                    if (sel2) { en.currentLine = (int)k; en.currentIndex = ordinal; }
                    ++ordinal;
                }
                break;
            }
            if (l2.empty() || l2[0] == '[') break; 
        }

        en.typed = en.labels.empty() && !en.value.empty();
        if (!en.labels.empty() || en.typed) g_entries.push_back(std::move(en));
    }

    BuildRows();
    g_ready = !g_rows.empty();
    return g_ready;
}

int item_count() { return (int)g_rows.size(); }

const Item* item(int index) {
    static Item snap;
    const Row* r = RowAt(index);
    if (!r) return nullptr;
    snap.title = r->title;
    snap.detail = r->detail;
    snap.group = r->group;
    snap.manual = r->manual;
    snap.typed = r->typed;
    snap.pick = r->pickIndex;
    snap.changed = !r->manual && !r->typed && r->pickIndex >= 0 && r->pickIndex != r->currentIndex;
    snap.current.clear();
    if (r->currentIndex >= 0 && r->currentIndex < (int)r->labels.size())
        snap.current = r->labels[(size_t)r->currentIndex];
    else if (r->typed && !r->entries.empty())
        snap.current = g_entries[(size_t)r->entries.front()].value;
    snap.recommended.clear();
    if (r->wantIndex >= 0 && r->wantIndex < (int)r->labels.size())
        snap.recommended = r->labels[(size_t)r->wantIndex];
    snap.options = r->labels;
    return &snap;
}

int option_count(int index) {
    const Row* r = RowAt(index);
    return r ? (int)r->labels.size() : 0;
}

std::string option(int index, int optionIndex) {
    const Row* r = RowAt(index);
    if (!r || optionIndex < 0 || optionIndex >= (int)r->labels.size()) return {};
    return r->labels[(size_t)optionIndex];
}

int changed_count() {
    int n = 0;
    for (const Row& r : g_rows)
        if (!r.manual && r.pickIndex >= 0 && r.pickIndex != r.currentIndex &&
            r.currentIndex >= 0) ++n;
    return n;
}

void recommend_all() {
    for (Row& r : g_rows) {
        if (r.manual || r.wantIndex < 0) continue;
        r.pickIndex = r.wantIndex;
    }
}

void pick(int index, int optionIndex) {
    if (index < 0 || index >= (int)g_rows.size()) return;
    Row& r = g_rows[(size_t)index];
    const int n = (int)r.labels.size();
    r.pickIndex = (optionIndex >= 0 && optionIndex < n) ? optionIndex : -1;
}

bool write_import() {
    if (!g_ready || g_rows.empty()) return false;

    bool any = false;
    for (const Row& r : g_rows) {
        if (r.manual || r.pickIndex < 0 || r.currentIndex < 0) continue;
        if (r.pickIndex != r.currentIndex) { any = true; break; }
    }
    if (!any) return false;

    std::string bytes;
    if (!ReadFile((std::string(kDir) + "\\nvram.txt").c_str(), bytes)) return false;
    if (!WriteFile((std::string(kDir) + "\\nvram.txt.bak").c_str(), bytes)) return false;

    std::vector<std::string> out = g_raw;
    int flips = 0;
    for (size_t ri = 0; ri < g_rows.size(); ++ri) {
        const Row& r = g_rows[ri];
        if (r.manual || r.pickIndex < 0 || r.pickIndex == r.currentIndex ||
            r.currentIndex < 0)
            continue;
        const std::string wantLabel = Lower(r.labels[(size_t)r.pickIndex]);
        for (int e : r.entries) {
            const Entry& en = g_entries[(size_t)e];
            const bool currentForEntry =
                en.currentIndex >= 0 &&
                CiEq(en.labels[(size_t)en.currentIndex],
                     Lower(r.labels[(size_t)r.pickIndex]).c_str());
            if (currentForEntry) continue;
            if (en.currentLine < 0) continue;

            size_t toLine = (size_t)-1;
            const size_t endScan = std::min(out.size(), en.optionsLine + en.labels.size() + 2);
            for (size_t k = en.optionsLine; k < endScan && toLine == (size_t)-1; ++k) {
                const std::string& l = out[k];
                if (KeyLine(l, "Setup Question")) break;
                const std::string target = (k == en.optionsLine && KeyLine(l, "Options"))
                                               ? AfterEq(l, "Options")
                                               : ((l.size() && (l[0] == ' ' || l[0] == '\t')) ? l : std::string());
                if (target.empty()) continue;
                std::string label;
                bool sel = false;
                if (!ParseOptionLine(target, label, sel)) continue;
                if (Lower(label) == wantLabel) toLine = k;
            }
            if (toLine == (size_t)-1) continue;

            std::string& from = out[(size_t)en.currentLine];
            if (!DropMarker(from) && en.currentLine != (int)toLine) continue;
            if (AddMarker(out[toLine])) ++flips;
        }
    }
    if (!flips) return false;

    std::string plan;
    for (const std::string& l : out) {
        plan += l;
        plan += "\r\n";
    }
    return WriteFile((std::string(kDir) + "\\bios_import.txt").c_str(), plan);
}

std::string status_text() {
    if (g_importSent) return "Import Done - BIOS Values Written";
    if (g_ready) {
        const int ch = changed_count();
        if (ch > 0) {
            char buf[80];
            snprintf(buf, sizeof(buf), "Loaded - %d Changed - Press Import Via SCEWIN", ch);
            return buf;
        }
        return "Loaded - Pick Values Or Press Recommended";
    }
    if (!FileExists((std::string(kDir) + "\\SCEWIN_64.exe").c_str()))
        return "Tool Missing - Run Download & Export";
    return "Tool Ready - Export Current BIOS Settings";
}

}
