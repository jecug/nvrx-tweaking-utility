using System.Collections.ObjectModel;
using System.Windows.Controls;
using NvrxPCTweakingUtility.Models;
using NvrxPCTweakingUtility.Services;

namespace NvrxPCTweakingUtility.Views;

public partial class CpuView : UserControl
{
    public ObservableCollection<TweakItem> TweakItems { get; } = new()
    {
        TweakFactory.Ready("Import Nvrx Power Plan",
            "Downloads and activates the Nvrx Ultimate Power Plan V2.1. This sets tuned power/performance settings for low latency and consistent CPU behaviour.",
            CmdService.Script("""
                mkdir "C:\Nvrx\Power Plan\"
                curl -g -L -# -o "C:\Nvrx\Power Plan\Nvrx Ultimate Power Plan V2.1.pow" "https://www.dropbox.com/scl/fi/9rekkoww3ym9d9gyruv1m/Nvrx-Ultimate-Power-Plan-V2.1.pow?rlkey=wlxqzjcyrlx62ds3ojbduvnls&st=0v8127et&dl=1"
                powercfg -import "C:\Nvrx\Power Plan\Nvrx Ultimate Power Plan V2.1.pow" 99771111-4b7f-1111-8888-771177884b7f >> "%LOG_PATH%" 2>&1
                powercfg -setactive 99771111-4b7f-1111-8888-771177884b7f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Enabling Package Idle State",
            "Allows CPU cores and the whole processor package to properly enter low-power idle states when not under load, reducing idle power draw and heat.",
            CmdService.Script("""
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Throttle" /v "PerfEnablePackageIdle" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Enabling Interrupt Steering",
            "Enables kernel interrupt steering so hardware interrupts can be spread across CPU cores, improving multi-core responsiveness and reducing single-core bottlenecks.",
            CmdService.Script("""
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" /v "InterruptSteeringFlags" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Disabling Inbox PEP Generated Constraints",
            "Disables the built-in power engine plugin from imposing its own power and latency constraints, letting the power plan control CPU power behaviour instead.",
            CmdService.Script("""
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v "DisableInboxPepGeneratedConstraints" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Disable Idle Scan Interval",
            "Stops the kernel from periodically scanning for idle CPU cores, reducing background timer activity and keeping responses more consistent.",
            CmdService.Script("""
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Power" /v "IdleScanInterval" /t REG_DWORD /d 0 /f
                """)),

        TweakFactory.Ready("Enabling Serialize Timer Expiration",
            "Serializes timer expiry so CPU timers fire in a more stable, predictable order. Can reduce jitter but slightly lower timer-request throughput.",
            CmdService.Script("""
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" /v "SerializeTimerExpiration" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Enabling Per-CPU Clock Tick Scheduling",
            "Lets the system schedule clock ticks separately for each CPU core instead of on a single shared tick, reducing timer latency on multicore systems.",
            CmdService.Script("""
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Kernel" /v "EnablePerCpuClockTickScheduling" /t REG_DWORD /d "2" /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Disabling Timer Check Flags",
            "Disables timer sanity/check flags in the kernel, which can reduce a small amount of per-tick overhead at the cost of some defensive checking.",
            CmdService.Script("""
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Kernel" /v "TimerCheckFlags" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Enable Actual Utilization Calculation",
            "Makes the power manager base CPU frequency/voltage decisions on measured real-time utilization rather than estimates, improving responsiveness under load.",
            CmdService.Script("""
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v "PerfCalculateActualUtilization" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Enable and Optimize MMCSS Service",
            "Starts the Multimedia Class Scheduler and gives audio, Pro Audio and playback tasks high scheduling priority with reduced network throttling, lowering audio latency and stutter.",
            CmdService.Script("""
                reg add "HKLM\SYSTEM\CurrentControlSet\Services\MMCSS" /v "Start" /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "NoLazyMode" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "NetworkThrottlingIndex" /t REG_DWORD /d 10 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "LazyModeTimeout" /t REG_DWORD /d 4294967295 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "SchedulerPeriod" /t REG_DWORD /d 1000000 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "IdleDetectionCycles" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "SchedulerTimerResolution" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Audio" /v "Priority" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Audio" /v "Scheduling Category" /t REG_SZ /d "High" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Audio" /v "Priority When Yielded" /t REG_DWORD /d 19 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Pro Audio" /v "Priority" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Pro Audio" /v "Scheduling Category" /t REG_SZ /d "High" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Pro Audio" /v "Priority When Yielded" /t REG_DWORD /d 19 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Playback" /v "Priority" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Playback" /v "Scheduling Category" /t REG_SZ /d "High" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Playback" /v "Priority When Yielded" /t REG_DWORD /d 19 /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Set Win32PrioritySeparation to 0x18",
            "Tells Windows to give the foreground/active application a short, variable time-slice priority boost, which can improve in-game smoothness.",
            CmdService.Script("""
                reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\PriorityControl" /v Win32PrioritySeparation /t REG_DWORD /d 0x18 /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Disable Coalescing Timer Interval",
            "Stops Windows from merging (coalescing) nearby timer callbacks into one, so timers fire closer to their true interval for more precise, consistent timing.",
            CmdService.Script("""
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v "CoalescingTimerInterval" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Disable Coalescing Flush Interval",
            "Prevents Windows from delaying the flushing of coalesced timers, giving timers a more immediate and accurate wake-up.",
            CmdService.Script("""
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v CoalescingFlushInterval /t REG_DWORD /d 0 /f >nul 2>&1
                """)),

        TweakFactory.Ready("Disable Hibernation",
            "Turns off hibernation and fast startup. Frees up disk space reserved for the hibernation file and avoids sleep-state quirks; you will lose the hibernate option.",
            CmdService.Script("""
                powercfg /h off
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v "HibernateChecksummingEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v "SkipHibernateMemoryMapValidation" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v "AllowHibernate" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v "HibernateEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v "HiberbootEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v "HibernateEnabledDefault" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power\ForceHibernateDisabled" /v "Policy" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Disable Screensaver",
            "Turns off the screensaver and its inactivity timer so the screen never blanks into a screensaver.",
            CmdService.Script("""
                reg add "HKCU\Control Panel\Desktop" /v "ScreenSaveActive" /t REG_SZ /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\Desktop" /v "SCRNSAVE.EXE" /t REG_SZ /d "" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\Desktop" /v "ScreenSaveTimeOut" /t REG_SZ /d "0" /f >> "%LOG_PATH%" 2>&1
                """)),
    };

    public CpuView()
    {
        InitializeComponent();
        Panel.TweakItems = TweakItems;
    }
}