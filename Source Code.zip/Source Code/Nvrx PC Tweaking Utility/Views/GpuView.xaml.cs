using System.Collections.ObjectModel;
using System.Windows.Controls;
using NvrxPCTweakingUtility.Models;
using NvrxPCTweakingUtility.Services;

namespace NvrxPCTweakingUtility.Views;

public partial class GpuView : UserControl
{
    public ObservableCollection<TweakItem> TweakItems { get; } = new()
    {
        TweakFactory.Ready("Disable NVIDIA Dynamic P-States",
            "Disables dynamic and asynchronous power states on NVIDIA GPUs so clocks stay at a steady level instead of bouncing up and down, which can reduce micro-stutter.",
            CmdService.Script("""
                for /f "tokens=*" %%n in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}" /f "NVIDIA" /t REG_SZ /s /e ^| findstr /l "}"') do (
                    reg add "%%n" /v "DisableDynamicPstate" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                    reg add "%%n" /v "DisableAsyncPstates" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                )
                """)),

        TweakFactory.Ready("Import Nvrx Ultimate Profile V2.nip",
            "Downloads NVIDIA Profile Inspector and imports the pre-tuned Nvrx Ultimate Profile V2, applying optimized per-game and global NVIDIA settings.",
            CmdService.Script("""
                curl -g -L -# -o "C:\Nvrx\nvidiaProfileInspector.zip" "https://github.com/Orbmu2k/nvidiaProfileInspector/releases/download/2.4.0.31/nvidiaProfileInspector.zip"
                powershell -NoProfile -Command "Expand-Archive -Path 'C:\Nvrx\nvidiaProfileInspector.zip' -DestinationPath 'C:\Nvrx\NvidiaProfileInspector' -Force"
                curl -g -L -# -o "C:\Nvrx\NvidiaProfileInspector\Nvrx Ultimate Profile V2.nip" "https://www.dropbox.com/scl/fi/arfy0nix8lo66vk50mdmu/Nvrx-Ultimate-Profile-V2.nip?rlkey=rgd0natexbbcw2bbtfevxofit&st=wsosdbuk&dl=1"
                start "" /wait "C:\Nvrx\NvidiaProfileInspector\nvidiaProfileInspector.exe" -silentImport "C:\Nvrx\NvidiaProfileInspector\Nvrx Ultimate Profile V2.nip"
                del /f /q "C:\Nvrx\nvidiaProfileInspector.zip" >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Apply MSI Utility v3 Tweaks",
            "Launches MSI Utility V3 so you can enable MSI (Message Signaled Interrupts) mode on your GPU and lower interrupt latency. Follow the on-screen instructions, then click Apply.",
            CmdService.Script("""
                if not exist "C:\Nvrx\MSI Utility V3\" mkdir "C:\Nvrx\MSI Utility V3\"
                curl -g -L -# -o "C:\Nvrx\MSI Utility V3\MSI Utility V3.exe" "https://www.dropbox.com/scl/fi/i9krde7osr3ibxqeiy0d1/MSI-Utility-V3.exe?rlkey=b33y1pleojg2raubpk01vgi4e&st=736xdji3&dl=1"
                powershell -Command "Start-Process 'C:\Nvrx\MSI Utility V3\MSI Utility V3.exe' -Verb RunAs"
                powershell -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show('Find your GPU in there and be sure that msi mode is checked, set interrupt policy to undefined. After that click on Apply button and close that app.', 'Nvrx PC Tweaking Utility - TODO', 'OK', 'Information')"
                """)),

        TweakFactory.Create("Custom Driver Guide",
            "Custom NVIDIA driver guide — coming soon.",
            "Wait for guide on youtube or in discord"),
    };

    public GpuView()
    {
        InitializeComponent();
        Panel.TweakItems = TweakItems;
    }
}