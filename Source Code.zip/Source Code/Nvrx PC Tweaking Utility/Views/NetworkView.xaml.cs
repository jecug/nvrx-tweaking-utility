using System.Collections.ObjectModel;
using System.Windows.Controls;
using NvrxPCTweakingUtility.Models;
using NvrxPCTweakingUtility.Services;

namespace NvrxPCTweakingUtility.Views;

public partial class NetworkView : UserControl
{
    public ObservableCollection<TweakItem> TweakItems { get; } = new()
    {
        TweakFactory.Ready("Reset Network",
            "Releases and renews your IP address, clears the DNS cache and resets the whole TCP/IP, Winsock and firewall stack. Fixes many network glitches; a reboot is sometimes required.",
            CmdService.Script("""
                ipconfig /release >> "%LOG_PATH%" 2>&1
                ipconfig /renew >> "%LOG_PATH%" 2>&1
                ipconfig /flushdns >> "%LOG_PATH%" 2>&1
                netsh int ip reset >> "%LOG_PATH%" 2>&1
                netsh int ipv4 reset >> "%LOG_PATH%" 2>&1
                netsh int ipv6 reset >> "%LOG_PATH%" 2>&1
                netsh int tcp reset >> "%LOG_PATH%" 2>&1
                netsh winsock reset >> "%LOG_PATH%" 2>&1
                netsh advfirewall reset >> "%LOG_PATH%" 2>&1
                netsh branchcache reset >> "%LOG_PATH%" 2>&1
                netsh http flush logbuffer >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Optimize TCP/IP Settings",
            "Tunes TCP settings for lower latency: enables RSS and TCP Fast Open, disables timestamps/RSC, and raises port and timeout limits.",
            CmdService.Script("""
                netsh int tcp set global rss=enabled >> "%LOG_PATH%" 2>&1
                netsh int tcp set global autotuninglevel=normal >> "%LOG_PATH%" 2>&1
                netsh int tcp set global rsc=disabled >> "%LOG_PATH%" 2>&1
                netsh int tcp set global timestamps=disabled >> "%LOG_PATH%" 2>&1
                netsh int tcp set global fastopen=enabled >> "%LOG_PATH%" 2>&1
                netsh int tcp set global fastopenfallback=enabled >> "%LOG_PATH%" 2>&1
                netsh int tcp set heuristics disabled >> "%LOG_PATH%" 2>&1
                netsh int tcp set supplemental template=custom icw=10 >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v "EnableLMHOSTS" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v "SackOpts" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v "MaxUserPort" /t REG_DWORD /d 65534 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v "TcpTimedWaitDelay" /t REG_DWORD /d 30 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters" /v "MaxCacheEntryTtlLimit" /t REG_DWORD /d 64000 /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Legacy Protocols & MTU Optimization",
            "Disables deprecated IPv6 tunneling (ISATAP/Teredo) and increases the IPv6 neighbor cache limit, improving network discovery and stability.",
            CmdService.Script("""
                netsh int isatap set state disabled >> "%LOG_PATH%" 2>&1
                netsh int teredo set state disabled >> "%LOG_PATH%" 2>&1
                netsh int ip set global neighborcachelimit=4096 >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Disable Wi-Fi Sense",
            "Stops Windows from automatically connecting to open Wi-Fi hotspots and from sharing/collecting hotspot information, improving privacy.",
            CmdService.Script("""
                reg add "HKLM\Software\Microsoft\PolicyManager\default\WiFi\AllowAutoConnectToWiFiSenseHotspots" /v "value" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\Software\Microsoft\PolicyManager\default\WiFi\AllowWiFiHotSpotReporting" /v "value" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Set DNS to Cloudflare",
            "Sets your active network adapters to use Cloudflare DNS (1.1.1.1 / 1.0.0.1) for faster, more private domain resolution. A reboot may be needed.",
            CmdService.Script("""
                powershell -NoProfile -Command "Get-NetAdapter | Where-Object {$_.Status -eq 'Up'} | ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.InterfaceIndex -ServerAddresses @('1.1.1.1','1.0.0.1') -EA SilentlyContinue }" >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Disable Delivery Optimization Service",
            "Stops and disables the Windows Delivery Optimization service, which shares Windows/Store update data over your network. Reduces background network and disk activity.",
            CmdService.Script("""
                sc stop DoSvc >> "%LOG_PATH%" 2>&1
                sc config DoSvc start=disabled >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Advanced Network Adapter Tweaks",
            "Disables NIC power saving and Energy-Efficient Ethernet (EEE), tunes offload/RSS/checksum and buffer settings, and restarts adapters to apply. May briefly drop network.",
            CmdService.Script("""
                powershell -NoProfile -Command "Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters\Interfaces\*' | ForEach-Object { Set-ItemProperty -Path $_.PSPath -Name NetbiosOptions -Value 2 -EA SilentlyContinue }" >> "%LOG_PATH%" 2>&1
                powershell -NoProfile -Command "Get-NetAdapter | Disable-NetAdapterPowerManagement -EA SilentlyContinue" >> "%LOG_PATH%" 2>&1
                powershell -NoProfile -Command "Get-NetAdapter -IncludeHidden | Set-NetIPInterface -WeakHostSend Enabled -WeakHostReceive Enabled -EA SilentlyContinue" >> "%LOG_PATH%" 2>&1
                for /f "tokens=*" %%n in ('Reg query "HKLM\SYSTEM\CurrentControlSet\Control\Class\{4D36E972-E325-11CE-BFC1-08002bE10318}" /f "*SpeedDuplex" /s ^| findstr "HKEY"') do (
                    reg add "%%n" /v "*EnergyEfficientEthernet" /t REG_SZ /d "0" /f >> "%LOG_PATH%" 2>&1
                    reg add "%%n" /v "*EEE" /t REG_SZ /d "0" /f >> "%LOG_PATH%" 2>&1
                    reg add "%%n" /v "EEE" /t REG_SZ /d "0" /f >> "%LOG_PATH%" 2>&1
                    reg add "%%n" /v "EnableGreenEthernet" /t REG_SZ /d "0" /f >> "%LOG_PATH%" 2>&1
                    reg add "%%n" /v "EnablePowerManagement" /t REG_SZ /d "0" /f >> "%LOG_PATH%" 2>&1
                    reg add "%%n" /v "PowerSavingMode" /t REG_SZ /d "0" /f >> "%LOG_PATH%" 2>&1
                    reg add "%%n" /v "ULPMode" /t REG_SZ /d "0" /f >> "%LOG_PATH%" 2>&1
                    reg add "%%n" /v "AutoDisableGigabit" /t REG_SZ /d "0" /f >> "%LOG_PATH%" 2>&1
                    reg add "%%n" /v "TCPChecksumOffloadIPv4" /t REG_SZ /d "3" /f >> "%LOG_PATH%" 2>&1
                    reg add "%%n" /v "TCPChecksumOffloadIPv6" /t REG_SZ /d "3" /f >> "%LOG_PATH%" 2>&1
                    reg add "%%n" /v "UDPChecksumOffloadIPv4" /t REG_SZ /d "3" /f >> "%LOG_PATH%" 2>&1
                    reg add "%%n" /v "UDPChecksumOffloadIPv6" /t REG_SZ /d "3" /f >> "%LOG_PATH%" 2>&1
                    reg add "%%n" /v "LsoV2IPv4" /t REG_SZ /d "1" /f >> "%LOG_PATH%" 2>&1
                    reg add "%%n" /v "LsoV2IPv6" /t REG_SZ /d "1" /f >> "%LOG_PATH%" 2>&1
                    reg add "%%n" /v "RSS" /t REG_SZ /d "1" /f >> "%LOG_PATH%" 2>&1
                    reg add "%%n" /v "*NumRssQueues" /t REG_SZ /d "2" /f >> "%LOG_PATH%" 2>&1
                    reg add "%%n" /v "ReceiveBuffers" /t REG_SZ /d "512" /f >> "%LOG_PATH%" 2>&1
                    reg add "%%n" /v "TransmitBuffers" /t REG_SZ /d "512" /f >> "%LOG_PATH%" 2>&1
                    reg add "%%n" /v "JumboPacket" /t REG_SZ /d "1514" /f >> "%LOG_PATH%" 2>&1
                )
                powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-NetAdapter | Where-Object { $_.Status -eq 'Up' } | ForEach-Object { $n = $_.Name; @{ 'Speed & Duplex'='Auto Negotiation'; '*SpeedDuplex'='Auto Negotiation' }.GetEnumerator() | ForEach-Object { try { Set-NetAdapterAdvancedProperty -Name $n -DisplayName $_.Name -DisplayValue $_.Value -ErrorAction SilentlyContinue } catch {} } }" >> "%LOG_PATH%" 2>&1
                powershell -NoProfile -Command "$nic='HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4D36E972-E325-11CE-BFC1-08002bE10318}'; Get-ChildItem $nic -EA SilentlyContinue | Where-Object {$_.PSChildName -match '^\d{4}$'} | ForEach-Object { $p='HKLM:\SYSTEM\CurrentControlSet\Enum\'+$_.InstanceId+'\Device Parameters\WDF'; if(!(Test-Path $p)){New-Item $p -Force|Out-Null}; Set-ItemProperty $p 'IdleInD3' 0 -EA SilentlyContinue }" >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Services\NDIS\Parameters" /v "PacketCoalescing" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Services\NDIS\Parameters" /v "NoPauseOnSuspend" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                powershell -NoProfile -ExecutionPolicy Bypass -Command "$patterns = @('Microsoft ISATAP Adapter','Microsoft 6to4 Adapter','Fax','Send to OneNote'); Get-PnpDevice -PresentOnly:$false | Where-Object { $patterns -contains $_.FriendlyName } | ForEach-Object { try { Disable-PnpDevice -InstanceId $_.InstanceId -Confirm:$false -ErrorAction Stop } catch {} }" >> "%LOG_PATH%" 2>&1
                powershell -NoProfile -ExecutionPolicy Bypass -Command "$keys=Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}' -ErrorAction SilentlyContinue; foreach($key in $keys){ if(Get-ItemProperty -Path $key.PSPath -Name DriverDesc -ErrorAction SilentlyContinue){ New-ItemProperty -Path $key.PSPath -Name PnPCapabilities -PropertyType DWord -Value 24 -Force -ErrorAction SilentlyContinue | Out-Null } }" >> "%LOG_PATH%" 2>&1
                powershell -NoProfile -Command "Get-NetAdapter -Physical | ForEach-Object { Restart-NetAdapter -Name $_.Name -Confirm:$false -ErrorAction SilentlyContinue }" >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Harden Network Security",
            "Disables the insecure legacy SMB1 protocol and tightens network security (anonymous logon restrictions, secure credentials, LSA protection). May break old-school LAN/SMB shares.",
            CmdService.Script("""
                powershell -NoProfile -Command "Disable-WindowsOptionalFeature -Online -FeatureName SMB1Protocol -NoRestart -EA SilentlyContinue" >> "%LOG_PATH%" 2>&1
                reg add "HKLM\System\CurrentControlSet\Services\LanManServer\Parameters" /v "RestrictNullSessAccess" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\System\CurrentControlSet\Services\LanManServer\Parameters" /v "DisableCompression" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                powershell -NoProfile -Command "Set-SmbClientConfiguration -EnableInsecureGuestLogons:$false -Force" >> "%LOG_PATH%" 2>&1
                reg add "HKLM\System\CurrentControlSet\Control\Lsa" /v "RestrictAnonymous" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\System\CurrentControlSet\Control\Lsa" /v "RestrictAnonymousSAM" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\Software\Policies\Microsoft\Windows\CredentialsDelegation" /v "AllowProtectedCreds" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\System\CurrentControlSet\Control\Lsa" /v "DisableRestrictedAdminOutboundCreds" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\System\CurrentControlSet\Control\Lsa" /v "DisableRestrictedAdmin" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\System\CurrentControlSet\Control\Lsa" /v "RunAsPPL" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\System\CurrentControlSet\Control\SecurityProviders\WDigest" /v "Negotiate" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\System\CurrentControlSet\Control\SecurityProviders\WDigest" /v "UseLogonCredential" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                """)),
    };

    public NetworkView()
    {
        InitializeComponent();
        Panel.TweakItems = TweakItems;
    }
}