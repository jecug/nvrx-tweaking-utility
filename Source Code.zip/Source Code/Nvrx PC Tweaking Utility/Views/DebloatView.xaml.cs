using System.Collections.ObjectModel;
using System.Windows.Controls;
using NvrxPCTweakingUtility.Models;
using NvrxPCTweakingUtility.Services;

namespace NvrxPCTweakingUtility.Views;

public partial class DebloatView : UserControl
{
    public ObservableCollection<TweakItem> TweakItems { get; } = new()
    {
        TweakFactory.Ready("Disable Startup Apps",
            "Opens Autoruns so you can review and disable unnecessary startup entries. Tip: keep antivirus, cmd.exe and the n/a services enabled.",
            CmdService.Script("""
                mkdir "C:\Nvrx\Autoruns\"
                curl -g -L -# -o "C:\Nvrx\Autoruns\Autoruns.exe" "https://www.dropbox.com/scl/fi/x4xwackwfn191pv2lc6xf/Autoruns.exe?rlkey=ettzx61n86in4e3tbe63rmtal&st=xzycli9q&dl=1"
                powershell -Command "Start-Process 'C:\Nvrx\Autoruns\Autoruns.exe' -Verb RunAs"
                powershell -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show('In there disable all unwanted stuff except: antivirus, cmd.exe, and the n/a services.', 'Nvrx PC Tweaking Utility - TODO', 'OK', 'Information')"
                """)),

        TweakFactory.Ready("Disable Microsoft Office Telemetry",
            "Stops Microsoft Office (Access, Excel, PowerPoint, OneNote, Publisher, Visio, Word, Outlook) from sending telemetry and usage data.",
            CmdService.Script("""
                reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM" /v "EnableLogging" /t REG_DWORD /d 0 /f >nul 2>&1
                reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM" /v "EnableUpload" /t REG_DWORD /d 0 /f >nul 2>&1
                reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedApplications" /v "accesssolution" /t REG_DWORD /d 1 /f >nul 2>&1
                reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedApplications" /v "olksolution" /t REG_DWORD /d 1 /f >nul 2>&1
                reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedApplications" /v "onenotesolution" /t REG_DWORD /d 1 /f >nul 2>&1
                reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedApplications" /v "pptsolution" /t REG_DWORD /d 1 /f >nul 2>&1
                reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedApplications" /v "projectsolution" /t REG_DWORD /d 1 /f >nul 2>&1
                reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedApplications" /v "publishersolution" /t REG_DWORD /d 1 /f >nul 2>&1
                reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedApplications" /v "visiosolution" /t REG_DWORD /d 1 /f >nul 2>&1
                reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedApplications" /v "wdsolution" /t REG_DWORD /d 1 /f >nul 2>&1
                reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedApplications" /v "xlsolution" /t REG_DWORD /d 1 /f >nul 2>&1
                reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedSolutionTypes" /v "agave" /t REG_DWORD /d 1 /f >nul 2>&1
                reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedSolutionTypes" /v "appaddins" /t REG_DWORD /d 1 /f >nul 2>&1
                reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedSolutionTypes" /v "comaddins" /t REG_DWORD /d 1 /f >nul 2>&1
                reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedSolutionTypes" /v "documentfiles" /t REG_DWORD /d 1 /f >nul 2>&1
                reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedSolutionTypes" /v "templatefiles" /t REG_DWORD /d 1 /f >nul 2>&1
                """)),

        TweakFactory.Ready("Disable SmartScreen",
            "Disables Windows SmartScreen and web content evaluation so apps/windows don't get silently checked or blocked online.",
            CmdService.Script("""
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v "EnableSmartScreen" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" /v "SmartScreenEnabled" /t REG_SZ /d "Off" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\AppHost" /v "EnableWebContentEvaluation" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Apply Some Windows Defender Commands",
            "Tunes Windows Defender: lowers cloud-block level, disables enhanced notifications, caps scan CPU usage to 25% and lowers Defender's CPU priority so scans don't slow you down.",
            CmdService.Script("""
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\MpEngine" /v "MpCloudBlockLevel" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Reporting" /v "DisableEnhancedNotifications" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Scan" /v "AvgCPULoadFactor" /t REG_DWORD /d 25 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Scan" /v "ScanAvgCPULoadFactor" /t REG_DWORD /d 25 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\MsMpEng.exe\PerfOptions" /v "CpuPriorityClass" /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\MsMpEngCP.exe\PerfOptions" /v "CpuPriorityClass" /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Debloat Mozilla Firefox",
            "Removes Firefox telemetry, studies, Pocket, the default-browser agent and its cache files (minidump/pingsender/logs).",
            CmdService.Script("""
                del /f /s /q "%APPDATA%\Mozilla\Firefox\Profiles\*.default\cache2\*.*" >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Mozilla\Firefox" /v "DisableTelemetry" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Mozilla\Firefox" /v "DisableFirefoxStudies" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Mozilla\Firefox" /v "PocketEnabled" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Mozilla\Firefox" /v "DisableDefaultBrowserAgent" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                del "C:\Program Files\Mozilla Firefox\minidump-analyzer.exe" /f /q >> "%LOG_PATH%" 2>&1
                del "C:\Program Files\Mozilla Firefox\pingsender.exe" /f /q >> "%LOG_PATH%" 2>&1
                cd /d "C:\Program Files\Mozilla Firefox" >> "%LOG_PATH%" 2>&1
                del /f install.log >> "%LOG_PATH%" 2>&1
                del /f minidump*.* >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Debloat Steam",
            "Disables Steam from starting with Windows and removes its startup entry to reduce background load.",
            CmdService.Script("""
                reg add "HKCU\SOFTWARE\Valve\Steam" /v "StartupMode" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg delete "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "Steam" /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Debloat Spotify",
            "Closes Spotify, removes its startup entry and deletes its cache and debug log files.",
            CmdService.Script("""
                taskkill /F /IM Spotify.exe >> "%LOG_PATH%" 2>&1
                reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "Spotify" /f >> "%LOG_PATH%" 2>&1
                cd /d "%APPDATA%\Spotify" >> "%LOG_PATH%" 2>&1
                del /f crash*.* >> "%LOG_PATH%" 2>&1
                del /f debug.log >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Debloat Discord",
            "Closes Discord, clears its cache folders and logs, removes its startup entry and disables telemetry, crash reporting, animations, overlay and rich presence.",
            CmdService.Script("""
                taskkill /IM Discord.exe /F >> "%LOG_PATH%" 2>&1
                taskkill /IM DiscordPTB.exe /F >> "%LOG_PATH%" 2>&1
                taskkill /IM DiscordCanary.exe /F >> "%LOG_PATH%" 2>&1
                taskkill /IM DiscordOverlayHost.exe /F >> "%LOG_PATH%" 2>&1
                taskkill /IM DiscordGameDetector.exe /F >> "%LOG_PATH%" 2>&1
                taskkill /IM Update.exe /F >> "%LOG_PATH%" 2>&1
                set "DISC_APPDATA=%APPDATA%\discord"
                set "DISC_LOCAL=%LOCALAPPDATA%\Discord"
                for %%D in (
                Cache
                GPUCache
                DawnCache
                Code Cache
                logs
                Crashpad
                blob_storage
                Temp
                Service Worker
                ) do (
                    if exist "%DISC_APPDATA%\%%D" rmdir /s /q "%DISC_APPDATA%\%%D"
                    if exist "%DISC_LOCAL%\%%D" rmdir /s /q "%DISC_LOCAL%\%%D"
                )
                del /f /q "%DISC_APPDATA%\*.log" >> "%LOG_PATH%" 2>&1
                del /f /q "%DISC_LOCAL%\*.log" >> "%LOG_PATH%" 2>&1
                if exist "%LOCALAPPDATA%\SquirrelTemp" rmdir /s /q "%LOCALAPPDATA%\SquirrelTemp"
                reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v Discord /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Discord" /v "TelemetryEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Discord" /v "EnableTelemetry" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Discord" /v "CrashReportingEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Discord" /v "EnableAnimations" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Discord" /v "EnableRichPresence" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                if exist "%APPDATA%\discord\settings.json" (
                powershell -NoProfile -Command ^
                "$p='%APPDATA%\discord\settings.json'; ^
                $j=Get-Content $p -Raw | ConvertFrom-Json; ^
                if(-not $j.settings){$j | Add-Member settings @{} -Force}; ^
                if(-not $j.settings.overlay){$j.settings.overlay=@{} }; ^
                $j.settings.overlay.enabled=$false; ^
                $j | ConvertTo-Json -Depth 10 | Set-Content $p -Encoding UTF8" >> "%LOG_PATH%" 2>&1
                )
                """)),

        TweakFactory.Ready("Debloat Adobe",
            "Closes Adobe apps, disables Adobe background/services and telemetry (AGS/AGM/Update service), and removes Adobe startup entries and usage capture.",
            CmdService.Script("""
                taskkill /IM "Adobe CEF Helper.exe" /F >> "%LOG_PATH%" 2>&1
                taskkill /IM "AdobeIPCBroker.exe" /F >> "%LOG_PATH%" 2>&1
                taskkill /IM "CCXProcess.exe" /F >> "%LOG_PATH%" 2>&1
                taskkill /IM "CoreSync.exe" /F >> "%LOG_PATH%" 2>&1
                taskkill /IM "Adobe Desktop Service.exe" /F >> "%LOG_PATH%" 2>&1
                taskkill /IM "AdobeUpdateService.exe" /F >> "%LOG_PATH%" 2>&1
                taskkill /IM "AdobeCollabSync.exe" /F >> "%LOG_PATH%" 2>&1
                taskkill /IM "AdobeNotificationClient.exe" /F >> "%LOG_PATH%" 2>&1
                sc stop AGSService >> "%LOG_PATH%" 2>&1
                sc config AGSService start= disabled >> "%LOG_PATH%" 2>&1
                sc stop AGMService >> "%LOG_PATH%" 2>&1
                sc config AGMService start= disabled >> "%LOG_PATH%" 2>&1
                sc stop AdobeUpdateService >> "%LOG_PATH%" 2>&1
                sc config AdobeUpdateService start= disabled >> "%LOG_PATH%" 2>&1
                sc stop AdobeARMservice >> "%LOG_PATH%" 2>&1
                sc config AdobeARMservice start= disabled >> "%LOG_PATH%" 2>&1
                reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "Adobe Creative Cloud" /f >> "%LOG_PATH%" 2>&1
                reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "AdobeGCInvoker-1.0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Adobe\CommonFiles\UsageCC" /v "UsageCC" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Adobe\Adobe Acrobat\DC\AVGeneral" /v "bUsageData" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Adobe\CrashReporter" /v "OptIn" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Adobe\Adobe Creative Cloud" /v "DisableNotifications" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Debloat Tiktok LIVE Studio",
            "Closes Tiktok LIVE Studio, clears its cache folders and disables telemetry, crash reporting, usage stats and auto-update.",
            CmdService.Script("""
                taskkill /IM "TikTok LIVE Studio.exe" /F >> "%LOG_PATH%" 2>&1
                rmdir /s /q "%APPDATA%\TikTok LIVE Studio\Cache" >> "%LOG_PATH%" 2>&1
                rmdir /s /q "%APPDATA%\TikTok LIVE Studio\GPUCache" >> "%LOG_PATH%" 2>&1
                rmdir /s /q "%APPDATA%\TikTok LIVE Studio\Code Cache" >> "%LOG_PATH%" 2>&1
                rmdir /s /q "%LOCALAPPDATA%\TikTok LIVE Studio\Cache" >> "%LOG_PATH%" 2>&1
                rmdir /s /q "%LOCALAPPDATA%\TikTok LIVE Studio\Temp" >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\TikTok LIVE Studio" /v TelemetryEnabled /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\TikTok LIVE Studio" /v CrashHandlerEnabled /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\TikTok LIVE Studio" /v SendUsageStats /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\TikTok LIVE Studio" /v AutoUpdate /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Disable Windows AI",
            "Removes Copilot, Recall and other Windows AI packages/scheduled tasks, disables the AI service, and blocks AI access across Copilot, Cortana, Paint, Notepad, Edge and app privacy. Disabling Recall will delete its history.",
            CmdService.Script("""
                taskkill /F /IM "ai.exe" /IM "Copilot.exe" /IM "aihost.exe" /IM "aicontext.exe" /IM "ClickToDo.exe" /IM "aixhost.exe" /IM "WorkloadsSessionHost.exe" >> "%LOG_PATH%" 2>&1
                sc stop WSAIFabricSvc >> "%LOG_PATH%" 2>&1
                sc config WSAIFabricSvc start= disabled >> "%LOG_PATH%" 2>&1
                dism /Online /Disable-Feature /NoRestart /FeatureName:Recall /Quiet >> "%LOG_PATH%" 2>&1
                powershell -NoProfile -ExecutionPolicy Bypass -Command "$packages = @('Microsoft.549981C3F5F10', 'Microsoft.Windows.Ai.Copilot.Provider', 'Microsoft.Copilot', 'Microsoft.WindowsAiFoundation', 'Microsoft.Windows.Recall', 'MicrosoftWindows.Client.AIX', 'Microsoft.Windows.Copilot', 'Client.CoPilot', 'Ai.Copilot', 'Client.CoreAI'); foreach ($pkg in $packages) { Get-AppxPackage -Name \"*$pkg*\" -AllUsers | Remove-AppxPackage -AllUsers -ErrorAction SilentlyContinue; Get-AppxProvisionedPackage -Online | Where-Object {$_.DisplayName -like \"*$pkg*\"} | Remove-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue; }; $recallTasks = @('\Microsoft\Windows\WindowsAI\*', '\Microsoft\Windows\Recall\*'); foreach ($taskPath in $recallTasks) { Get-ScheduledTask -TaskPath $taskPath -ErrorAction SilentlyContinue | Unregister-ScheduledTask -Confirm:$false -ErrorAction SilentlyContinue; }" >> "%LOG_PATH%" 2>&1
                schtasks /delete /tn "\Microsoft\Windows\WindowsAI\Recall" /f >> "%LOG_PATH%" 2>&1
                schtasks /delete /tn "\Microsoft\Windows\WindowsAI\Settings" /f >> "%LOG_PATH%" 2>&1
                schtasks /delete /tn "\Microsoft\Windows\WindowsAI" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot" /v "TurnOffWindowsCopilot" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "DisableAIDataAnalysis" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "AllowRecallEnablement" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "DisableClickToDo" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "TurnOffSavingSnapshots" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "DisableSettingsAgent" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "DisableAgentConnectors" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "AllowModelSharing" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "DisableRemoteAgentConnectors" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "DisableAgentWorkspaces" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\Shell\Copilot\BingChat" /v "IsUserEligible" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\Shell\Copilot" /v "IsCopilotAvailable" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\Shell\Copilot" /v "CopilotDisabledReason" /t REG_SZ /d "FeatureIsDisabled" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked" /v "{CB3B0003-8088-4EDE-8769-8B354AB2FF8C}" /t REG_SZ /d " " /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search" /v "AllowCortana" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search" /v "CortanaConsent" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "CopilotCDPPageContext" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v CopilotPageAction /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "CopilotPageContext" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "HubsSidebarEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "EdgeEntraCopilotPageContext" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "Microsoft365CopilotChatIconEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "EdgeHistoryAISearchEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "ComposeInlineEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "GenAILocalFoundationalModelSettings" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Paint" /v "DisableImageCreator" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Paint" /v "DisableCocreator" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Paint" /v "DisableGenerativeFill" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Paint" /v "DisableGenerativeErase" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Paint" /v "DisableRemoveBackground" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\WindowsNotepad" /v "DisableAIFeatures" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\WindowsNotepad" /v "DisableWritingTools" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsAccessGenerativeAI" /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsAccessSystemAIModels" /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsAccessAI" /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsAccessTextAndImageGeneration" /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsAccessGazeInput" /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsAccessHumanPresence" /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsAccessSpatialPerception" /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsSyncWithDevices" /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\systemAIModels" /v "Value" /t REG_SZ /d "Deny" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\systemAIModels" /v "RecordUsageData" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\generativeAI" /v "Value" /t REG_SZ /d "Deny" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\gazeInput" /v "Value" /t REG_SZ /d "Deny" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\humanPresence" /v "Value" /t REG_SZ /d "Deny" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\spatialPerception" /v "Value" /t REG_SZ /d "Deny" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\backgroundSpatialPerception" /v "Value" /t REG_SZ /d "Deny" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot" /v "TurnOffWindowsCopilot" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "DisableAIDataAnalysis" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "AllowRecallEnablement" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "DisableClickToDo" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "TurnOffSavingSnapshots" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "DisableSettingsAgent" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\Shell\Copilot\BingChat" /v "IsUserEligible" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\Shell\Copilot" /v "IsCopilotAvailable" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\Shell\Copilot" /v "CopilotDisabledReason" /t REG_SZ /d "FeatureIsDisabled" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "ShowCopilotButton" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\input\Settings" /v "InsightsEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Policies\Microsoft\Windows\Explorer" /v "DisableSearchBoxSuggestions" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Notifications\Settings" /v "AutoOpenCopilotLargeScreens" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsCopilot" /v "AllowCopilotRuntime" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Notepad" /v "ShowRewriteButton" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKU\.DEFAULT\Software\Policies\Microsoft\Windows\WindowsAI" /v "DisableClickToDo" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\systemAIModels" /v "Value" /t REG_SZ /d "Deny" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\generativeAI" /v "Value" /t REG_SZ /d "Deny" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\gazeInput" /v "Value" /t REG_SZ /d "Deny" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\humanPresence" /v "Value" /t REG_SZ /d "Deny" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\spatialPerception" /v "Value" /t REG_SZ /d "Deny" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\backgroundSpatialPerception" /v "Value" /t REG_SZ /d "Deny" /f >> "%LOG_PATH%" 2>&1
                reg delete "HKCR\ms-office-ai" /f >> "%LOG_PATH%" 2>&1
                reg delete "HKCR\ms-copilot" /f >> "%LOG_PATH%" 2>&1
                reg delete "HKCR\ms-clicktodo" /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Uninstall Useless Windows Apps",
            "Downloads Geek Uninstaller so you can manually remove unwanted apps. Use Microsoft Store Apps view to uninstall built-in apps with leftover-trace removal.",
            CmdService.Script("""
                mkdir "C:\Nvrx\Geek\"
                curl -g -L -# -o "C:\Nvrx\Geek\geek.exe" "https://www.dropbox.com/scl/fi/cijd0xgjlj52a2a0ihkr1/geek.exe?rlkey=z43asazchcrqgmz3vk2gh725x&st=s6l1wgmw&dl=1"
                powershell -Command "Start-Process 'C:\Nvrx\Geek\geek.exe' -Verb RunAs"
                powershell -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show('Click on View and select Microsoft Store Apps, in there delete ALL apps(with leftover traces removal) that you don''t need AND PLEASE BE CAREFUL.', 'Nvrx PC Tweaking Utility - TODO', 'OK', 'Information')"
                """)),

        TweakFactory.Ready("Pause Windows Updates",
            "Pauses Windows feature and quality updates for an extremely long time (until January 2038) and blocks store/prerelease scheduled updates, so Windows stays exactly as it is.",
            CmdService.Script("""
                reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v "PauseFeatureUpdatesStartTime" /t REG_SZ /d "2023-08-17T12:47:51Z" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v "PauseFeatureUpdatesEndTime" /t REG_SZ /d "2038-01-19T03:14:07Z" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v "PauseQualityUpdatesStartTime" /t REG_SZ /d "2023-08-17T12:47:51Z" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v "PauseQualityUpdatesEndTime" /t REG_SZ /d "2038-01-19T03:14:07Z" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v "PauseUpdatesStartTime" /t REG_SZ /d "2023-08-17T12:47:51Z" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v "PauseUpdatesExpiryTime" /t REG_SZ /d "2038-01-19T03:14:07Z" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\Setup\UpgradeNotification" /v "UpgradeAvailable" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\Software\Policies\Microsoft\MRT" /v "DontReportInfectionInformation" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Settings" /v "DownloadMode" /t REG_SZ /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\PreviewBuilds" /v "AllowBuildPreview" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg delete "HKLM\SOFTWARE\Microsoft\WindowsUpdate\Orchestrator\UScheduler_Oobe\DevHomeUpdate" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Orchestrator\UScheduler\DevHomeUpdate" /v "workCompleted" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg delete "HKLM\SOFTWARE\Microsoft\WindowsUpdate\Orchestrator\UScheduler_Oobe\OutlookUpdate" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Orchestrator\UScheduler\OutlookUpdate" /v "workCompleted" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\Orchestrator\UScheduler_Oobe" /v "BlockedOobeUpdaters" /t REG_SZ /d "[\"MS_Outlook\"]" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v "HideMCTLink" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v "RestartNotificationsAllowed2" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\Software\Policies\Microsoft\Windows\WindowsUpdate" /v "DoNotConnectToWindowsUpdateInternetLocations" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v "SetDisableUXWUAccess" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\WindowsStore" /v "AutoDownload" /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\WindowsStore" /v "DisableOSUpgrade" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\Software\Policies\Microsoft\Windows\WindowsUpdate\AU" /v "AUOptions" /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\Software\Policies\Microsoft\Windows\WindowsUpdate\AU" /v "AutomaticMaintenanceEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" /v "NoAutoUpdate" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Uninstall OneDrive",
            "Uninstalls OneDrive completely: removes the app, its sync/services, startup and scheduled tasks, deletes its folders and moves your files back into your user folders. Backup your OneDrive files first.",
            CmdService.Script("""
                taskkill /F /IM "OneDriveStandaloneUpdater.exe" >> "%LOG_PATH%" 2>&1
                taskkill /F /IM "OneDriveSetup.exe" >> "%LOG_PATH%" 2>&1
                taskkill /F /IM "OneDrive.exe" >> "%LOG_PATH%" 2>&1
                taskkill /F /IM "FileCoAuth.exe" >> "%LOG_PATH%" 2>&1
                taskkill /F /IM "Microsoft.SharePoint.exe" >> "%LOG_PATH%" 2>&1
                if exist "%SystemRoot%\System32\OneDriveSetup.exe" (
                    start "" /wait "%SystemRoot%\System32\OneDriveSetup.exe" /uninstall >> "%LOG_PATH%" 2>&1
                )
                if exist "%SystemRoot%\SysWOW64\OneDriveSetup.exe" (
                    start "" /wait "%SystemRoot%\SysWOW64\OneDriveSetup.exe" /uninstall >> "%LOG_PATH%" 2>&1
                )
                powershell -NoProfile -Command "Get-AppxPackage -AllUsers *OneDrive* | Remove-AppxPackage -AllUsers" >> "%LOG_PATH%" 2>&1
                sc delete OneSyncSvc >> "%LOG_PATH%" 2>&1
                for /f "tokens=*" %%s in ('sc query ^| findstr /i "OneSyncSvc_"') do (
                    for /f "tokens=2" %%a in ("%%s") do sc delete "%%a" >> "%LOG_PATH%" 2>&1
                )
                schtasks /Delete /TN "\Microsoft\Windows\OneDrive\OneDrive Standalone Update Task" /F >> "%LOG_PATH%" 2>&1
                for /f "usebackq tokens=1* delims=\" %%A in (`schtasks /query /fo list ^| findstr /c:"\OneDrive Reporting Task" /c:"\OneDrive Standalone Update Task"`) do (
                    schtasks /delete /tn "%%B" /f >> "%LOG_PATH%" 2>&1
                )
                powershell -NoProfile -Command "Get-ScheduledTask -TaskPath '\' -TaskName 'OneDrive*' -ErrorAction SilentlyContinue | Unregister-ScheduledTask -Confirm:$false -ErrorAction SilentlyContinue" >> "%LOG_PATH%" 2>&1
                if exist "%~dp0oned.bat" call "%~dp0oned.bat" >> "%LOG_PATH%" 2>&1
                for /f "usebackq tokens=2 delims=\" %%e in (`reg query "HKEY_USERS" ^| findstr /r /x /c:"HKEY_USERS\\S-.*" /c:"HKEY_USERS\\AME_UserHive_[^_]*"`) do (
                    reg query "HKU\%%e" | findstr /c:"Volatile Environment" /c:"AME_UserHive_" >> "%LOG_PATH%" 2>&1
                    if not errorlevel 1 (
                        call :USERREG "%%e"
                    )
                )
                del /f /q "%windir%\System32\OneDriveSetup.exe" >> "%LOG_PATH%" 2>&1
                del /f /q "%windir%\SysWOW64\OneDriveSetup.exe" >> "%LOG_PATH%" 2>&1
                del /f /q "%windir%\SysWOW64\OneDriveSettingSyncProvider.dll" >> "%LOG_PATH%" 2>&1
                reg delete "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "OneDrive" /f >> "%LOG_PATH%" 2>&1
                reg delete "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "OneDriveSetup" /f >> "%LOG_PATH%" 2>&1
                reg delete "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" /v "{0DDD015D-B06C-45D5-8C4C-F59713854639}" /f >> "%LOG_PATH%" 2>&1
                reg delete "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" /v "{35286A68-3C57-41A1-BBB1-0EAE73D76C95}" /f >> "%LOG_PATH%" 2>&1
                reg delete "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" /v "{A0C69A99-21C8-4671-8703-7934162FCF1D}" /f >> "%LOG_PATH%" 2>&1
                reg delete "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" /v "{F42EE2D3-909F-4907-8871-4C22FC0BF756}" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" /v "Desktop" /t REG_SZ /d "%%USERPROFILE%%\Desktop" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" /v "My Music" /t REG_SZ /d "%%USERPROFILE%%\Music" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" /v "My Pictures" /t REG_SZ /d "%%USERPROFILE%%\Pictures" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" /v "My Video" /t REG_SZ /d "%%USERPROFILE%%\Videos" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" /v "Personal" /t REG_SZ /d "%%USERPROFILE%%\Documents" /f >> "%LOG_PATH%" 2>&1
                reg delete "HKCR\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}" /f >> "%LOG_PATH%" 2>&1
                reg delete "HKCU\SOFTWARE\Microsoft\OneDrive" /f >> "%LOG_PATH%" 2>&1
                for /f "usebackq delims=" %%a in (`dir /b /a:d "%SystemDrive%\Users"`) do (
                    rmdir /q /s "%SystemDrive%\Users\%%a\AppData\Local\Microsoft\OneDrive" >> "%LOG_PATH%" 2>&1
                    del /q /f "%SystemDrive%\Users\%%a\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\OneDrive.lnk" >> "%LOG_PATH%" 2>&1
                    if not exist "%SystemDrive%\Users\%%a\Desktop" mkdir "%SystemDrive%\Users\%%a\Desktop" >> "%LOG_PATH%" 2>&1
                    if not exist "%SystemDrive%\Users\%%a\Documents" mkdir "%SystemDrive%\Users\%%a\Documents" >> "%LOG_PATH%" 2>&1
                    if not exist "%SystemDrive%\Users\%%a\Pictures" mkdir "%SystemDrive%\Users\%%a\Pictures" >> "%LOG_PATH%" 2>&1
                    if not exist "%SystemDrive%\Users\%%a\Videos" mkdir "%SystemDrive%\Users\%%a\Videos" >> "%LOG_PATH%" 2>&1
                    if not exist "%SystemDrive%\Users\%%a\Music" mkdir "%SystemDrive%\Users\%%a\Music" >> "%LOG_PATH%" 2>&1
                    if exist "%SystemDrive%\Users\%%a\OneDrive\Desktop" (for /f "usebackq delims=" %%b in (`dir /b /a:-s "%SystemDrive%\Users\%%a\OneDrive\Desktop"`) do (echo No|move /-Y "%SystemDrive%\Users\%%a\OneDrive\Desktop\%%b" "%SystemDrive%\Users\%%a\Desktop" >> "%LOG_PATH%" 2>&1))
                    if exist "%SystemDrive%\Users\%%a\OneDrive\Documents" (for /f "usebackq delims=" %%b in (`dir /b /a:-s "%SystemDrive%\Users\%%a\OneDrive\Documents"`) do (echo No|move /-Y "%SystemDrive%\Users\%%a\OneDrive\Documents\%%b" "%SystemDrive%\Users\%%a\Documents" >> "%LOG_PATH%" 2>&1))
                    if exist "%SystemDrive%\Users\%%a\OneDrive\Pictures" (for /f "usebackq delims=" %%b in (`dir /b /a:-s "%SystemDrive%\Users\%%a\OneDrive\Pictures"`) do (echo No|move /-Y "%SystemDrive%\Users\%%a\OneDrive\Pictures\%%b" "%SystemDrive%\Users\%%a\Pictures" >> "%LOG_PATH%" 2>&1))
                    if exist "%SystemDrive%\Users\%%a\OneDrive\Videos" (for /f "usebackq delims=" %%b in (`dir /b /a:-s "%SystemDrive%\Users\%%a\OneDrive\Videos"`) do (echo No|move /-Y "%SystemDrive%\Users\%%a\OneDrive\Videos\%%b" "%SystemDrive%\Users\%%a\Videos" >> "%LOG_PATH%" 2>&1))
                    if exist "%SystemDrive%\Users\%%a\OneDrive\Music" (for /f "usebackq delims=" %%b in (`dir /b /a:-s "%SystemDrive%\Users\%%a\OneDrive\Music"`) do (echo No|move /-Y "%SystemDrive%\Users\%%a\OneDrive\Music\%%b" "%SystemDrive%\Users\%%a\Music" >> "%LOG_PATH%" 2>&1))
                    if exist "%SystemDrive%\Users\%%a\OneDrive\Desktop" dir /b /a:-s "%SystemDrive%\Users\%%a\OneDrive\Desktop" | findstr /R /c:"." >> "%LOG_PATH%" 2>&1 || rmdir /q /s "%SystemDrive%\Users\%%a\OneDrive\Desktop" >> "%LOG_PATH%" 2>&1
                    if exist "%SystemDrive%\Users\%%a\OneDrive\Documents" dir /b /a:-s "%SystemDrive%\Users\%%a\OneDrive\Documents" | findstr /R /c:"." >> "%LOG_PATH%" 2>&1 || rmdir /q /s "%SystemDrive%\Users\%%a\OneDrive\Documents" >> "%LOG_PATH%" 2>&1
                    if exist "%SystemDrive%\Users\%%a\OneDrive\Pictures" dir /b /a:-s "%SystemDrive%\Users\%%a\OneDrive\Pictures" | findstr /R /c:"." >> "%LOG_PATH%" 2>&1 || rmdir /q /s "%SystemDrive%\Users\%%a\OneDrive\Pictures" >> "%LOG_PATH%" 2>&1
                    if exist "%SystemDrive%\Users\%%a\OneDrive\Videos" dir /b /a:-s "%SystemDrive%\Users\%%a\OneDrive\Videos" | findstr /R /c:"." >> "%LOG_PATH%" 2>&1 || rmdir /q /s "%SystemDrive%\Users\%%a\OneDrive\Videos" >> "%LOG_PATH%" 2>&1
                    if exist "%SystemDrive%\Users\%%a\OneDrive\Music" dir /b /a:-s "%SystemDrive%\Users\%%a\OneDrive\Music" | findstr /R /c:"." >> "%LOG_PATH%" 2>&1 || rmdir /q /s "%SystemDrive%\Users\%%a\OneDrive\Music" >> "%LOG_PATH%" 2>&1
                    del /q /f "%SystemDrive%\Users\%%a\OneDrive\Personal Vault.lnk" >> "%LOG_PATH%" 2>&1
                    for /f "usebackq delims=" %%b in (`dir /b /a:-s "%SystemDrive%\Users\%%a\OneDrive" ^| findstr /V /X /c:"Desktop" /c:"Documents" /c:"Pictures" /c:"Videos" /c:"Music"`) do (
                        if not exist "%SystemDrive%\Users\%%a\Desktop\OneDriveFiles" mkdir "%SystemDrive%\Users\%%a\Desktop\OneDriveFiles" >> "%LOG_PATH%" 2>&1
                        echo No|move /-Y "%SystemDrive%\Users\%%a\OneDrive\%%b" "%SystemDrive%\Users\%%a\Desktop\OneDriveFiles" >> "%LOG_PATH%" 2>&1
                    )
                    dir /b /a:-s "%SystemDrive%\Users\%%a\OneDrive" | findstr /R /c:"." >> "%LOG_PATH%" 2>&1 || rmdir /q /s "%SystemDrive%\Users\%%a\OneDrive" >> "%LOG_PATH%" 2>&1
                )
                robocopy "%USERPROFILE%\OneDrive" "%USERPROFILE%" /mov /e /xj /ndl /nfl /njh /njs /nc /ns /np >> "%LOG_PATH%" 2>&1
                rd /s /q "%USERPROFILE%\OneDrive" >> "%LOG_PATH%" 2>&1
                rd /s /q "%LOCALAPPDATA%\OneDrive" >> "%LOG_PATH%" 2>&1
                rd /s /q "%LOCALAPPDATA%\Microsoft\OneDrive" >> "%LOG_PATH%" 2>&1
                rd /s /q "%ProgramData%\Microsoft OneDrive" >> "%LOG_PATH%" 2>&1
                rd /s /q "%SystemDrive%\OneDriveTemp" >> "%LOG_PATH%" 2>&1
                del /f /q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\OneDrive.lnk" >> "%LOG_PATH%" 2>&1
                for /f "usebackq delims=" %%e in (`reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\SyncRootManager" ^| findstr /i /c:"OneDrive"`) do reg delete "%%e" /f >> "%LOG_PATH%" 2>&1
                reg add "HKU\.DEFAULT\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce" /v "HideOneDriveExplorer" /t REG_SZ /d "reg add HKCU\Software\Classes\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6} /v System.IsPinnedToNameSpaceTree /t REG_DWORD /d 0 /f" /f >> "%LOG_PATH%" 2>&1
                reg add "HKU\.DEFAULT\Software\Classes\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}" /v "System.IsPinnedToNameSpaceTree" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\OneDrive" /v "DisableFileSyncNGSC" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\OneDrive" /v "KFMBlockOptIn" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\OneDrive" /v "DisableFileSync" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\OneDrive" /v "DisableFileSyncNGSC" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\OneDrive" /v "DisablePersonalSync" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\OneDrive" /v "DisableLibrariesDefaultSaveToOneDrive" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\OneDrive" /v "PreventOneDriveInstalls" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\OneDrive" /v "DisableNetworkFileSync" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\OneDrive" /v "DisableMeteredNetworkFileSync" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\OneDrive" /v "PreventNetworkTrafficPreUserSignIn" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg load HKU\Default "C:\Users\Default\NTUSER.DAT" >> "%LOG_PATH%" 2>&1
                if not errorlevel 1 (
                    reg delete "HKU\Default\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v OneDriveSetup /f >> "%LOG_PATH%" 2>&1
                    reg unload HKU\Default >> "%LOG_PATH%" 2>&1
                )
                set "USER_SID=%~1"
                for /f "usebackq delims=" %%e in (`reg query "HKU\%USER_SID%\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\BannerStore" ^| findstr /i /c:"OneDrive"` 2^>nul) do reg delete "%%e" /f >> "%LOG_PATH%" 2>&1
                for /f "usebackq delims=" %%e in (`reg query "HKU\%USER_SID%\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\AutoplayHandlers\Handlers" ^| findstr /i /c:"OneDrive"` 2^>nul) do reg delete "%%e" /f >> "%LOG_PATH%" 2>&1
                for /f "usebackq delims=" %%e in (`reg query "HKU\%USER_SID%\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths" ^| findstr /i /c:"OneDrive"` 2^>nul) do reg delete "%%e" /f >> "%LOG_PATH%" 2>&1
                for /f "usebackq delims=" %%e in (`reg query "HKU\%USER_SID%\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall" ^| findstr /i /c:"OneDrive"` 2^>nul) do reg delete "%%e" /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Debloat Microsoft Edge",
            "Closes Microsoft Edge, disables its telemetry, ads, suggestions, sidebar and startup boost, and clears its cache folders.",
            CmdService.Script("""
                taskkill /F /IM msedge.exe >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v EdgeEnhanceImagesEnabled /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v PersonalizationReportingEnabled /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v MetricsReportingEnabled /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v DiagnosticData /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v HubsSidebarEnabled /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v EdgeShoppingAssistantEnabled /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v SearchSuggestEnabled /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v WebWidgetAllowed /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v SyncDisabled /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v BrowserSignin /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v SendSiteInfoToImproveServices /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v AlternateErrorPagesEnabled /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v HideFirstRunExperience /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v BackgroundModeEnabled /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v ShowRecommendationsEnabled /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v SpotlightExperiencesAndRecommendationsEnabled /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v PromotionalTabsEnabled /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v NewTabPageHideDefaultTopSites /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v ShowMicrosoftRewards /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v MicrosoftEdgeInsiderPromotionEnabled /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v StartupBoostEnabled /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v EdgeAssetDeliveryServiceEnabled /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v UserFeedbackAllowed /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                set "EDGE_USER=%LOCALAPPDATA%\Microsoft\Edge\User Data"
                if exist "%EDGE_USER%" (
                    for /d %%P in ("%EDGE_USER%\*") do (
                        if exist "%%P\Cache" rd /s /q "%%P\Cache"
                        if exist "%%P\Code Cache" rd /s /q "%%P\Code Cache"
                        if exist "%%P\GPUCache" rd /s /q "%%P\GPUCache"
                    )
                )
                """)),

        TweakFactory.Ready("Debloat Google Chrome",
            "Closes Google Chrome, disables its telemetry, background mode, notifications, media router and popups/sensor permissions, and clears its cache folders.",
            CmdService.Script("""
                taskkill /F /IM chrome.exe >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v MetricsReportingEnabled /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v DeviceMetricsReportingEnabled /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v UserFeedbackAllowed /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v BackgroundModeEnabled /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v PromotionalTabsEnabled /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v ShowRecommendationsEnabled /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v NetworkPredictionOptions /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v ChromeCleanupEnabled /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v ChromeCleanupReportingEnabled /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v SafeBrowsingProtectionLevel /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v EnableMediaRouter /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v ShowCastIconInToolbar /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v SafeBrowsingExtendedReportingEnabled /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v DefaultPopupsSetting /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v DefaultSensorsSetting /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v DefaultSerialGuardSetting /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v DefaultWebBluetoothGuardSetting /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v DefaultWebUsbGuardSetting /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                set "CHROME_USER=%LOCALAPPDATA%\Google\Chrome\User Data"
                if exist "%CHROME_USER%" (
                    for /d %%P in ("%CHROME_USER%\*") do (
                        if exist "%%P\Cache" rd /s /q "%%P\Cache"
                        if exist "%%P\Code Cache" rd /s /q "%%P\Code Cache"
                        if exist "%%P\GPUCache" rd /s /q "%%P\GPUCache"
                    )
                )
                """)),

        TweakFactory.Ready("Debloat Brave",
            "Closes Brave, disables its VPN, wallet, AI chat, rewards, news, talk, sidebar and telemetry, hides sponsored images, and clears its cache folders.",
            CmdService.Script("""
                taskkill /F /IM brave.exe >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BraveVPNDisabled" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BraveWalletDisabled" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BraveAIChatEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BraveRewardsDisabled" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BraveTalkDisabled" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BraveNewsDisabled" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BraveLabsEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BraveSidebarEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "MetricsReportingEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "SafeBrowsingExtendedReportingEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\Software\Policies\BraveSoftware\Brave" /v "NewTabPageShowBackgroundImage" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "NewTabPageShowSponsoredImages" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                set "BRAVE_USER=%LOCALAPPDATA%\BraveSoftware\Brave-Browser\User Data"
                if exist "%BRAVE_USER%" (
                    for /d %%P in ("%BRAVE_USER%\*") do (
                        if exist "%%P\Cache" rd /s /q "%%P\Cache"
                        if exist "%%P\Code Cache" rd /s /q "%%P\Code Cache"
                        if exist "%%P\GPUCache" rd /s /q "%%P\GPUCache"
                    )
                )
                """)),
    };

    public DebloatView()
    {
        InitializeComponent();
        Panel.TweakItems = TweakItems;
    }
}
