using System.Collections.ObjectModel;
using System.Windows.Controls;
using NvrxPCTweakingUtility.Models;
using NvrxPCTweakingUtility.Services;

namespace NvrxPCTweakingUtility.Views;

public partial class KbmView : UserControl
{
    public ObservableCollection<TweakItem> TweakItems { get; } = new()
    {
        TweakFactory.Ready("Disable USB Power Savings",
            "Turns off USB selective suspend, power management and wake-on-device settings, and disables wake capability for input devices to cut input latency.",
            CmdService.Script("""
                reg add "HKLM\SYSTEM\CurrentControlSet\Services\usb" /v DisableSelectiveSuspend /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\usb\Usb20HardwareLpm" /v Usb20HardwareLpmOverride /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\usb\UsbLtm" /v UsbLtmEnable /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                powershell -NoProfile -Command "Get-WmiObject Win32_USBHub | ForEach-Object { $p='HKLM:\SYSTEM\CurrentControlSet\Enum\'+$_.DeviceID+'\Device Parameters'; if(Test-Path $p){Set-ItemProperty $p 'EnhancedPowerManagementEnabled' 0 -EA SilentlyContinue} }" >> "%LOG_PATH%" 2>&1
                powershell -NoProfile -Command "Get-PnpDevice | Where-Object {$_.Class -eq 'USB' -and $_.FriendlyName -like '*xHCI*'} | ForEach-Object { $p='HKLM:\SYSTEM\CurrentControlSet\Enum\'+$_.InstanceId+'\Device Parameters\WDF'; if(!(Test-Path $p)){New-Item $p -Force|Out-Null}; Set-ItemProperty $p 'IdleInD3' 0 -EA SilentlyContinue }" >> "%LOG_PATH%" 2>&1
                powershell -NoProfile -Command "$controllers=Get-CimInstance Win32_USBController; foreach($c in $controllers){$p='HKLM:\SYSTEM\CurrentControlSet\Enum\'+$c.PNPDeviceID; New-Item -Path ($p+'\Device Parameters\Interrupt Management\MessageSignaledInterruptProperties') -Force|Out-Null; New-Item -Path ($p+'\Device Parameters\Interrupt Management\Affinity Policy') -Force|Out-Null; Set-ItemProperty -Path ($p+'\Device Parameters\Interrupt Management\MessageSignaledInterruptProperties') -Name MSISupported -Type DWord -Value 1 -EA SilentlyContinue; New-ItemProperty -Path ($p+'\Device Parameters\Interrupt Management\Affinity Policy') -Name DevicePriority -PropertyType String -Value '' -Force -EA SilentlyContinue|Out-Null}" >> "%LOG_PATH%" 2>&1
                for %%a in (
                    EnhancedPowerManagementEnabled
                    AllowIdleIrpInD3
                    EnableSelectiveSuspend
                    DeviceSelectiveSuspended
                    SelectiveSuspendEnabled
                    SelectiveSuspendOn
                    EnumerationRetryCount
                    ExtPropDescSemaphore
                    WaitWakeEnabled
                    D3ColdSupported
                    WdfDirectedPowerTransitionEnable
                    EnableIdlePowerManagement
                    IdleInWorkingState
                ) do (
                    for /f "delims=" %%b in ('reg query "HKLM\SYSTEM\CurrentControlSet\Enum" /s /f "%%a" 2^>nul ^| findstr /i "HKEY"') do (
                        reg add "%%b" /v "%%a" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                    )
                )
                powershell -NoProfile -Command "$cutoff = (Get-Date).AddDays(-30); Get-PnpDevice | Where-Object { $_.Present -eq $false } | ForEach-Object { $d = $_ | Get-PnpDeviceProperty -KeyName DEVPKEY_Device_LastArrivalDate -ErrorAction SilentlyContinue; if (-not $d.Data -or $d.Data -lt $cutoff) { pnputil /remove-device $d.InstanceId } }" >> "%LOG_PATH%" 2>&1
                for /f "tokens=*" %%I in ('powercfg /devicequery wake_armed') do (
                    powercfg /devicedisablewake "%%I" >> "%LOG_PATH%" 2>&1
                )
                for /f "tokens=*" %%I in ('powercfg /devicequery wake_programmable') do (
                    powercfg /devicedisablewake "%%I" >> "%LOG_PATH%" 2>&1
                )
                powershell -NoProfile -Command "$devices=Get-CimInstance Win32_PnPEntity -Property PNPDeviceID,Name | Where-Object PNPDeviceID; $powerList=Get-CimInstance -Namespace root\wmi -ClassName MSPower_DeviceEnable -ErrorAction SilentlyContinue; if($powerList){ foreach($power in $powerList){ $instance=$power.InstanceName -replace '_\d+$',''; $match=$devices | Where-Object { $instance -match ([regex]::Escape($_.PNPDeviceID)) } | Select-Object -First 1; if($match -and $power.Enable){ Set-CimInstance -InputObject $power -Property @{Enable=$false} -ErrorAction SilentlyContinue } } }" >> "%LOG_PATH%" 2>&1
                powershell -NoProfile -Command "Get-CimInstance -Namespace root\wmi -ClassName MSPower_DeviceWakeEnable -ErrorAction SilentlyContinue | Where-Object { $_.Enable } | ForEach-Object { Set-CimInstance -InputObject $_ -Property @{Enable=$false} -ErrorAction SilentlyContinue }" >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Disable Mouse Acceleration",
            "Removes Windows pointer acceleration and enhances pointer precision so mouse movement maps 1:1 to your hand for raw, predictable aiming.",
            CmdService.Script("""
                reg add "HKCU\Control Panel\Mouse" /v MouseSpeed /t REG_SZ /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\Mouse" /v MouseThreshold1 /t REG_SZ /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\Mouse" /v MouseThreshold2 /t REG_SZ /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\Mouse" /v MouseSensitivity /t REG_SZ /d "10" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\Mouse" /v MouseTrails /t REG_SZ /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\Mouse" /v "RawMouseThrottleDuration" /t REG_DWORD /d 20 /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Apply Some Keyboard Tweaks",
            "Maximizes keyboard repeat speed, removes key delay, and enables the Scroll Lock indicator for snappier, more responsive typing.",
            CmdService.Script("""
                reg add "HKCU\Control Panel\Keyboard" /v KeyboardDelay /t REG_SZ /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\Keyboard" /v KeyboardSpeed /t REG_SZ /d "31" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\Keyboard" /v InitialKeyboardIndicators /t REG_SZ /d "2" /f >> "%LOG_PATH%" 2>&1
                reg add "HKEY_USERS\.DEFAULT\Control Panel\Keyboard" /v InitialKeyboardIndicators /t REG_SZ /d "2" /f >> "%LOG_PATH%" 2>&1
                reg add "HKEY_USERS\.DEFAULT\Control Panel\Keyboard" /v KeyboardDelay /t REG_SZ /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKEY_USERS\.DEFAULT\Control Panel\Keyboard" /v KeyboardSpeed /t REG_SZ /d "31" /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Disable Accessibility Settings",
            "Disables Windows accessibility filters such as Filter Keys, Sticky Keys, Toggle Keys and fast-key acceptance delays that can interfere with fast repeated input.",
            CmdService.Script("""
                reg add "HKCU\Control Panel\Accessibility\MouseKeys" /v "Flags" /t REG_SZ /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\Accessibility\StickyKeys" /v "Flags" /t REG_SZ /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\Accessibility\ToggleKeys" /v "Flags" /t REG_SZ /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\Accessibility\Keyboard Response" /v "Flags" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\Accessibility\Keyboard Response" /v "DelayBeforeAcceptance" /t REG_SZ /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\Accessibility\Keyboard Response" /v "Last BounceKey Setting" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\Accessibility\Keyboard Response" /v "Last Valid Delay" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\Accessibility\Keyboard Response" /v "Last Valid Repeat" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\Accessibility\Keyboard Response" /v "Last Valid Wait" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Disable IMOD (EXPERIMENTAL)",
            "EXPERIMENTAL - disables IMOD (inverse measures-of-disorder / kernel timing) detection. This can falsely trigger some anti-cheats. Downloads the IMOD disabler and installs it to run at startup.",
            CmdService.Script("""
                mkdir "C:\Nvrx\Disable IMOD" 2>nul
                curl -s -L "https://www.dropbox.com/scl/fi/xye15x8015zu2jfifmsi3/Disable_IMOD.zip?rlkey=xsib8xq15n2xvbrix40v15ze5&st=1nj3ej21&dl=1" -o "C:\Nvrx\Disable_IMOD.zip"
                if exist "C:\Nvrx\Disable_IMOD.zip" tar -xf "C:\Nvrx\Disable_IMOD.zip" -C "C:\Nvrx\Disable IMOD" & del /q "C:\Nvrx\Disable_IMOD.zip"
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "IMOD Disabler" /t REG_SZ /d "C:\Nvrx\Disable IMOD\IMOD.exe" /f >> "%LOG_PATH%" 2>&1
                """)),
    };

    public KbmView()
    {
        InitializeComponent();
        Panel.TweakItems = TweakItems;
    }
}