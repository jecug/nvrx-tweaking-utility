using System.Collections.ObjectModel;
using System.Windows.Controls;
using NvrxPCTweakingUtility.Models;
using NvrxPCTweakingUtility.Services;

namespace NvrxPCTweakingUtility.Views;

public partial class WindowsView : UserControl
{
    public ObservableCollection<TweakItem> TweakItems { get; } = new()
    {
        TweakFactory.Ready("Disable Unwanted Telemetry",
            "Blocks telemetry/analytics hosts in the HOSTS file and disables diagnostic data collection, feedback, input personalization and online speech/data-collection services to improve privacy.",
            CmdService.Script("""
                set "HOSTS_FILE=%WINDIR%\System32\drivers\etc\hosts"
                >> "%HOSTS_FILE%" echo.
                >> "%HOSTS_FILE%" echo # Brave telemetry
                >> "%HOSTS_FILE%" echo 0.0.0.0 p2a-json.brave.com
                >> "%HOSTS_FILE%" echo 0.0.0.0 p2a.brave.com
                >> "%HOSTS_FILE%" echo 0.0.0.0 p3a-json.brave.com
                >> "%HOSTS_FILE%" echo 0.0.0.0 p3a.brave.com
                >> "%HOSTS_FILE%" echo 0.0.0.0 star-randsrv.bsg.brave.com
                >> "%HOSTS_FILE%" echo.
                >> "%HOSTS_FILE%" echo # Mozilla telemetry
                >> "%HOSTS_FILE%" echo 0.0.0.0 incoming.telemetry.mozilla.org
                >> "%HOSTS_FILE%" echo 0.0.0.0 telemetry.mozilla.org
                >> "%HOSTS_FILE%" echo.
                >> "%HOSTS_FILE%" echo # Google advertising / analytics
                >> "%HOSTS_FILE%" echo 0.0.0.0 adservice.google.com
                >> "%HOSTS_FILE%" echo 0.0.0.0 adservice.google.pl
                >> "%HOSTS_FILE%" echo 0.0.0.0 pagead2.googlesyndication.com
                >> "%HOSTS_FILE%" echo 0.0.0.0 ssl.google-analytics.com
                >> "%HOSTS_FILE%" echo 0.0.0.0 stats.g.doubleclick.net
                >> "%HOSTS_FILE%" echo 0.0.0.0 www.google-analytics.com
                >> "%HOSTS_FILE%" echo.
                >> "%HOSTS_FILE%" echo # Microsoft telemetry
                >> "%HOSTS_FILE%" echo 0.0.0.0 eu-v10c.events.data.microsoft.com
                >> "%HOSTS_FILE%" echo 0.0.0.0 functional.events.data.microsoft.com
                >> "%HOSTS_FILE%" echo 0.0.0.0 self.events.data.microsoft.com
                >> "%HOSTS_FILE%" echo 0.0.0.0 telecommand.telemetry.microsoft.com
                >> "%HOSTS_FILE%" echo 0.0.0.0 us-v10c.events.data.microsoft.com
                >> "%HOSTS_FILE%" echo 0.0.0.0 v10.events.data.microsoft.com
                >> "%HOSTS_FILE%" echo 0.0.0.0 v10.vortex-win.data.microsoft.com
                >> "%HOSTS_FILE%" echo 0.0.0.0 v10c.events.data.microsoft.com
                >> "%HOSTS_FILE%" echo 0.0.0.0 vortex-win.data.microsoft.com
                >> "%HOSTS_FILE%" echo.
                >> "%HOSTS_FILE%" echo # Optional Microsoft advertising
                >> "%HOSTS_FILE%" echo 0.0.0.0 c.bing.com
                >> "%HOSTS_FILE%" echo 0.0.0.0 business.bing.com
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v "POWERSHELL_TELEMETRY_OPTOUT" /t REG_SZ /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\International\User Profile" /v "HttpAcceptLanguageOptOut" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Siuf\Rules" /v "NumberOfSIUFInPeriod" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Siuf\Rules" /v "PeriodInNanoSeconds" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v "DoNotShowFeedbackNotifications" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Privacy" /v "TailoredExperiencesWithDiagnosticDataEnabled" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection" /v "AllowTelemetry" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v "AllowTelemetry" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v "DisableCommercialDataOptIn" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Input" /v "InputServiceEnabled" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Input" /v "InputServiceEnabledForCCI" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Speech_OneCore\Preferences" /v "ModelDownloadAllowed" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Speech_OneCore\Preferences" /v "UserProfileEnabled" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Speech_OneCore\Settings\OnlineSpeechPrivacy" /v "HasAccepted" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Speech_OneCore\Settings\OnlineSpeechPrivacy" /v "Status" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\TextInput" /v "EnablePredictionInsight" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Input\Settings" /v "InsightsEnabled" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Input\Settings" /v "InputPersonalizationTips" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\InputPersonalization" /v "RestrictImplicitTextCollection" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\InputPersonalization" /v "RestrictImplicitInkCollection" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\InputPersonalization\TrainedDataStore" /v "HarvestContacts" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Input\TIPC" /v "Enabled" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\WindowsInkWorkspace" /v "AllowWindowsInkWorkspace" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\PenWorkspace" /v "PenWorkspaceAppSuggestionsEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\DefaultPressure" /v "Disable" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\TabletPC" /v "PreventHandwritingDataSharing" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\TextInput" /v "AllowLinguisticDataCollection" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\Maps" /v "AutoUpdateEnabled" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Sensor\Overrides\{BFA794E4-F964-4FDB-90F6-51056BFE4B44}" /v "SensorPermissionState" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\sensors" /v "Value" /t REG_SZ /d "Deny" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location" /v "Value" /t REG_SZ /d "Deny" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\SettingSync" /v "DisableSyncOnPaidNetwork" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\SearchSettings" /v "IsMSACloudSearchEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\SearchSettings" /v "IsAADCloudSearchEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\SearchSettings" /v "IsDynamicSearchBoxEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v "PublishUserActivities" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v "EnableActivityFeed" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v "UploadUserActivities" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v "AllowCrossDeviceClipboard" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\settingSync" /v "SyncPolicy" /t REG_DWORD /d 5 /f
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\settingSync\Groups\Accessibility" /v "Enabled" /t REG_DWORD /d 0 /f
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\settingSync\Groups\AppSync" /v "Enabled" /t REG_DWORD /d 0 /f
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\settingSync\Groups\Browsersettings" /v "Enabled" /t REG_DWORD /d 0 /f
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\settingSync\Groups\Credentials" /v "Enabled" /t REG_DWORD /d 0 /f
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\settingSync\Groups\DesktopTheme" /v "Enabled" /t REG_DWORD /d 0 /f
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\settingSync\Groups\Language" /v "Enabled" /t REG_DWORD /d 0 /f
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\settingSync\Groups\PackageState" /v "Enabled" /t REG_DWORD /d 0 /f
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\settingSync\Groups\Personalization" /v "Enabled" /t REG_DWORD /d 0 /f
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\settingSync\Groups\StartLayout" /v "Enabled" /t REG_DWORD /d 0 /f
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\settingSync\Groups\Windows" /v "Enabled" /t REG_DWORD /d 0 /f
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisablesettingSync" /t REG_DWORD /d 2 /f
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisablesettingSyncUserOverride" /t REG_DWORD /d 1 /f
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableAppSyncsettingSync" /t REG_DWORD /d 2 /f
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableAppSyncsettingSyncUserOverride" /t REG_DWORD /d 1 /f
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableApplicationsettingSync" /t REG_DWORD /d 2 /f
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableApplicationsettingSyncUserOverride" /t REG_DWORD /d 1 /f
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableCredentialssettingSync" /t REG_DWORD /d 2 /f
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableCredentialssettingSyncUserOverride" /t REG_DWORD /d 1 /f
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableDesktopThemesettingSync" /t REG_DWORD /d 2 /f
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableDesktopThemesettingSyncUserOverride" /t REG_DWORD /d 1 /f
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisablePersonalizationsettingSync" /t REG_DWORD /d 2 /f
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisablePersonalizationsettingSyncUserOverride" /t REG_DWORD /d 1 /f
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableStartLayoutsettingSync" /t REG_DWORD /d 2 /f
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableStartLayoutsettingSyncUserOverride" /t REG_DWORD /d 1 /f
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableSyncOnPaidNetwork" /t REG_DWORD /d 1 /f
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableWebBrowsersettingSync" /t REG_DWORD /d 2 /f
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableWebBrowsersettingSyncUserOverride" /t REG_DWORD /d 1 /f
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableWindowssettingSync" /t REG_DWORD /d 2 /f
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableWindowssettingSyncUserOverride" /t REG_DWORD /d 1 /f
                reg add "HKLM\SOFTWARE\Microsoft\SQMClient\Windows" /v "CEIPEnable" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\SQMClient\Windows" /v "DisableOptinExperience" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\SQMClient\Windows" /v "SqmLoggerRunning" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppCompat" /v "DisablePCA" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppCompat" /v "DisableInventory" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppCompat" /v "AITEnable" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\AppModel" /v "Start" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\CimFSUnionFS-Filter" /v "Start" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\CloudExperienceHostOobe" /v "Start" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DataMarket" /v "Start" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\Diagtrack-Listener" /v "Start" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\FaceTel" /v "Start" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\HolographicDevice" /v "Start" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\Microsoft-Windows-AssignedAccess-Trace" /v "Start" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\Mellanox-Kernel" /v "Start" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\NBSMBLOGGER" /v "Start" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\RefSLog" /v "Start" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\SetupPlatformTel" /v "Start" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\SQMLogger" /v "Start" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\TileStore" /v "Start" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\AutoLogger-Diagtrack-Listener" /v "Start" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\AutoLogger-SQMLogger" /v "Start" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WUDF" /v "LogEnable" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WUDF" /v "LogLevel" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\Lsa\Credssp" /v "DebugLogLevel" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\Software\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Application-Experience/Steps-Recorder" /v "Enabled" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Policies\Microsoft\Assistance\Client\1.0" /v "NoExplicitFeedback" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Assistance\Client\1.0\Settings" /v "ImplicitFeedback" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\current\device\System" /v "AllowExperimentation" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\System\AllowExperimentation" /v "value" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\FindMyDevice" /v "AllowFindMyDevice" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Maps" /v "AllowUntriggeredNetworkTrafficOnSettingsPage" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Maps" /v "AutoDownloadAndUpdateMapData" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo" /v "Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\CloudExperienceHost\Intent\creative" /v "Intent" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\CloudExperienceHost\Intent\entertainment" /v "Intent" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\CloudExperienceHost\Intent\family" /v "Intent" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\CloudExperienceHost\Intent\gaming" /v "Intent" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\CloudExperienceHost\Intent\schoolwork" /v "Intent" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\CloudExperienceHost\Intent\business" /v "Intent" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\CloudExperienceHost\Intent\development" /v "Intent" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Policies\Microsoft\Windows\AdvertisingInfo" /v "DisabledByGroupPolicy" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AdvertisingInfo" /v "DisabledByGroupPolicy" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack" /v "ShowSharedDiagnosticLogs" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableSoftLanding" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent" /v "DisableWindowsConsumerFeatures" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent" /v "DisableConsumerAccountStateContent" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Device Metadata" /v "PreventDeviceMetadataFromNetwork" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v "DisableDiagnosticDataViewer" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Personalization\Settings" /v "AcceptedPrivacyPolicy" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\InputPersonalization" /v "AllowInputPersonalization" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CDP" /v "CdpSessionUserAuthzPolicy" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CDP" /v "NearShareChannelUserAuthzPolicy" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\WindowsSelfHost\UI\Visibility" /v "DiagnosticErrorText" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\WindowsSelfHost\UI\Strings" /v "DiagnosticErrorText" /t REG_SZ /d "" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\WindowsSelfHost\UI\Strings" /v "DiagnosticLinkText" /t REG_SZ /d "" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppCompat" /v "DisableUAR" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Personalization" /v "NoLockScreenCamera" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\AdvertisingInfo" /v "Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors" /v "DisableWindowsLocationProvider" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors" /v "DisableLocationScripting" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors" /v "DisableLocation" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Biometrics" /v "Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Apply Windows Customization Tweaks",
            "Declutters the Start menu, taskbar, search and File Explorer: hides recommended/ads/people, disables OneDrive and web search, enables dark theme and speeds up window/menu behaviour.",
            CmdService.Script("""
                del /f /q "%AppData%\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar*" >nul 2>&1
                reg add "HKEY_CLASSES_ROOT\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}" /v "System.IsPinnedToNameSpaceTree" /t REG_DWORD /d 0 /f
                reg delete "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "OneDrive" /f >nul 2>&1
                for /f "tokens=1" %%a in ('reg query "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" ^| findstr /i "MicrosoftEdgeAutoLaunch"') do (
                  reg delete "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "%%a" /f >nul 2>&1
                )
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Explorer" /v "HideRecommendedSection" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "Start_AccountNotifications" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "Start_TrackProgs" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\FlyoutMenuSettings" /v "ShowHibernateOption" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\FlyoutMenuSettings" /v "ShowLockOption" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\FlyoutMenuSettings" /v "ShowSleepOption" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "TaskbarChat" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Chat" /v "ChatIcon" /t REG_DWORD /d 3 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "HidePeopleBar" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\People" /v "PeopleBand" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "DisallowShaking" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "NoWorkingOnIt" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "SharingWizardOn" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg delete "HKCR\*\shellex\ContextMenuHandlers\ModernSharing" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Start\Companions\Microsoft.YourPhone_8wekyb3d8bbwe" /v "IsEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Appx" /v "AllowAutomaticAppArchiving" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\CrossDeviceResume\Configuration" /v "IsResumeAllowed" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\FileHistory" /v "Disabled" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\FileHistory" /v "Disabled" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "HideSCAHealth" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "ExtendedUIHoverTime" /t REG_DWORD /d "196608" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "DontPrettyPath" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "NoLowDiskSpaceChecks" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "NoInternetOpenWith" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "NoInstrumentation" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "EnableBalloonTips" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "HideSCAMeetNow" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Feeds" /v "ShellFeedsTaskbarViewMode" /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "ShowSyncProviderNotifications" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\Desktop" /v "JPEGImportQuality" /t REG_DWORD /d "100" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search" /v "AllowCloudSearch" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search" /v "AllowSearchToUseLocation" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Explorer" /v "DisableSearchBoxSuggestions" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Search" /v "BingSearchEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\SearchSettings" /v "IsCloudContentEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search" /v "DisableWebSearch" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search" /v "ConnectedSearchUseWeb" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search" /v "EnableSemanticIndexing" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Explorer" /v "DisableAIActions" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\SearchSettings" /v "SafeSearchMode" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\SearchSettings" /v "LanguageFeatures" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\SearchSettings" /v "HashesReported" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\SearchSettings" /v "CloudSearchControl" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" /v "ShowFrequent" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" /v "ShowRecent" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" /v "TelemetrySalt" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "Start_Layout" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "LaunchTo" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "HideFileExt" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "Hidden" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Start" /v "ShowRecentList" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "Start_TrackDocs" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "EnableSnapAssistFlyout" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "Start_TrackPrograms" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\TaskbarFlashing" /v "SystemSettings_DesktopTaskbar_Flashing" /t REG_SZ /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "ShowBatteryPercentage" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "TaskbarAl" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "NoRecentDocsHistory" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\TaskbarDa" /v "SystemSettings_DesktopTaskbar_Da" /t REG_SZ /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "NoStartMenuMorePrograms" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "DisablePreviewWindow" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "HideSCAMeetNow" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "TaskbarMn" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "TaskbarDa" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "Start_IrisRecommendations" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Policies\Microsoft\Windows\Windows Feeds" /v "EnableFeeds" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\NewsAndInterests" /v "AllowNewsAndInterests" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Dsh" /v "AllowNewsAndInterests" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\Accessibility" /v "DynamicScrollbars" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\Keyboard" /v "InitialKeyboardIndicators" /t REG_SZ /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "AllowOnlineTips" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Settings\AllowOnlineTips" /v "value" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg delete "HKCU\Software\Microsoft\Office\16.0\Outlook\Options\General" /v "HideNewOutlookToggle" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "IconsOnly" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Personalization" /v "NoLockScreen" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v "DisableLogonBackgroundImage" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\Desktop" /v "AutoEndTasks" /t REG_SZ /d 1 /f
                reg add "HKCU\Control Panel\Desktop" /v "HungAppTimeout" /t REG_SZ /d 1500 /f
                reg add "HKCU\Control Panel\Desktop" /v "WaitToKillTimeout" /t REG_SZ /d 2500 /f
                reg add "HKCU\Control Panel\Desktop" /v "WaitToKillAppTimeout" /t REG_SZ /d "2000" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\Desktop" /v "MenuShowDelay" /t REG_SZ /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control" /v "WaitToKillServiceTimeout" /t REG_SZ /d 2500 /f
                reg add "HKLM\System\CurrentControlSet\Control\CrashControl" /v "DisplayParameters" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v "VerboseStatus" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}" /ve /d "" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32" /ve /d "" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\SmartActionPlatform" /v "SmartActionsEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\TaskbarDeveloperSettings" /v "TaskbarEndTask" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Classes\CLSID\{f874310e-b6b7-47dc-bc84-b9e6b38f5903}" /v "System.IsPinnedToNameSpaceTree" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Classes\CLSID\{e88865ea-0e1c-4e20-9aa6-edcd0212c87c}" /v "System.IsPinnedToNameSpaceTree" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Classes\CLSID\{d3162b92-9365-467a-956b-92703aca08af}" /v "System.IsPinnedToNameSpaceTree" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Classes\CLSID\{3dfdf296-dbec-4fb4-81d1-6a3438bcf4de}" /v "System.IsPinnedToNameSpaceTree" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Classes\CLSID\{0DB7E03F-FC29-4DC6-9020-FF41B59E513A}" /v "System.IsPinnedToNameSpaceTree" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Classes\CLSID\{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}" /v "System.IsPinnedToNameSpaceTree" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKU\default\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "LaunchTo" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "ContentDeliveryAllowed" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "FeatureManagementEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContentEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "OemPreInstalledAppsEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "PreInstalledAppsEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "PreInstalledAppsEverEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SilentInstalledAppsEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SoftLandingEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SystemPaneSuggestionsEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "ShowSyncProviderNotifications" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "RotatingLockScreenEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "RotatingLockScreenOverlayEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-310093Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-310101Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-310102Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-314559Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-314563Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-314566Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-314567Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338380Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338381Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338382Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338386Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338387Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338388Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338389Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338393Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338394Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-353694Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-353696Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-353697Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-353698Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-353699Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-353702Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-353703Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-353704Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-353711Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableWindowsSpotlightWindowsWelcomeExperience" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableWindowsSpotlightOnActionCenter" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableWindowsSpotlightOnSettings" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableWindowsSpotlightFeatures" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Policies\Microsoft\Windows\CloudContent" /v "ConfigureWindowsSpotlight" /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableWindowsSpotlightWindowsWelcomeExperience" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableWindowsSpotlightOnActionCenter" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableWindowsSpotlightOnSettings" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableWindowsSpotlightFeatures" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\Software\Policies\Microsoft\Windows\CloudContent" /v "ConfigureWindowsSpotlight" /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\StorageSense" /v "AllowStorageSenseGlobal" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableThirdPartySuggestions" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableSoftLanding" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableCloudOptimizedContent" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableWebExperience" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "SettingsPageVisibility" /t REG_SZ /d "hide:home" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v "AppsUseLightTheme" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v "AppsUseLightTheme" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\microsoft.microsoftedge_8wekyb3d8bbwe\MicrosoftEdge\Main" /v "Theme" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\DirectX\UserGpuPreferences" /v "DirectXUserGlobalSettings" /t REG_SZ /d "SwapEffectUpgradeEnable=1;" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v "EnableTransparency" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v "SystemUsesLightTheme" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" /v "VisualFXSetting" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\DWM" /v "EnableBlurBehind" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "TaskbarAnimations" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\Desktop\WindowMetrics" /v "MinAnimate" /t REG_SZ /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\Desktop" /v "DragFullWindows" /t REG_SZ /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\Desktop" /v "FontSmoothing" /t REG_SZ /d "2" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\Desktop" /v "FontSmoothingType" /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Control Panel\Desktop" /v "UserPreferencesMask" /t REG_BINARY /d 9e3e078012000000 /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Apply Gaming Optimizations",
            "Disables Game Bar/DVR capture overhead and enables Hardware-Accelerated GPU Scheduling (HAGS), plus raises the TDR timeout to prevent GPU driver timeouts during demanding games.",
            CmdService.Script("""
                reg add "HKLM\SOFTWARE\Microsoft\WindowsRuntime\ActivatableClassId\Windows.Gaming.GameBar.PresenceServer.Internal.PresenceWriter" /v "ActivationType" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR" /v "AllowGameDVR" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR" /v "AppCaptureEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v "AppCaptureEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\GameBar" /v "AllowAutoGameMode" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\GameBar" /v "GamePanelStartupTipIndex" /t REG_DWORD /d 3 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\ApplicationManagement\AllowGameDVR" /v "value" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\System\GameConfigStore" /v "GameDVR_Enabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\System\GameConfigStore" /v "GameDVR_FSEBehavior" /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\System\GameConfigStore" /v "GameDVR_FSEBehaviorMode" /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\System\GameConfigStore" /v "GameDVR_HonorUserFSEBehaviorMode" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\System\GameConfigStore" /v "GameDVR_DXGIHonorFSEWindowsCompatible" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\System\GameConfigStore" /v "GameDVR_EFSEFeatureFlags" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\GameBar" /v "ShowStartupPanel" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\GameBar" /v "UseNexusForGameBarEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\SOFTWARE\Microsoft\GameBar" /v "AutoGameModeEnabled" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR" /v "AutoGameModeEnabled" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v "HwSchMode" /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                reg delete "HKLM\SOFTWARE\Microsoft\Windows\Dwm" /v "OverlayTestMode" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v "TdrDelay" /t REG_DWORD /d 8 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v "TdrDdiDelay" /t REG_DWORD /d 8 /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("Configure Windows Update",
            "Controls Windows Update behaviour: stops automatic driver delivery from Windows Update, disables automatic reboots and blocks preview/insider builds for a more stable system.",
            CmdService.Script("""
                reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\current\device\Update" /v "ExcludeWUDriversInQualityUpdate" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Update" /v "ExcludeWUDriversInQualityUpdate" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v "ExcludeWUDriversInQualityUpdate" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v "ExcludeWUDriversInQualityUpdate" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Update\ExcludeWUDriversInQualityUpdate" /v "value" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Device Metadata" /v "PreventDeviceMetadataFromNetwork" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching" /v "SearchOrderConfig" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching" /v "DontSearchWindowsUpdate" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" /v "NoAutoUpdate" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" /v "NoAutoRebootWithLoggedOnUsers" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v "AUPowerManagement" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization" /v "DODownloadMode" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\WindowsStore" /v "AutoDownload" /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\PreviewBuilds" /v "AllowBuildPreview" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\PreviewBuilds" /v "EnableConfigFlighting" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\PreviewBuilds" /v "EnableExperimentation" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v "ManagePreviewBuilds" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v "ManagePreviewBuildsPolicyValue" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v "InsiderProgramEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\DriverSearching" /v "SearchOrderConfig" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\DriverSearching" /v "DontSearchWindowsUpdate" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\DriverSearching" /v "DriverUpdateWizardWuSearchEnabled" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                """)),

        TweakFactory.Ready("More Great Windows Tweaks",
            "Applies NTFS/filesystem optimizations, speeds up startup, disables background apps, restores legacy file-type associations (ps1/txt/bat), adds desktop context-menu shortcuts and a 'Run as TrustedInstaller' right-click menu.",
            CmdService.Script("""
                fsutil 8dot3name set 1 >> "%LOG_PATH%" 2>&1
                fsutil behavior set disablelastaccess 1 >> "%LOG_PATH%" 2>&1
                fsutil behavior set encryptpagingfile 0 >> "%LOG_PATH%" 2>&1
                fsutil behavior set DisableDeleteNotify 0 >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\BitLocker" /v "PreventDeviceEncryption" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Microsoft Edge" /v "NoRemove" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control" /v "SvcHostSplitThresholdInKB" /t REG_DWORD /d 3670016 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\PowerShell\1\ShellIds\Microsoft.PowerShell" /v "ExecutionPolicy" /t REG_SZ /d "Unrestricted" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\Software\Policies\Microsoft\Windows\PowerShell" /v "ExecutionPolicy" /t REG_SZ /d "Unrestricted" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\Software\Policies\Microsoft\Windows\PowerShell" /v "EnableScripts" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                powershell -Command "Get-ChildItem -Path '%NVRX_UTILITY_DIR%' -Recurse -ErrorAction SilentlyContinue | Unblock-File" >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v "DisableAutomaticRestartSignOn" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v "DelayedDesktopSwitchTimeout" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Serialize" /v "StartupDelayInMSec" /t REG_DWORD /d "0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\FileSystem" /v "LongPathsEnabled" /t REG_DWORD /d "1" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\current\device\Education" /v "IsEducationEnvironment" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Messaging" /v "AllowMessageSync" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Device Installer" /v "DisableCoInstallers" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance" /v "MaintenanceDisabled" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control" /v "WaitToKillServiceTimeout" /t REG_SZ /d "2000" /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager" /v "DisableWpbtExecution" /t REG_DWORD /d 0 /f >> "%LOG_PATH%" 2>&1
                reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" /v "GlobalUserDisabled" /t REG_DWORD /d 1 /f >> "%LOG_PATH%" 2>&1
                reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsRunInBackground" /t REG_DWORD /d 2 /f >> "%LOG_PATH%" 2>&1
                reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsRunInBackground_UserInControlOfTheseApps" /f >> "%LOG_PATH%" 2>&1
                reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsRunInBackground_ForceAllowTheseApps" /f >> "%LOG_PATH%" 2>&1
                reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsRunInBackground_ForceDenyTheseApps" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCR\.ps1" /ve /t REG_SZ /d "ps1legacy" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCR\.ps1\ShellNew" /v "NullFile" /t REG_SZ /d "" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCR\ps1legacy" /ve /t REG_SZ /d "pwsh" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCR\ps1legacy" /v "FriendlyTypeName" /t REG_SZ /d "pwsh" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCR\.txt" /ve /t REG_SZ /d "txtlegacy" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCR\.txt\ShellNew" /v "NullFile" /t REG_SZ /d "" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCR\txtlegacy" /ve /t REG_SZ /d "txt" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCR\txtlegacy" /v "FriendlyTypeName" /t REG_SZ /d "txt" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCR\.bat" /ve /t REG_SZ /d "batfile" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCR\.bat\ShellNew" /v "NullFile" /t REG_SZ /d "" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCR\batfile" /ve /t REG_SZ /d "bat" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCR\batfile" /v "FriendlyTypeName" /t REG_SZ /d "bat" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCR\DesktopBackground\Shell\MSInfo" /ve /t REG_SZ /d "MSInfo Shortcut" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCR\DesktopBackground\Shell\MSInfo" /v "Icon" /t REG_SZ /d "msinfo32.exe,0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCR\DesktopBackground\Shell\MSInfo\command" /ve /t REG_SZ /d "msinfo32.exe" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCR\DesktopBackground\Shell\BIOSReboot" /ve /t REG_SZ /d "BIOS Shortcut" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCR\DesktopBackground\Shell\BIOSReboot" /v "Icon" /t REG_SZ /d "shell32.dll,238" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCR\DesktopBackground\Shell\BIOSReboot" /v "HasLUAShield" /t REG_SZ /d "" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCR\DesktopBackground\Shell\PowerShellLegacy" /ve /t REG_SZ /d "PowerShell Shortcut" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCR\DesktopBackground\Shell\PowerShellLegacy" /v "Icon" /t REG_SZ /d "powershell.exe,0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCR\DesktopBackground\Shell\TextLegacy" /ve /t REG_SZ /d "Text Shortcut" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCR\DesktopBackground\Shell\TextLegacy" /v "Icon" /t REG_SZ /d "notepad.exe,0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCR\DesktopBackground\Shell\BatchLegacy" /ve /t REG_SZ /d "Batch Shortcut" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCR\DesktopBackground\Shell\BatchLegacy" /v "Icon" /t REG_SZ /d "cmd.exe,0" /f >> "%LOG_PATH%" 2>&1
                reg add "HKCR\batfile\shell\setdesktopwallpaper" /v "MUIVerb" /t REG_SZ /d "Run as TrustedInstaller" /f
                reg add "HKCR\batfile\shell\setdesktopwallpaper" /v "HasLUAShield" /t REG_SZ /d "" /f
                reg add "HKCR\batfile\shell\setdesktopwallpaper" /v "Icon" /t REG_SZ /d "powershell.exe,0" /f
                reg add "HKCR\batfile\shell\setdesktopwallpaper\command" /v "" /t REG_SZ /d "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe -win 1 -nop -c iex((10..40|%%{(gp 'Registry::HKCR\RunAsTI' $_ -ea 0).$_})-join[char]10); # --%% \"%%L\"" /f
                reg add "HKCR\cmdfile\shell\setdesktopwallpaper" /v "MUIVerb" /t REG_SZ /d "Run as TrustedInstaller" /f
                reg add "HKCR\cmdfile\shell\setdesktopwallpaper" /v "HasLUAShield" /t REG_SZ /d "" /f
                reg add "HKCR\cmdfile\shell\setdesktopwallpaper" /v "Icon" /t REG_SZ /d "powershell.exe,0" /f
                reg add "HKCR\cmdfile\shell\setdesktopwallpaper\command" /v "" /t REG_SZ /d "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe -win 1 -nop -c iex((10..40|%%{(gp 'Registry::HKCR\RunAsTI' $_ -ea 0).$_})-join[char]10); # --%% \"%%L\"" /f
                reg add "HKCR\exefile\shell\setdesktopwallpaper" /v "MUIVerb" /t REG_SZ /d "Run as TrustedInstaller" /f
                reg add "HKCR\exefile\shell\setdesktopwallpaper" /v "HasLUAShield" /t REG_SZ /d "" /f
                reg add "HKCR\exefile\shell\setdesktopwallpaper" /v "Icon" /t REG_SZ /d "powershell.exe,0" /f
                reg add "HKCR\exefile\shell\setdesktopwallpaper\command" /v "" /t REG_SZ /d "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe -win 1 -nop -c iex((10..40|%%{(gp 'Registry::HKCR\RunAsTI' $_ -ea 0).$_})-join[char]10); # --%% \"%%L\"" /f
                reg add "HKCR\mscfile\shell\setdesktopwallpaper" /v "MUIVerb" /t REG_SZ /d "Run as TrustedInstaller" /f
                reg add "HKCR\mscfile\shell\setdesktopwallpaper" /v "HasLUAShield" /t REG_SZ /d "" /f
                reg add "HKCR\mscfile\shell\setdesktopwallpaper" /v "Icon" /t REG_SZ /d "powershell.exe,0" /f
                reg add "HKCR\mscfile\shell\setdesktopwallpaper\command" /v "" /t REG_SZ /d "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe -win 1 -nop -c iex((10..40|%%{(gp 'Registry::HKCR\RunAsTI' $_ -ea 0).$_})-join[char]10); # --%% \"%%L\"" /f
                reg add "HKCR\Microsoft.PowerShellScript.1\shell\setdesktopwallpaper" /v "MUIVerb" /t REG_SZ /d "Run as TrustedInstaller" /f
                reg add "HKCR\Microsoft.PowerShellScript.1\shell\setdesktopwallpaper" /v "HasLUAShield" /t REG_SZ /d "" /f
                reg add "HKCR\Microsoft.PowerShellScript.1\shell\setdesktopwallpaper" /v "Icon" /t REG_SZ /d "powershell.exe,0" /f
                reg add "HKCR\Microsoft.PowerShellScript.1\shell\setdesktopwallpaper\command" /v "" /t REG_SZ /d "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe -win 1 -nop -c iex((10..40|%%{(gp 'Registry::HKCR\RunAsTI' $_ -ea 0).$_})-join[char]10); # --%% powershell -nop -c iex((gc -lit '%%L')-join[char]10)" /f
                reg add "HKCR\regfile\shell\setdesktopwallpaper" /v "MUIVerb" /t REG_SZ /d "Import as TrustedInstaller" /f
                reg add "HKCR\regfile\shell\setdesktopwallpaper" /v "HasLUAShield" /t REG_SZ /d "" /f
                reg add "HKCR\regfile\shell\setdesktopwallpaper" /v "Icon" /t REG_SZ /d "powershell.exe,0" /f
                reg add "HKCR\regfile\shell\setdesktopwallpaper\command" /v "" /t REG_SZ /d "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe -win 1 -nop -c iex((10..40|%%{(gp 'Registry::HKCR\RunAsTI' $_ -ea 0).$_})-join[char]10); # --%% regedit /s \"%%L\"" /f
                reg add "HKCR\Folder\shell\setdesktopwallpaper" /v "MuiVerb" /t REG_SZ /d "Open as TrustedInstaller" /f
                reg add "HKCR\Folder\shell\setdesktopwallpaper" /v "HasLUAShield" /t REG_SZ /d "" /f
                reg add "HKCR\Folder\shell\setdesktopwallpaper" /v "Icon" /t REG_SZ /d "powershell.exe,0" /f
                reg add "HKCR\Folder\shell\setdesktopwallpaper" /v "AppliesTo" /t REG_SZ /d "NOT System.ParsingName:=\"::{645FF040-5081-101B-9F08-00AA002F954E}\"" /f
                reg add "HKCR\Folder\shell\setdesktopwallpaper\command" /v "" /t REG_SZ /d "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe -win 1 -nop -c iex((10..40|%%{(gp 'Registry::HKCR\RunAsTI' $_ -ea 0).$_})-join[char]10); # --%% \"%%L\"" /f
                reg add "HKCR\RunAsTI" /v "10" /t REG_SZ /d "function RunAsTI ($cmd,$arg) { $id='RunAsTI'; $key=\"Registry::HKU\\$(((whoami /user)-split' ')[-1])\\Volatile Environment\"; $code=@'" /f
                reg add "HKCR\RunAsTI" /v "11" /t REG_SZ /d " $I=[int32]; $M=$I.module.gettype(\"System.Runtime.Interop`Services.Mar`shal\"); $P=$I.module.gettype(\"System.Int`Ptr\"); $S=[string]" /f
                reg add "HKCR\RunAsTI" /v "12" /t REG_SZ /d " $D=@(); $T=@(); $DM=[AppDomain]::CurrentDomain.\"DefineDynami`cAssembly\"(1,1).\"DefineDynami`cModule\"(1); $Z=[uintptr]::size " /f
                reg add "HKCR\RunAsTI" /v "13" /t REG_SZ /d " 0..5|%% {$D += $DM.\"Defin`eType\"(\"AveYo_$_\",1179913,[ValueType])}; $D += [uintptr]; 4..6|%% {$D += $D[$_].\"MakeByR`efType\"()}" /f
                reg add "HKCR\RunAsTI" /v "14" /t REG_SZ /d " $F='kernel','advapi','advapi', ($S,$S,$I,$I,$I,$I,$I,$S,$D[7],$D[8]), ([uintptr],$S,$I,$I,$D[9]),([uintptr],$S,$I,$I,[byte[]],$I)" /f
                reg add "HKCR\RunAsTI" /v "15" /t REG_SZ /d " 0..2|%% {$9=$D[0].\"DefinePInvok`eMethod\"(('CreateProcess','RegOpenKeyEx','RegSetValueEx')[$_],$F[$_]+'32',8214,1,$S,$F[$_+3],1,4)}" /f
                reg add "HKCR\RunAsTI" /v "16" /t REG_SZ /d " $DF=($P,$I,$P),($I,$I,$I,$I,$P,$D[1]),($I,$S,$S,$S,$I,$I,$I,$I,$I,$I,$I,$I,[int16],[int16],$P,$P,$P,$P),($D[3],$P),($P,$P,$I,$I)" /f
                reg add "HKCR\RunAsTI" /v "17" /t REG_SZ /d " 1..5|%% {$k=$_; $n=1; $DF[$_-1]|%% {$9=$D[$k].\"Defin`eField\"('f' + $n++, $_, 6)}}; 0..5|%% {$T += $D[$_].\"Creat`eType\"()}" /f
                reg add "HKCR\RunAsTI" /v "18" /t REG_SZ /d " 0..5|%% {nv \"A$_\" ([Activator]::CreateInstance($T[$_])) -fo}; function F ($1,$2) {$T[0].\"G`etMethod\"($1).invoke(0,$2)}" /f
                reg add "HKCR\RunAsTI" /v "19" /t REG_SZ /d " $TI=(whoami /groups)-like'*1-16-16384*'; $As=0; if(!$cmd) {$cmd='control';$arg='admintools'}; if ($cmd-eq'This PC'){$cmd='file:'}" /f
                reg add "HKCR\RunAsTI" /v "20" /t REG_SZ /d " if (!$TI) {'TrustedInstaller','lsass','winlogon'|%% {if (!$As) {$9=sc.exe start $_; $As=@(get-process -name $_ -ea 0|%% {$_})[0]}}" /f
                reg add "HKCR\RunAsTI" /v "21" /t REG_SZ /d " function M ($1,$2,$3) {$M.\"G`etMethod\"($1,[type[]]$2).invoke(0,$3)}; $H=@(); $Z,(4*$Z+16)|%% {$H += M \"AllocHG`lobal\" $I $_}" /f
                reg add "HKCR\RunAsTI" /v "22" /t REG_SZ /d " M \"WriteInt`Ptr\" ($P,$P) ($H[0],$As.Handle); $A1.f1=131072; $A1.f2=$Z; $A1.f3=$H[0]; $A2.f1=1; $A2.f2=1; $A2.f3=1; $A2.f4=1" /f
                reg add "HKCR\RunAsTI" /v "23" /t REG_SZ /d " $A2.f6=$A1; $A3.f1=10*$Z+32; $A4.f1=$A3; $A4.f2=$H[1]; M \"StructureTo`Ptr\" ($D[2],$P,[boolean]) (($A2 -as $D[2]),$A4.f2,$false)" /f
                reg add "HKCR\RunAsTI" /v "24" /t REG_SZ /d " $Run=@($null, \"powershell -win 1 -nop -c iex `$env:R; # $id\", 0, 0, 0, 0x0E080600, 0, $null, ($A4 -as $T[4]), ($A5 -as $T[5]))" /f
                reg add "HKCR\RunAsTI" /v "25" /t REG_SZ /d " F 'CreateProcess' $Run; return}; $env:R=''; rp $key $id -force; $priv=[diagnostics.process].\"GetM`ember\"('SetPrivilege',42)[0]" /f
                reg add "HKCR\RunAsTI" /v "26" /t REG_SZ /d " 'SeSecurityPrivilege','SeTakeOwnershipPrivilege','SeBackupPrivilege','SeRestorePrivilege' |%% {$priv.Invoke($null, @(\"$_\",2))}" /f
                reg add "HKCR\RunAsTI" /v "27" /t REG_SZ /d " $HKU=[uintptr][uint32]2147483651; $NT='S-1-5-18'; $reg=($HKU,$NT,8,2,($HKU -as $D[9])); F 'RegOpenKeyEx' $reg; $LNK=$reg[4]" /f
                reg add "HKCR\RunAsTI" /v "28" /t REG_SZ /d " function L ($1,$2,$3) {sp 'Registry::HKCR\\AppID\\{CDCBCFCA-3CDC-436f-A4E2-0E02075250C2}' 'RunAs' $3 -force -ea 0" /f
                reg add "HKCR\RunAsTI" /v "29" /t REG_SZ /d "  $b=[Text.Encoding]::Unicode.GetBytes(\"\\Registry\\User\\$1\"); F 'RegSetValueEx' @($2,'SymbolicLinkValue',0,6,[byte[]]$b,$b.Length)}" /f
                reg add "HKCR\RunAsTI" /v "30" /t REG_SZ /d " function Q {[int](gwmi win32_process -filter 'name=\"explorer.exe\"'|?{$_.getownersid().sid-eq$NT}|select -last 1).ProcessId}" /f
                reg add "HKCR\RunAsTI" /v "31" /t REG_SZ /d " $env:wt='powershell'; dir \"$env:ProgramFiles\\WindowsApps\\Microsoft.WindowsTerminal*\\wt.exe\" -rec|%% {$env:wt='\"'+$_.FullName+'\" \"-d .\"'}" /f
                reg add "HKCR\RunAsTI" /v "32" /t REG_SZ /d " $11bug=($((gwmi Win32_OperatingSystem).BuildNumber)-eq'22000')-AND(($cmd-eq'file:')-OR(test-path -lit $cmd -PathType Container))" /f
                reg add "HKCR\RunAsTI" /v "33" /t REG_SZ /d " if ($11bug) {'System.Windows.Forms','Microsoft.VisualBasic' |%% {$9=[Reflection.Assembly]::LoadWithPartialName(\"'$_\")}}" /f
                reg add "HKCR\RunAsTI" /v "34" /t REG_SZ /d " if ($11bug) {$path='^(l)'+$($cmd -replace '([\\+\\^\\%\\~\\(\\)\\[\\]])','{$1}')+'{ENTER}'; $cmd='control.exe'; $arg='admintools'}" /f
                reg add "HKCR\RunAsTI" /v "35" /t REG_SZ /d " L ($key-split'\\\\')[1] $LNK ''; $R=[diagnostics.process]::start($cmd,$arg); if ($R) {$R.PriorityClass='High'; $R.WaitForExit()}" /f
                reg add "HKCR\RunAsTI" /v "36" /t REG_SZ /d " if ($11bug) {$w=0; do {if($w-gt40){break}; sleep -mi 250;$w++} until (Q); [Microsoft.VisualBasic.Interaction]::AppActivate($(Q))}" /f
                reg add "HKCR\RunAsTI" /v "37" /t REG_SZ /d " if ($11bug) {[Windows.Forms.SendKeys]::SendWait($path)}; do {sleep 7} while(Q); L '.Default' $LNK 'Interactive User'" /f
                reg add "HKCR\RunAsTI" /v "38" /t REG_SZ /d "'@; $V='';'cmd','arg','id','key'|%%{$V+=\"`n`$$_='$($(gv $_ -val)-replace\"'\",\"''\")';\"}; sp $key $id $($V,$code) -type 7 -force -ea 0" /f
                reg add "HKCR\RunAsTI" /v "39" /t REG_SZ /d " start powershell -args \"-win 1 -nop -c `n$V `$env:R=(gi `$key -ea 0).getvalue(`$id)-join''; iex `$env:R\" -verb runas" /f
                reg add "HKCR\RunAsTI" /v "40" /t REG_SZ /d "}; $A=([environment]::commandline-split'-[-]%%+ ?',2)[1]-split'\"([^\"]+)\"|([^ ]+)',2|%%{$_.Trim(' \"')}; RunAsTI $A[1] $A[2]" /f
                reg add "HKCR\DESKTOP" /ve /t REG_SZ /d "Desktop" /f >> "%LOG_PATH%" 2>&1
                """)),
    };

    public WindowsView()
    {
        InitializeComponent();
        Panel.TweakItems = TweakItems;
    }
}