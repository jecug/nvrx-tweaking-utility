using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NvrxPCTweakingUtility.Models;
using NvrxPCTweakingUtility.Services;

namespace NvrxPCTweakingUtility.Views;

public partial class DashboardView : UserControl, INotifyPropertyChanged
{
    private string _osName = "Loading...";
    private string _osDetail = string.Empty;
    private string _cpuName = "Loading...";
    private string _cpuDetail = string.Empty;
    private string _ramText = "Loading...";
    private string _gpuName = "Loading...";
    private string _gpuDetail = string.Empty;

    public DashboardView()
    {
        InitializeComponent();
        DataContext = this;
        LogPathHint = $"Log file: {LogService.Instance.LogPath}";
        Loaded += OnLoaded;
    }

    public string LogPathHint { get; }

    public string OsName { get => _osName; set { _osName = value; OnPropertyChanged(); } }
    public string OsDetail { get => _osDetail; set { _osDetail = value; OnPropertyChanged(); } }
    public string CpuName { get => _cpuName; set { _cpuName = value; OnPropertyChanged(); } }
    public string CpuDetail { get => _cpuDetail; set { _cpuDetail = value; OnPropertyChanged(); } }
    public string RamText { get => _ramText; set { _ramText = value; OnPropertyChanged(); } }
    public string GpuName { get => _gpuName; set { _gpuName = value; OnPropertyChanged(); } }
    public string GpuDetail { get => _gpuDetail; set { _gpuDetail = value; OnPropertyChanged(); } }

    private async void OnLoaded(object sender, RoutedEventArgs e)
    {
        Loaded -= OnLoaded;
        var info = await SystemInfoService.LoadAsync();

        OsName = info.OsName;
        var version = string.IsNullOrEmpty(info.OsDisplay) ? string.Empty : $"Version {info.OsDisplay}  ·  ";
        OsDetail = $"{version}Build {info.OsBuild}  ·  {info.Architecture}";
        CpuName = info.CpuName;
        CpuDetail = $"{info.LogicalCores} logical cores  ·  ~{info.CpuSpeedMhz} MHz";
        RamText = $"{info.TotalRamGb} GB";
        GpuName = info.GpuName;
        GpuDetail = $"Driver {info.GpuDriver}";
    }

    private async void OnQuickAction(object sender, RoutedEventArgs e)
    {
        var button = sender as Button;

        string name;
        if (button?.Content is StackPanel sp &&
            sp.Children.OfType<TextBlock>().LastOrDefault() is { } tb)
        {
            name = tb.Text;
        }
        else
        {
            name = button?.Content as string ?? "Quick action";
        }

        button.IsEnabled = false;
        try
        {
            await RunQuick(name);
        }
        finally
        {
            button.IsEnabled = true;
        }
    }

    private async Task RunQuick(string name)
    {
        if (!ElevationHelper.IsAdministrator)
        {
            LogService.Instance.Error($"{name} requires administrator privileges.");
            MessageBox.Show("Administrator privileges required.",
                "Nvrx PC Tweaking Utility", MessageBoxButton.OK, MessageBoxImage.Error);
            return;
        }

        var command = QuickActions.TryGetValue(name, out var script) ? script : null;
        if (command is null)
        {
            LogService.Instance.Warn($"Quick action not implemented yet: {name}");
            return;
        }

        LogService.Instance.Info($"> {name}");
        bool ok;
        try
        {
            ok = await Task.Run(() => CmdService.RunBatch(command));
        }
        catch (Exception ex)
        {
            LogService.Instance.Error($"  {name} error: {ex.Message}");
            ok = false;
        }

        LogService.Instance.Write($"  {(ok ? "OK" : "FAILED")}: {name}",
            ok ? LogLevel.Success : LogLevel.Error);
        MessageBox.Show(ok ? "Finished!" : "Failed!",
            "Nvrx PC Tweaking Utility", MessageBoxButton.OK,
            ok ? MessageBoxImage.Information : MessageBoxImage.Error);
    }

    private static Dictionary<string, string> QuickActions { get; } = new()
    {
        ["Apply Disk Cleanup"] = DiskCleanupScript,
        ["Activate Windows"] = ActivateWindowsScript,
        ["Create System Restore Point"] = RestorePointScript,
        ["Install Important Runtimes"] = RuntimesScript,
        ["Restore Corrupted System Files"] = RestoreFilesScript,
    };

    private const string DiskCleanupScript = """
        powershell -NoProfile -Command "$RegPath = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches'; $SageID = 'StateFlags0099'; $cats = @('Active Setup Temp Folders','DownloadsFolder','BranchCache','Content Indexer Cleaner','D3D Shader Cache','Delivery Optimization Files','Device Driver Packages','Diagnostic Data Viewer database files','Downloaded Program Files','Feedback Hub Archive log files','GameNewsFiles','GameStatisticsFiles','GameUpdateFiles','Internet Cache Files','Language Pack','Memory Dump Files','Offline Pages Files','Old ChkDsk Files','Previous Installations','Recycle Bin','RetailDemo Offline Content','Service Pack Cleanup','Setup Log Files','System error memory dump files','System error minidump files','Temporary Files','Temporary Setup Files','Temporary Sync Files','Thumbnail Cache','Update Cleanup','Upgrade Discarded Files','User file versions','Windows Defender','Windows Error Reporting Archive Files','Windows Error Reporting Files','Windows Error Reporting Queue Files','Windows Error Reporting System Archive Files','Windows Error Reporting System Queue Files','Windows Error Reporting Temp Files','Windows ESD installation files','Windows Upgrade Log Files','Windows Reset Log Files'); foreach ($cat in $cats) { $p = Join-Path $RegPath $cat; if (Test-Path $p) { Set-ItemProperty -Path $p -Name $SageID -Type DWORD -Value 2 -Force -EA SilentlyContinue } }"
        start /wait cleanmgr /sagerun:99
        timeout /t 2 /nobreak >> "%LOG_PATH%" 2>&1
        """;

    private const string ActivateWindowsScript = """
        echo In opened script press "1" on your keyboard and wait
        echo Press on any key after "Press any key to Go back..." text appears
        echo Press "0" on your keyboard to close MAS
        powershell -NoProfile -ExecutionPolicy Bypass -Command "iex (curl.exe -s --doh-url https://1.1.1.1/dns-query https://get.activated.win | Out-String)"
        """;

    private const string RestorePointScript = """
        echo In the opened window click on "Configure"
        echo In new window enable system protection and set max usage to 7 percent
        echo And click on "Apply" and "OK", now click on "Create"
        echo Name it "Before Nvrx PC Tweaking Utility" and click on "Create"
        echo Wait it until Windows creates system restore point and after that click on "Close"
        start "" /wait SystemPropertiesProtection
        """;

    private const string RuntimesScript = """
        powershell -NoProfile -Command "if (-not (Test-NetConnection -ComputerName 'builds.dotnet.microsoft.com' -Port 443 -InformationLevel Quiet)) { exit 1 }"
        if errorlevel 1 (
            echo Network connection check failed. >> "%LOG_PATH%" 2>&1
            exit /b 1
        )
        set "DownloadDir=C:\Nvrx\Important Runtimes"
        if not exist "%DownloadDir%" (
            mkdir "%DownloadDir%" || (
                echo Failed to create download directory. >> "%LOG_PATH%" 2>&1
                exit /b 1
            )
        )
        set "URL_DotnetRuntime9=https://builds.dotnet.microsoft.com/dotnet/Runtime/9.0.8/dotnet-runtime-9.0.8-win-x64.exe"
        set "URL_DotnetSDK9=https://builds.dotnet.microsoft.com/dotnet/Sdk/9.0.304/dotnet-sdk-9.0.304-win-x64.exe"
        set "URL_WinDesktopRuntime8=https://download.visualstudio.microsoft.com/download/pr/fc8c9dea-8180-4dad-bf1b-5f229cf47477/c3f0536639ab40f1470b6bad5e1b95b8/windowsdesktop-runtime-8.0.13-win-x64.exe"
        set "URL_VCRedistAIO=https://www.dropbox.com/scl/fi/boyrchap95ty2jrvmn76l/Visual-C-Runtimes-All-in-One-Jun-2026.zip?rlkey=z888z6tv9wcdbq1giizuhtfhs&st=7eehjpl4&dl=1"
        set "URL_DirectX=https://download.microsoft.com/download/1/7/1/1718CCC4-6315-4D8E-9543-8E28A4E18C4C/dxwebsetup.exe"
        powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13; Invoke-WebRequest -Uri '%URL_DotnetRuntime9%' -OutFile '%DownloadDir%\dotnet-runtime-9.0.8-win-x64.exe' -UseBasicParsing" >> "%LOG_PATH%" 2>&1
        powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13; Invoke-WebRequest -Uri '%URL_DotnetSDK9%' -OutFile '%DownloadDir%\dotnet-sdk-9.0.304-win-x64.exe' -UseBasicParsing" >> "%LOG_PATH%" 2>&1
        powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13; Invoke-WebRequest -Uri '%URL_WinDesktopRuntime8%' -OutFile '%DownloadDir%\windowsdesktop-runtime-8.0.13-win-x64.exe' -UseBasicParsing" >> "%LOG_PATH%" 2>&1
        powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13; Invoke-WebRequest -Uri '%URL_VCRedistAIO%' -OutFile '%DownloadDir%\Visual-C-Runtimes-All-in-One.zip' -UseBasicParsing" >> "%LOG_PATH%" 2>&1
        powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13; Invoke-WebRequest -Uri '%URL_DirectX%' -OutFile '%DownloadDir%\dxwebsetup.exe' -UseBasicParsing" >> "%LOG_PATH%" 2>&1
        if exist "%DownloadDir%\dotnet-runtime-9.0.8-win-x64.exe" (
            powershell -NoProfile -Command "$p = Start-Process '%DownloadDir%\dotnet-runtime-9.0.8-win-x64.exe' -ArgumentList '/passive /norestart' -PassThru; Wait-Process -Id $p.Id" >> "%LOG_PATH%" 2>&1
        )
        if exist "%DownloadDir%\dotnet-sdk-9.0.304-win-x64.exe" (
            powershell -NoProfile -Command "$p = Start-Process '%DownloadDir%\dotnet-sdk-9.0.304-win-x64.exe' -ArgumentList '/passive /norestart' -PassThru; Wait-Process -Id $p.Id" >> "%LOG_PATH%" 2>&1
        )
        if exist "%DownloadDir%\windowsdesktop-runtime-8.0.13-win-x64.exe" (
            powershell -NoProfile -Command "$p = Start-Process '%DownloadDir%\windowsdesktop-runtime-8.0.13-win-x64.exe' -ArgumentList '/passive /norestart' -PassThru; Wait-Process -Id $p.Id" >> "%LOG_PATH%" 2>&1
        )
        if exist "%DownloadDir%\Visual-C-Runtimes-All-in-One.zip" (
            if exist "%DownloadDir%\Visual-C-Runtimes-All-in-One" rmdir /s /q "%DownloadDir%\Visual-C-Runtimes-All-in-One"
            mkdir "%DownloadDir%\Visual-C-Runtimes-All-in-One"
            powershell -NoProfile -Command "Expand-Archive -Path '%DownloadDir%\Visual-C-Runtimes-All-in-One.zip' -DestinationPath '%DownloadDir%\Visual-C-Runtimes-All-in-One' -Force" >> "%LOG_PATH%" 2>&1
            del /f /q "%DownloadDir%\Visual-C-Runtimes-All-in-One.zip"
            if exist "%DownloadDir%\Visual-C-Runtimes-All-in-One\install_all.bat" (
                pushd "%DownloadDir%\Visual-C-Runtimes-All-in-One"
                cmd.exe /c "call install_all.bat" >> "%LOG_PATH%" 2>&1
                popd
            )
        )
        if exist "%DownloadDir%\dxwebsetup.exe" (
            powershell -NoProfile -Command "$p = Start-Process '%DownloadDir%\dxwebsetup.exe' -ArgumentList '/q' -PassThru; Wait-Process -Id $p.Id" >> "%LOG_PATH%" 2>&1
        )
        """;

    private const string RestoreFilesScript = """
        DISM /Online /Cleanup-Image /RestoreHealth
        sfc /scannow
        """;

    private void OnOpenLogFolder(object sender, RoutedEventArgs e)
    {
        try
        {
            Process.Start(new ProcessStartInfo("explorer.exe")
            {
                UseShellExecute = true,
                Arguments = $"/select,\"{LogService.Instance.LogPath}\"",
            });
        }
        catch (Exception ex)
        {
            LogService.Instance.Error($"Could not open log folder: {ex.Message}");
        }
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    private void OnPropertyChanged([CallerMemberName] string? name = null)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}