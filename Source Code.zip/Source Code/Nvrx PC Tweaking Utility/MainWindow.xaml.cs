using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using NvrxPCTweakingUtility.Models;
using NvrxPCTweakingUtility.Services;
using NvrxPCTweakingUtility.Views;

namespace NvrxPCTweakingUtility;

public partial class MainWindow : Window
{
    private readonly Dictionary<string, UserControl> _views = new();

    public ObservableCollection<LogEntry> LogEntries => LogService.Instance.Entries;

    public MainWindow()
    {
        InitializeComponent();
        DataContext = this;

        _views["Dashboard"] = new DashboardView();
        _views["CPU Optimization"] = new CpuView();
        _views["GPU Optimization"] = new GpuView();
        _views["Keyboard & Mouse"] = new KbmView();
        _views["Network"] = new NetworkView();
        _views["Windows"] = new WindowsView();
        _views["Debloat"] = new DebloatView();

        ContentHost.Content = _views["Dashboard"];

        LoadBrandIcons();

        AdminBadgeText.Text = ElevationHelper.IsAdministrator ? "ELEVATED" : "NOT ELEVATED";
        AdminBadgeText.Foreground = ElevationHelper.IsAdministrator
            ? System.Windows.Media.Brushes.White
            : System.Windows.Media.Brushes.Gray;

        LogService.Instance.StatusChanged += OnLogStatusChanged;
        LogCountText.Text = $"{LogEntries.Count} entries";
    }

    protected override void OnClosed(EventArgs e)
    {
        LogService.Instance.StatusChanged -= OnLogStatusChanged;
        base.OnClosed(e);
    }

    private void OnWindowLoaded(object sender, RoutedEventArgs e)
    {
        var fade = new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(260))
        {
            EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut }
        };
        BeginAnimation(OpacityProperty, fade);

        var grow = new DoubleAnimation(0.985, 1, TimeSpan.FromMilliseconds(340))
        {
            EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut }
        };
        RootScale.BeginAnimation(ScaleTransform.ScaleXProperty, grow);

        var growY = new DoubleAnimation(0.985, 1, TimeSpan.FromMilliseconds(340))
        {
            EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut }
        };
        RootScale.BeginAnimation(ScaleTransform.ScaleYProperty, growY);
    }

    private void OnLogStatusChanged(string _)
    {
        LogCountText.Text = $"{LogEntries.Count} entries";
        LogScroll?.ScrollToEnd();
    }

    private void LoadBrandIcons()
    {
        try
        {
            var info = Application.GetResourceStream(new Uri("pack://application:,,,/Assets/app.ico"));
            using var stream = info?.Stream;
            if (stream is null) return;

            var decoder = new IconBitmapDecoder(stream, BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.OnLoad);
            var frame = decoder.Frames.OrderByDescending(f => f.PixelWidth).FirstOrDefault();
            if (frame is null) return;
            if (frame.CanFreeze) frame.Freeze();

            TitleBrandImage.Source = frame;
            SideBrandImage.Source = frame;
        }
        catch
        {
        }
    }

    private void OnNavChecked(object sender, RoutedEventArgs e)
    {
        if (sender is RadioButton rb && rb.IsChecked == true && rb.Content is string key)
        {
            if (_views.TryGetValue(key, out var view))
            {
                ContentHost.Content = view;
                view.Opacity = 0;
                var fade = new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(180));
                view.BeginAnimation(UIElement.OpacityProperty, fade);
            }
        }
    }

    private const int WM_SYSCOMMAND = 0x0112;
    private const int SC_MAXIMIZE = 0xF030;
    private const int DWMWA_WINDOW_CORNER_PREFERENCE = 33;
    private const int DWMWCP_ROUND = 2;

    private HwndSource? _hwndSource;

    [System.Runtime.InteropServices.DllImport("dwmapi.dll")]
    private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int attrValue, int attrSize);

    protected override void OnSourceInitialized(EventArgs e)
    {
        base.OnSourceInitialized(e);
        _hwndSource = (HwndSource?)PresentationSource.FromVisual(this);
        _hwndSource?.AddHook(WndProc);

        if (_hwndSource is not null && Environment.OSVersion.Version.Build >= 22000)
        {
            var corner = DWMWCP_ROUND;
            _ = DwmSetWindowAttribute(_hwndSource.Handle, DWMWA_WINDOW_CORNER_PREFERENCE, ref corner, sizeof(int));
        }
    }

    private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
    {
        if (msg == WM_SYSCOMMAND && (wParam.ToInt32() & 0xFFF0) == SC_MAXIMIZE)
        {
            handled = true;
        }
        return IntPtr.Zero;
    }

    private void OnTitleBarMouseDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ChangedButton != MouseButton.Left) return;
        if (FindAncestor<Button>(e.OriginalSource as DependencyObject) is not null) return;

        DragMove();
    }

    private static T? FindAncestor<T>(DependencyObject? node) where T : DependencyObject
    {
        while (node is not null)
        {
            if (node is T match) return match;
            node = VisualTreeHelper.GetParent(node) ?? LogicalTreeHelper.GetParent(node);
        }
        return null;
    }

    private void OnMinimize(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;

    private void OnClose(object sender, RoutedEventArgs e) => Close();

    private void OnToggleLog(object sender, RoutedEventArgs e)
    {
        LogPanel.Visibility = LogPanel.Visibility == Visibility.Visible ? Visibility.Collapsed : Visibility.Visible;
        if (LogPanel.Visibility == Visibility.Visible)
            LogScroll?.ScrollToEnd();
    }

    private void OnClearLog(object sender, RoutedEventArgs e)
    {
        LogEntries.Clear();
        LogCountText.Text = "0 entries";
    }
}