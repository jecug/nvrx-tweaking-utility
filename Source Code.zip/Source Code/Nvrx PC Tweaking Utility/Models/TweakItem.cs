namespace NvrxPCTweakingUtility.Models;

public sealed class TweakItem
{
    public string Id { get; set; } = string.Empty;

    public string Title { get; set; } = string.Empty;

    public string Description { get; set; } = string.Empty;

    public bool IsPlaceholder { get; set; } = true;

    public Func<bool>? Execute { get; set; }

    public string Notice { get; set; } = string.Empty;
}
