namespace NvrxPCTweakingUtility.Models;

public static class TweakFactory
{
    public static TweakItem Create(string title, string description, string notice = "")
        => new()
        {
            Title = title,
            Description = description,
            IsPlaceholder = true,
            Notice = notice,
        };

    public static TweakItem Ready(string title, string description, Func<bool> execute)
        => new()
        {
            Title = title,
            Description = description,
            IsPlaceholder = false,
            Execute = execute,
        };
}
