using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using NvrxPCTweakingUtility.Models;

namespace NvrxPCTweakingUtility.Services;

public sealed class LogService
{
    public static LogService Instance { get; } = new();

    public ObservableCollection<LogEntry> Entries { get; } = new();

    public event Action<string>? StatusChanged;

    private readonly object _lock = new();
    private readonly string _logPath;

    private LogService()
    {
        _logPath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
            "Nvrx_Log.txt");

        try
        {
            File.WriteAllText(_logPath,
                $"Nvrx PC Tweaking Utility Log{Environment.NewLine}" +
                $"Date: {DateTime.Now:dd/MM/yyyy HH:mm:ss}{Environment.NewLine}" +
                $"------------------------------------------{Environment.NewLine}");
        }
        catch
        {
        }
    }

    public string LogPath => _logPath;

    public void Info(string message) => Write(message, LogLevel.Info);

    public void Success(string message) => Write(message, LogLevel.Success);

    public void Warn(string message) => Write(message, LogLevel.Warning);

    public void Error(string message) => Write(message, LogLevel.Error);

    public void Write(string message, LogLevel level = LogLevel.Info)
    {
        var entry = new LogEntry(DateTime.Now, level, message);

        lock (_lock)
        {
            try
            {
                File.AppendAllText(_logPath, $"[{entry.Timestamp:HH:mm:ss}] {message}{Environment.NewLine}");
            }
            catch
            {
            }
        }

        var dispatcher = Application.Current?.Dispatcher;
        if (dispatcher is not null && !dispatcher.CheckAccess())
        {
            dispatcher.Invoke(() =>
            {
                Entries.Add(entry);
                while (Entries.Count > 1000) Entries.RemoveAt(0);
                StatusChanged?.Invoke(message);
            });
        }
        else
        {
            Entries.Add(entry);
            while (Entries.Count > 1000) Entries.RemoveAt(0);
            StatusChanged?.Invoke(message);
        }
    }
}