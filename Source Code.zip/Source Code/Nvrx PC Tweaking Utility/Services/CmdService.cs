using System.Diagnostics;
using System.IO;
using System.Text;

namespace NvrxPCTweakingUtility.Services;

public static class CmdService
{
    private static readonly object Sync = new();

    public static bool RunBatch(string script)
    {
        var logPath = LogService.Instance.LogPath;
        var dir = Path.Combine(Path.GetTempPath(), "NvrxTweaks");
        Directory.CreateDirectory(dir);

        var batPath = Path.Combine(dir, $"tweak_{Guid.NewGuid():N}.bat");
        var cmdPath = Path.Combine(dir, $"flush_{Guid.NewGuid():N}.cmd");

        try
        {
            var sb = new StringBuilder();
            sb.AppendLine("@echo off");
            sb.AppendLine("setlocal EnableExtensions");
            sb.AppendLine("set \"LOG_PATH=" + logPath.Replace("\"", string.Empty) + "\"");
            sb.Append(script.TrimEnd());
            if (!script.TrimEnd().EndsWith("\n")) sb.AppendLine();
            sb.AppendLine("endlocal");
            File.WriteAllText(batPath, sb.ToString(), new UTF8Encoding(false));

            File.WriteAllText(cmdPath,
                "@echo off\r\n" +
                "chcp 65001 >nul\r\n" +
                $"call \"{batPath}\"\r\n" +
                "exit /b 0\r\n",
                new UTF8Encoding(false));

            var psi = new ProcessStartInfo
            {
                FileName = Environment.GetFolderPath(Environment.SpecialFolder.System) + "\\cmd.exe",
                Arguments = $"/c \"{cmdPath}\"",
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding = Encoding.UTF8,
            };
            psi.Environment["LOG_PATH"] = logPath;
            psi.Environment["NVRX_UTILITY_DIR"] = AppContext.BaseDirectory;

            using var proc = Process.Start(psi);
            if (proc is null) return false;

            var stdout = proc.StandardOutput.ReadToEnd();
            var stderr = proc.StandardError.ReadToEnd();
            proc.WaitForExit();

            if (!string.IsNullOrWhiteSpace(stdout))
                LogService.Instance.Info(stdout.Trim());
            if (!string.IsNullOrWhiteSpace(stderr))
                LogService.Instance.Warn(stderr.Trim());

            return proc.ExitCode == 0;
        }
        catch (Exception ex)
        {
            LogService.Instance.Error($"  CmdService error: {ex.Message}");
            return false;
        }
        finally
        {
            try { if (File.Exists(cmdPath)) File.Delete(cmdPath); } catch { }
            try { if (File.Exists(batPath)) File.Delete(batPath); } catch { }
        }
    }

    public static Func<bool> Script(string script) => () => RunBatch(script);
}
