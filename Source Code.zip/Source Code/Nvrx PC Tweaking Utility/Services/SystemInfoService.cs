using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace NvrxPCTweakingUtility.Services;

public sealed record SystemInfo(
    string OsName,
    string OsDisplay,
    string OsBuild,
    string CpuName,
    int LogicalCores,
    string CpuSpeedMhz,
    double TotalRamGb,
    string GpuName,
    string GpuDriver,
    string Architecture);

public static class SystemInfoService
{
    public static async Task<SystemInfo> LoadAsync()
    {
        return await Task.Run(() =>
        {
            var osName = "Windows";
            var osDisplay = string.Empty;
            var osBuild = "10.0";
            var cpuName = "Unknown CPU";
            var cpuMhz = "0";
            var gpuName = "Unknown GPU";
            var gpuDriver = "Unknown";
            double totalRam = 0;

            try
            {
                using var nt = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion");
                osName = nt?.GetValue("ProductName")?.ToString() ?? osName;
                osBuild = nt?.GetValue("CurrentBuildNumber")?.ToString() ?? osBuild;
                osDisplay = nt?.GetValue("DisplayVersion")?.ToString() ?? string.Empty;

                if (int.TryParse(osBuild, out var build) && build >= 22000 && !osName.Contains("Windows 11"))
                    osName = osName.Replace("Windows 10", "Windows 11");
            }
            catch { }

            try
            {
                using var cpu = Registry.LocalMachine.OpenSubKey(@"HARDWARE\DESCRIPTION\System\CentralProcessor\0");
                cpuName = cpu?.GetValue("ProcessorNameString")?.ToString()?.Trim() ?? cpuName;
                cpuMhz = cpu?.GetValue("~MHz")?.ToString() ?? cpuMhz;
            }
            catch { }

            try
            {
                using var gpu = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}\0000");
                gpuName = gpu?.GetValue("DriverDesc")?.ToString() ?? gpuName;
                gpuDriver = gpu?.GetValue("DriverVersion")?.ToString() ?? gpuDriver;
            }
            catch { }

            try
            {
                var status = new MemoryStatusEx();
                if (GlobalMemoryStatusEx(status))
                {
                    totalRam = status.ullTotalPhys / (1024.0 * 1024.0 * 1024.0);
                }
            }
            catch { }

            return new SystemInfo(
                osName,
                osDisplay,
                osBuild,
                cpuName,
                Environment.ProcessorCount,
                cpuMhz,
                Math.Round(totalRam, 1),
                gpuName,
                gpuDriver,
                Environment.Is64BitOperatingSystem ? "x64" : "x86");
        });
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    private sealed class MemoryStatusEx
    {
        public uint dwLength;
        public uint dwMemoryLoad;
        public ulong ullTotalPhys;
        public ulong ullAvailPhys;
        public ulong ullTotalPageFile;
        public ulong ullAvailPageFile;
        public ulong ullTotalVirtual;
        public ulong ullAvailVirtual;
        public ulong ullAvailExtendedVirtual;

        public MemoryStatusEx() => dwLength = (uint)Marshal.SizeOf<MemoryStatusEx>();
    }

    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GlobalMemoryStatusEx([In, Out] MemoryStatusEx lpBuffer);
}