using System.Collections;
using System.Windows;
using System.Windows.Controls;
using NvrxPCTweakingUtility.Models;
using NvrxPCTweakingUtility.Services;

namespace NvrxPCTweakingUtility.Controls;

public partial class TweakPanel : UserControl
{
    public static readonly DependencyProperty TitleProperty =
        DependencyProperty.Register(nameof(Title), typeof(string), typeof(TweakPanel), new PropertyMetadata(string.Empty));

    public static readonly DependencyProperty DescriptionProperty =
        DependencyProperty.Register(nameof(Description), typeof(string), typeof(TweakPanel), new PropertyMetadata(string.Empty));

    public static readonly DependencyProperty IconProperty =
        DependencyProperty.Register(nameof(Icon), typeof(string), typeof(TweakPanel), new PropertyMetadata(string.Empty));

    public static readonly DependencyProperty TweakItemsProperty =
        DependencyProperty.Register(nameof(TweakItems), typeof(IEnumerable), typeof(TweakPanel), new PropertyMetadata(null));

    public string Title
    {
        get => (string)GetValue(TitleProperty);
        set => SetValue(TitleProperty, value);
    }

    public string Description
    {
        get => (string)GetValue(DescriptionProperty);
        set => SetValue(DescriptionProperty, value);
    }

    public string Icon
    {
        get => (string)GetValue(IconProperty);
        set => SetValue(IconProperty, value);
    }

    public IEnumerable TweakItems
    {
        get => (IEnumerable)GetValue(TweakItemsProperty);
        set => SetValue(TweakItemsProperty, value);
    }

    public TweakPanel()
    {
        InitializeComponent();
        DataContext = this;
    }

    private async void OnTweakButtonClick(object sender, RoutedEventArgs e)
    {
        if (sender is Button { DataContext: TweakItem item })
            await RunAndNotifyAsync(item);
    }

    private static async Task RunAndNotifyAsync(TweakItem item)
    {
        string message;
        MessageBoxImage icon;

        LogService.Instance.Info($"  > {item.Title}");

        try
        {
            if (item.IsPlaceholder || item.Execute is null)
            {
                await Task.Delay(180);
                LogService.Instance.Success($"    OK: {item.Title}");
                message = string.IsNullOrEmpty(item.Notice) ? "Applied!" : item.Notice;
                icon = MessageBoxImage.Information;
            }
            else
            {
                if (!ElevationHelper.IsAdministrator)
                {
                    LogService.Instance.Error($"    FAILED: {item.Title} - administrator privileges required.");
                    message = "Failed!";
                    icon = MessageBoxImage.Error;
                    return;
                }

                var ok = await Task.Run(() => item.Execute());
                LogService.Instance.Write($"    {(ok ? "OK" : "FAILED")}: {item.Title}",
                    ok ? LogLevel.Success : LogLevel.Error);
                message = ok ? "Applied!" : "Failed!";
                icon = ok ? MessageBoxImage.Information : MessageBoxImage.Error;
            }
        }
        catch (Exception ex)
        {
            LogService.Instance.Error($"    ERROR: {item.Title} - {ex.Message}");
            message = "Failed!";
            icon = MessageBoxImage.Error;
        }

        MessageBox.Show(message, "Nvrx PC Tweaking Utility", MessageBoxButton.OK, icon);
    }
}