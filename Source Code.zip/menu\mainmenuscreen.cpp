#define WIN32_LEAN_AND_MEAN
#define NOMINMAX

#include "mainmenuscreen.h"

#include "menuwidgets.h"
#include "glasspanel.h"
#include "layout.h"
#include "theme.h"
#include "renderopacity.h"
#include "embeddedassets.h"
#include "imagedecoder.h"
#include "appbridge.h"

#include "../res/resource.h"
#include "../main/tweaks.hpp"

#include "imgui.h"
#include "iconfont.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

namespace UI::Screens
{
    using namespace UI::Menu;
    namespace Components = UI::Components;

    namespace
    {

        Renderer::Texture LoadPngSilhouette(ID3D11Device* device, int resourceId)
        {
            Renderer::Texture tex;
            const HRSRC res = FindResourceW(GetModuleHandleW(nullptr), MAKEINTRESOURCEW(resourceId), L"PNG");
            if (!res)
                return tex;
            const HGLOBAL block = LoadResource(nullptr, res);
            if (!block)
                return tex;
            const void* data = LockResource(block);
            const DWORD size = SizeofResource(nullptr, res);
            if (!data || !size)
                return tex;
            Utilities::DecodedImage image = Utilities::DecodeImage(static_cast<const uint8_t*>(data), size);
            if (!image.IsValid())
                return tex;
            Utilities::ConvertToWhiteSilhouette(image);
            Utilities::ResampleImage(image, 20, 20);
            tex.Create(device, image.Frames.front().Pixels.data(), image.Width, image.Height);
            return tex;
        }

        std::string LowerStr(const char* s)
        {
            std::string o = s ? s : "";
            for (char& c : o)
                c = static_cast<char>(tolower(static_cast<unsigned char>(c)));
            return o;
        }

        bool FilterMatch(const char* text, const char* query)
        {
            if (!query || !*query)
                return true;
            return LowerStr(text).find(LowerStr(query)) != std::string::npos;
        }

        const char* GroupIcon(const char* name)
        {
            if (!name || !*name)
                return ICON_SETTINGS;
            if (std::strcmp(name, "Performance") == 0)
                return ICON_SPEED;
            if (std::strcmp(name, "System") == 0)
                return ICON_GEARS;
            if (std::strcmp(name, "Privacy") == 0)
                return ICON_SHIELD;
            if (std::strcmp(name, "Debloat") == 0)
                return ICON_SWEEP;
            if (std::strcmp(name, "Apps") == 0)
                return ICON_APPS;
            if (std::strcmp(name, "Security") == 0)
                return ICON_SECURITY;
            if (std::strcmp(name, "Customization") == 0)
                return ICON_PALETTE;
            if (std::strcmp(name, "BIOS Tweaker") == 0)
                return ICON_BOARD;
            if (std::strcmp(name, "Game Tweaker") == 0)
                return ICON_GAMEPAD;
            return ICON_SETTINGS;
        }

        std::string Fitted(const char* text, float maxWidth, ImFont* font)
        {
            if (!text)
                return {};
            std::string s(text);
            bool truncated = false;
            while (s.size() > 4 && Components::TextWidth(s.c_str(), font) > maxWidth)
            {
                s.pop_back();
                truncated = true;
            }
            if (truncated && s.size() <= 4)
                s.clear();
            return truncated ? s + "..." : s;
        }

        std::string FittedByCount(const char* text, size_t maxLength)
        {
            if (!text)
                return {};
            std::string s(text);
            if (s.size() > maxLength)
            {
                s.resize(maxLength);
                s += "...";
            }
            return s;
        }

        void DrawAppliedPill(ImVec2 min)
        {
            const ThemeTypography& typography = Theme::Get().Typography();
            ImDrawList* drawList = ImGui::GetWindowDrawList();
            const char* label = "APPLIED";
            const float w = Components::TextWidth(label, typography.Small) + 12.0f;
            drawList->AddRectFilled(min, ImVec2(min.x + w, min.y + 17.0f), Color(240, 240, 240, 232), 8.5f);
            const float textH = Components::TextHeight(typography.Small);
            Components::DrawTextAt(ImVec2(min.x + 6.0f, min.y + (17.0f - textH) * 0.5f),
                label, typography.Small, ImVec4(10.0f / 255.0f, 10.0f / 255.0f, 12.0f / 255.0f, 1.0f));
        }

        float StoredAnim(const char* id, float target, float speed)
        {
            const ImGuiID animId = ImGui::GetID(id);
            ImGuiStorage* storage = ImGui::GetStateStorage();
            float value = storage->GetFloat(animId, target);
            value += (target - value) * (1.0f - std::exp(-ImGui::GetIO().DeltaTime * speed));
            storage->SetFloat(animId, value);
            return value;
        }

        ImVec4 LevelColor(int level)
        {
            const ThemeColors& colors = Theme::Get().Colors();
            switch (level)
            {
            case 1: return colors.TextPrimary;
            case 2: return ImVec4(0.93f, 0.70f, 0.35f, 1.0f);
            case 3: return ImVec4(0.96f, 0.45f, 0.41f, 1.0f);
            case 4: return ImVec4(0.47f, 0.47f, 0.51f, 1.0f);
            default: return colors.TextSecondary;
            }
        }
    }

    void MainMenuScreen::Initialize(ID3D11Device* device)
    {
        const int iconResource[2] = { IDR_PNG_TAB_OVERVIEW, IDR_PNG_TAB_TWEAKS };

        for (int i = 0; i < kTabCount; ++i)
            m_Icons[i] = LoadPngSilhouette(device, iconResource[i]);

        m_ActiveTab = nvrx::app::App::get().tab();
        m_LastTab = m_ActiveTab;
    }

    void MainMenuScreen::Update(float)
    {
        m_PageTransitionT = (std::min)(1.0f, m_PageTransitionT + ImGui::GetIO().DeltaTime / 0.12f);
    }

    MainMenuScreen::PanelRects MainMenuScreen::GetPanelRects(ImVec2 regionMin, ImVec2 regionSize)
    {
        const ImVec2 canvasMin(
            regionMin.x + (regionSize.x - kMenuWidth) * 0.5f,
            regionMin.y + (regionSize.y - kMenuHeight) * 0.5f);
        const ImVec2 contentMin(canvasMin.x + kOuterMargin, canvasMin.y + kOuterMargin);
        const ImVec2 contentMax(
            canvasMin.x + kMenuWidth - kOuterMargin,
            canvasMin.y + kMenuHeight - kOuterMargin);
        const float belowTopBar = contentMin.y + kTopBarHeight + kPanelGap;
        return {
            ImVec2(contentMin.x + kLeftPanelWidth + kPanelGap, contentMin.y),
                ImVec2(contentMax.x, contentMin.y + kTopBarHeight),
            ImVec2(contentMin.x, belowTopBar),
                ImVec2(contentMin.x + kLeftPanelWidth, contentMax.y),
            ImVec2(contentMin.x + kLeftPanelWidth + kPanelGap, belowTopBar), contentMax
        };
    }

    float MainMenuScreen::PanelRadius()
    {
        return kPanelRadius;
    }

    void MainMenuScreen::DrawTopBar(ImDrawList* drawList, const PanelRects& panels)
    {
        const ThemeColors& colors = Theme::Get().Colors();
        const ThemeTypography& typography = Theme::Get().Typography();

        ImVec2 tabMin(panels.TopMin.x + 10.0f, panels.TopMin.y + 8.0f);
        constexpr float collapsedWidth = 42.0f;
        const float tabHeight = panels.TopMax.y - 8.0f - tabMin.y;

        for (int i = 0; i < kTabCount; ++i)
        {
            const float labelWidth = Components::TextWidth(m_Tabs[i].Label, typography.BodyMedium);
            const float expandedWidth = 40.0f + labelWidth + 16.0f;

            const float previousEase = m_TabHoverT[i] * m_TabHoverT[i] * (3.0f - 2.0f * m_TabHoverT[i]);
            const float previousWidth = collapsedWidth + previousEase * (expandedWidth - collapsedWidth);
            ImGui::SetCursorScreenPos(tabMin);
            char id[32];
            snprintf(id, sizeof(id), "##nvrx_tab_%d", i);
            if (ImGui::InvisibleButton(id, ImVec2(previousWidth, tabHeight)))
            {
                if (m_ActiveTab != i)
                    m_PageTransitionT = 0.0f;
                m_ActiveTab = i;
                nvrx::app::App::get().set_tab(i);
            }
            const bool hovered = ImGui::IsItemHovered();
            m_TabHoverT[i] += ((hovered ? 1.0f : 0.0f) - m_TabHoverT[i])
                * (1.0f - std::exp(-ImGui::GetIO().DeltaTime * 18.0f));
            const float ease = m_TabHoverT[i] * m_TabHoverT[i] * (3.0f - 2.0f * m_TabHoverT[i]);
            const float width = collapsedWidth + ease * (expandedWidth - collapsedWidth);
            const ImVec2 tabMax(tabMin.x + width, panels.TopMax.y - 8.0f);

            if (ease > 0.01f)
                drawList->AddRectFilled(tabMin, tabMax,
                    Color(255, 255, 255, static_cast<int>(ease * 20.0f)), 12.0f);

            if (m_Icons[i].IsValid())
            {
                const ImVec2 iconMin(std::floor(tabMin.x + 12.0f),
                    std::floor((tabMin.y + tabMax.y) * 0.5f - 10.0f));
                const int alpha = m_ActiveTab == i ? 255 : 190 + static_cast<int>(ease * 45.0f);
                drawList->AddImage(reinterpret_cast<ImTextureID>(m_Icons[i].View()),
                    iconMin, ImVec2(iconMin.x + 20.0f, iconMin.y + 20.0f),
                    ImVec2(0.0f, 0.0f), ImVec2(1.0f, 1.0f), Color(255, 255, 255, alpha));
            }
            if (ease > 0.04f)
            {
                ImVec4 textColor = colors.TextPrimary;
                textColor.w *= ease;
                const float h = Components::TextHeight(typography.BodyMedium);
                Components::DrawTextAt(ImVec2(tabMin.x + 40.0f, (tabMin.y + tabMax.y - h) * 0.5f),
                    m_Tabs[i].Label, typography.BodyMedium, textColor);
            }

            tabMin.x += width;
        }
    }

    bool MainMenuScreen::DrawSmallButton(const char* id, ImVec2 origin, float width, float height,
        const char* label, bool filled, bool danger, bool enabled)
    {
        const ThemeColors& colors = Theme::Get().Colors();
        const ThemeTypography& typography = Theme::Get().Typography();

        ImGui::PushID(id);
        ImGui::SetCursorScreenPos(origin);
        const bool clicked = ImGui::InvisibleButton("##nvrx_btn", ImVec2(width, height));
        const bool hovered = ImGui::IsItemHovered();
        const bool held = ImGui::IsItemActive();
        ImGui::PopID();

        char hoverId[128], pressId[128];
        snprintf(hoverId, sizeof(hoverId), "%s_hover", id);
        snprintf(pressId, sizeof(pressId), "%s_press", id);
        const float hover = StoredAnim(hoverId, enabled && hovered ? 1.0f : 0.0f, 18.0f);
        const float press = StoredAnim(pressId, enabled && held ? 1.0f : 0.0f, 30.0f);

        ImDrawList* drawList = ImGui::GetWindowDrawList();
        const ImVec2 btnMax(origin.x + width, origin.y + height);

        ImVec4 surface, border, labelColor;
        bool hasBorder = false;
        if (filled)
        {
            surface = Components::Mix(colors.Accent, colors.AccentHover, hover);
            surface = Components::Mix(surface, colors.AccentPressed, press);
            labelColor = colors.AccentText;
        }
        else if (danger)
        {
            surface = Components::Mix(colors.OutlineSurface, colors.Danger, hover * 0.22f);
            border = Components::Mix(colors.OutlineBorder, colors.Danger, hover * 0.55f);
            labelColor = Components::Mix(colors.TextSecondary, colors.Danger, hover);
            hasBorder = true;
        }
        else
        {
            surface = Components::Mix(colors.OutlineSurface, colors.OutlineSurfaceHover, hover);
            border = colors.OutlineBorder;
            labelColor = Components::Mix(colors.TextSecondary, colors.TextPrimary, hover);
            hasBorder = true;
        }
        if (!enabled)
        {
            surface = colors.AccentDisabled;
            border = colors.Border;
            labelColor = colors.TextDisabled;
            hasBorder = true;
        }

        constexpr float radius = 9.0f;
        drawList->AddRectFilled(origin, btnMax,
            ImGui::ColorConvertFloat4ToU32(ApplyOpacity(surface)), radius);
        if (hasBorder)
            drawList->AddRect(origin, btnMax,
                ImGui::ColorConvertFloat4ToU32(ApplyOpacity(border)), radius, 0, 1.0f);

        ImFont* labelFont = height >= 34.0f ? typography.BodyMedium : typography.Small;
        const float textH = Components::TextHeight(labelFont);
        Components::DrawTextCentered(ImVec2(origin.x, origin.y + (height - textH) * 0.5f),
            width, label, labelFont, labelColor);
        return clicked && enabled;
    }

    void MainMenuScreen::DrawSearchField(const ImVec2& origin, float width, char* buffer,
        size_t bufferSize, bool focusRequest)
    {
        const ThemeColors& colors = Theme::Get().Colors();
        ImDrawList* drawList = ImGui::GetWindowDrawList();
        const ThemeTypography& typography = Theme::Get().Typography();
        constexpr float height = 32.0f;
        const ImVec2 fieldMax(origin.x + width, origin.y + height);

        drawList->AddRectFilled(origin, fieldMax, Color(31, 35, 44), 16.0f);

        ImGui::PushID("##nvrx_search");
        if (focusRequest)
            ImGui::SetKeyboardFocusHere(0);

        const float padY = (height - ImGui::GetTextLineHeight()) * 0.5f;
        ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(0.0f, padY));
        ImGui::SetCursorScreenPos(ImVec2(origin.x + 34.0f, origin.y));
        ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4(0, 0, 0, 0));
        ImGui::PushStyleColor(ImGuiCol_FrameBgHovered, ImVec4(0, 0, 0, 0));
        ImGui::PushStyleColor(ImGuiCol_FrameBgActive, ImVec4(0, 0, 0, 0));
        ImGui::PushStyleColor(ImGuiCol_Text, colors.TextPrimary);
        ImGui::SetNextItemWidth(width - 46.0f);
        ImGui::InputTextWithHint("##nvrx_search_field", "Search tweaks...", buffer, bufferSize);
        ImGui::PopStyleColor(4);
        ImGui::PopStyleVar();
        const bool focused = ImGui::IsItemActive();
        const bool hoveredField = ImGui::IsItemHovered();
        ImGui::PopID();

        drawList->AddRect(origin, fieldMax,
            focused ? Color(240, 240, 243, 110)
                    : (hoveredField ? Color(255, 255, 255, 36) : Color(255, 255, 255, 13)),
            16.0f);
        const float iconW = Components::TextWidth(ICON_SEARCH, typography.IconControl);
        const float iconH = Components::TextHeight(typography.IconControl);
        Components::DrawTextAt(
            ImVec2(origin.x + 14.0f + (16.0f - iconW) * 0.5f, origin.y + (height - iconH) * 0.5f),
            ICON_SEARCH, typography.IconControl,
            focused ? colors.TextSecondary : colors.TextDisabled);
    }

    void MainMenuScreen::DrawGroupRail(ImDrawList* drawList, const PanelRects& panels)
    {
        const ThemeColors& colors = Theme::Get().Colors();
        const ThemeTypography& typography = Theme::Get().Typography();

        Components::GlassPanelStyle railStyle;
        railStyle.Radius = kPanelRadius;
        railStyle.Shadow = false;
        railStyle.Sheen = false;
        railStyle.Border = false;
        railStyle.CustomSurface = true;
        railStyle.SurfaceColor = kMainSurface;
        Components::DrawGlassPanel(panels.LeftMin, panels.LeftMax, railStyle);

        const int page = 1;

        char selKey[48];
        snprintf(selKey, sizeof(selKey), "##nvrx_railsel_%d", page);
        ImGuiID selId = ImGui::GetID(selKey);
        ImGuiStorage* storage = ImGui::GetStateStorage();
        int selected = storage->GetInt(selId, 0);

        constexpr float pillSize = 40.0f;
        constexpr float inset = 9.0f;
        float y = panels.LeftMin.y + inset;
        int idx = 0;
        int matchIdx = -1;
        for (auto& g : nvrx::groups())
        {
            if (static_cast<int>(g.page) != page)
                continue;
            const char* gid = g.name;
            if (idx == selected)
                matchIdx = idx;

            const ImVec2 pMin(panels.LeftMin.x + inset, y);
            const ImVec2 pMax(pMin.x + pillSize, y + pillSize);
            char pid[128];
            snprintf(pid, sizeof(pid), "##nvrx_grp_%d_%s", page, gid);
            ImGui::SetCursorScreenPos(pMin);
            const bool clicked = ImGui::InvisibleButton(pid, ImVec2(pillSize, pillSize));
            if (clicked)
            {
                selected = idx;
                storage->SetInt(selId, selected);
            }

            ImU32 bg;
            ImVec4 fg;
            if (selected == idx)
            {
                bg = Color(240, 240, 243);
                fg = ImVec4(0.047f, 0.047f, 0.055f, 1.0f);
            }
            else if (ImGui::IsItemHovered())
            {
                bg = Color(255, 255, 255, 18);
                fg = colors.TextPrimary;
            }
            else
            {
                bg = Color(255, 255, 255, 10);
                fg = colors.TextSecondary;
            }
            drawList->AddRectFilled(pMin, pMax, bg, 9.0f);

            const float iconW = Components::TextWidth(GroupIcon(gid), typography.IconControl);
            const float iconH = Components::TextHeight(typography.IconControl);
            Components::DrawTextAt(
                ImVec2(pMin.x + (pillSize - iconW) * 0.5f, pMin.y + (pillSize - iconH) * 0.5f),
                GroupIcon(gid), typography.IconControl, fg);

            y += pillSize + 8.0f;
            ++idx;
        }

        if (idx == 0)
        {
            m_SelectedGroup[0] = '\0';
            return;
        }
        if (selected < 0 || selected >= idx)
        {
            selected = 0;
            storage->SetInt(selId, 0);
        }
        const char* cur = m_SelectedGroup;
        const bool haveName = cur && cur[0];
        if (haveName && matchIdx == selected)
            return;
        int n = 0;
        for (auto& g : nvrx::groups())
        {
            if (static_cast<int>(g.page) == page)
            {
                if (n == selected)
                {
                    snprintf(m_SelectedGroup, sizeof(m_SelectedGroup),
                        "%s", g.name);
                    break;
                }
                ++n;
            }
        }
    }

    void MainMenuScreen::DrawBrand(ImDrawList* drawList, ImVec2 mainMin)
    {
        (void)drawList;
        const ThemeColors& colors = Theme::Get().Colors();
        const ThemeTypography& typography = Theme::Get().Typography();
        Components::DrawTextAt(ImVec2(mainMin.x + kBrandPadding, mainMin.y + 18.0f),
            "Nvrx PC Tweaking Utility", typography.BodyMedium, colors.TextPrimary);

        const float brandW = Components::TextWidth("Nvrx PC Tweaking Utility", typography.BodyMedium);
        Components::DrawTextAt(
            ImVec2(mainMin.x + kBrandPadding + brandW + 10.0f, mainMin.y + 18.0f),
            "v3.0", typography.BodyMedium, colors.TextPrimary);
    }

    void MainMenuScreen::DrawActionsCard(ImDrawList* drawList, ImVec2 mn, ImVec2 mx)
    {
        const ThemeColors& colors = Theme::Get().Colors();
        const ThemeTypography& typography = Theme::Get().Typography();
        nvrx::app::App& app = nvrx::app::App::get();
        const bool busy = app.busy();

        drawList->AddRectFilled(mn, mx, Color(17, 20, 27), 14.0f);
        drawList->AddRect(mn, mx, Color(255, 255, 255, 10), 14.0f);
        Components::DrawTextAt(ImVec2(mn.x + 16.0f, mn.y + 11.0f),
            "Actions", typography.BodyMedium, colors.TextPrimary);
        Components::DrawTextAt(ImVec2(mn.x + 16.0f, mn.y + 34.0f),
            "One-click engine commands", typography.Small, colors.TextSecondary);

        if (busy && app.total_count() > 0)
        {
            char overlay[64];
            snprintf(overlay, sizeof(overlay), "%d / %d", app.done_count(), app.total_count());
            Components::DrawTextAt(ImVec2(mx.x - 72.0f, mn.y + 13.0f),
                overlay, typography.Small, colors.TextSecondary);
        }

        const float inset = 16.0f;
        const float w = mx.x - mn.x - inset * 2.0f;
        ImVec2 y(mn.x + inset, mn.y + 60.0f);
        if (DrawSmallButton("##act_recommended", y, w, 28.0f,
            busy ? "Working..." : "Apply Recommended Tweaks", true, false, !busy))
            app.run_recommended();
        y.y += 34.0f;
        if (DrawSmallButton("##act_restore", y, w, 28.0f, "Create Restore Point", false, false, !busy))
            app.restore_point();
        y.y += 34.0f;
        if (DrawSmallButton("##act_reboot", y, w, 28.0f, "Reboot Now", false, true, !busy))
            app.reboot_now();

        if (busy && app.total_count() > 0)
        {
            const float frac = (std::max)(0.0f, (std::min)(1.0f,
                static_cast<float>(app.done_count()) / static_cast<float>(app.total_count())));
            drawList->AddRectFilled(ImVec2(mn.x + inset, mx.y - 8.0f),
                ImVec2(mx.x - inset, mx.y - 5.0f), Color(255, 255, 255, 16), 1.5f);
            if (frac > 0.001f)
                drawList->AddRectFilled(ImVec2(mn.x + inset, mx.y - 8.0f),
                    ImVec2(mn.x + inset + w * frac, mx.y - 5.0f), Color(240, 240, 243, 220), 1.5f);
        }
    }

    void MainMenuScreen::DrawActivityCard(ImDrawList* drawList, ImVec2 mn, ImVec2 mx)
    {
        const ThemeColors& colors = Theme::Get().Colors();
        const ThemeTypography& typography = Theme::Get().Typography();
        nvrx::app::App& app = nvrx::app::App::get();

        drawList->AddRectFilled(mn, mx, Color(17, 20, 27), 14.0f);
        drawList->AddRect(mn, mx, Color(255, 255, 255, 10), 14.0f);
        Components::DrawTextAt(ImVec2(mn.x + 16.0f, mn.y + 11.0f),
            "Recent Activity", typography.BodyMedium, colors.TextPrimary);
        Components::DrawTextAt(ImVec2(mn.x + 16.0f, mn.y + 34.0f),
            "Engine log (newest first)", typography.Small, colors.TextSecondary);

        if (DrawSmallButton("##act_copy", ImVec2(mx.x - 16.0f - 56.0f, mn.y + 9.0f),
            56.0f, 26.0f, "Copy", false, false, true))
            app.copy_log();
        if (DrawSmallButton("##act_clear",
            ImVec2(mx.x - 16.0f - 56.0f - 8.0f - 56.0f, mn.y + 9.0f),
            56.0f, 26.0f, "Clear", false, false, true))
            app.clear_log();

        const float logTop = mn.y + 60.0f;
        const float logBottom = mx.y - 12.0f;
        ImGui::PushStyleColor(ImGuiCol_ScrollbarBg, ImVec4(0, 0, 0, 0));
        ImGui::PushStyleColor(ImGuiCol_ScrollbarGrab, ImVec4(1, 1, 1, 0.10f));
        ImGui::PushStyleColor(ImGuiCol_ScrollbarGrabHovered, ImVec4(1, 1, 1, 0.22f));
        ImGui::PushStyleColor(ImGuiCol_ScrollbarGrabActive, ImVec4(1, 1, 1, 0.32f));
        ImGui::PushStyleVar(ImGuiStyleVar_ScrollbarSize, 4.0f);
        ImGui::PushStyleVar(ImGuiStyleVar_ScrollbarRounding, 2.0f);
        ImGui::SetCursorScreenPos(ImVec2(mn.x + 16.0f, logTop));
        ImGui::BeginChild("##activity_log",
            ImVec2(mx.x - mn.x - 32.0f, logBottom - logTop),
            ImGuiChildFlags_None,
            ImGuiWindowFlags_NoBackground);
        ImGui::PushFont(typography.Small);
        const std::vector<nvrx::app::LogEntry> lines = app.log_snapshot(160);
        for (size_t idx = lines.size(); idx-- > 0;)
        {
            const nvrx::app::LogEntry& line = lines[idx];
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.47f, 0.47f, 0.51f, 1.0f));
            ImGui::TextUnformatted(line.time.c_str());
            ImGui::PopStyleColor();
            ImGui::SameLine(0.0f, 8.0f);
            ImGui::PushStyleColor(ImGuiCol_Text, LevelColor(line.level));
            ImGui::TextWrapped("%s", line.text.c_str());
            ImGui::PopStyleColor();
            ImGui::SetCursorPosY(ImGui::GetCursorPosY() - 2.0f);
        }
        ImGui::PopFont();
        ImGui::EndChild();
        ImGui::PopStyleColor(4);
        ImGui::PopStyleVar(2);
    }

    void MainMenuScreen::DrawListPage(ImDrawList* drawList, ImVec2 cardTop, ImVec2 cardBottom, int page)
    {
        (void)drawList;
        const ThemeColors& colors = Theme::Get().Colors();
        const ThemeTypography& typography = Theme::Get().Typography();
        nvrx::app::App& app = nvrx::app::App::get();
        const bool busy = app.busy();

        const nvrx::Category* category = nullptr;
        for (auto& c : nvrx::categories())
        {
            if (static_cast<int>(c.page) == page)
                category = &c;
        }
        if (!category)
            return;

        const float contentLeft = cardTop.x;
        const float contentRight = cardBottom.x;
        const float cardW = contentRight - contentLeft;
        const char* filter = m_Filter;
        const char* groupName = m_SelectedGroup;

        if (groupName && groupName[0])
        {
            const char* groupNote = "";
            for (auto& grp : nvrx::groups())
            {
                if (static_cast<int>(grp.page) == page && std::strcmp(grp.name, groupName) == 0)
                {
                    groupNote = grp.note;
                    break;
                }
            }
            if (groupNote && groupNote[0])
                Components::DrawTextAt(ImVec2(contentLeft, cardTop.y - 34.0f),
                    groupNote, typography.Small, colors.TextSecondary);
            else if (category->note && category->note[0])
                Components::DrawTextAt(ImVec2(contentLeft, cardTop.y - 34.0f),
                    category->note, typography.Small, colors.TextSecondary);
        }
        if (!groupName || !groupName[0])
            return;

        if (std::strcmp(groupName, "BIOS Tweaker") == 0)
        {
            DrawBiosScreen(drawList, cardTop, cardBottom, filter);
            return;
        }

        if (std::strcmp(groupName, "Game Tweaker") == 0)
        {
            DrawGameScreen(drawList, cardTop, cardBottom, filter);
            return;
        }

        const float headerH = 44.0f;
        const float cardH = cardBottom.y - cardTop.y;
        (void)cardH;
        drawList->AddRectFilled(cardTop, cardBottom, Color(17, 20, 27), 14.0f);
        drawList->AddRect(cardTop, cardBottom, Color(255, 255, 255, 10), 14.0f);

        Components::DrawTextAt(ImVec2(cardTop.x + 14.0f, cardTop.y + 11.0f),
            groupName, typography.BodyMedium, colors.TextPrimary);
        {
            int count = 0;
            for (auto& t : nvrx::tweaks())
            {
                if (static_cast<int>(t.page) == page && std::strcmp(t.group, groupName) == 0
                    && (FilterMatch(t.title, filter) || FilterMatch(t.desc, filter)))
                {
                    ++count;
                }
            }

            char cnt[24];
            snprintf(cnt, sizeof(cnt), "%d", count);
            const float cntW = Components::TextWidth(cnt, typography.Small) + 18.0f;
            const ImVec2 c0(cardBottom.x - 14.0f - cntW, cardTop.y + 8.0f);
            const ImVec2 c1(cardBottom.x - 14.0f, cardTop.y + 30.0f);
            drawList->AddRectFilled(c0, c1, Color(255, 255, 255, 7), 11.0f);
            drawList->AddRect(c0, c1, Color(255, 255, 255, 12), 11.0f);
            const float cntH = Components::TextHeight(typography.Small);
            Components::DrawTextAt(ImVec2(c0.x + 9.0f, c0.y + (22.0f - cntH) * 0.5f),
                cnt, typography.Small, colors.TextSecondary);
        }

        DrawDivider(ImVec2(cardTop.x + 14.0f, cardTop.y + 34.0f),
            ImVec2(cardBottom.x - 14.0f, cardTop.y + 34.0f));

        ImGui::PushStyleColor(ImGuiCol_ScrollbarBg, ImVec4(0, 0, 0, 0));
        ImGui::PushStyleColor(ImGuiCol_ScrollbarGrab, ImVec4(1, 1, 1, 0.10f));
        ImGui::PushStyleColor(ImGuiCol_ScrollbarGrabHovered, ImVec4(1, 1, 1, 0.22f));
        ImGui::PushStyleColor(ImGuiCol_ScrollbarGrabActive, ImVec4(1, 1, 1, 0.32f));
        ImGui::PushStyleVar(ImGuiStyleVar_ScrollbarSize, 4.0f);
        ImGui::PushStyleVar(ImGuiStyleVar_ScrollbarRounding, 2.0f);
        ImGui::SetCursorScreenPos(ImVec2(contentLeft - 14.0f, cardTop.y + headerH + 6.0f));
        ImGui::BeginChild("##tweak_scroll",
            ImVec2(cardW + 28.0f, cardBottom.y - (cardTop.y + headerH + 6.0f)),
            ImGuiChildFlags_None, ImGuiWindowFlags_NoBackground);

        ImDrawList* cDL = ImGui::GetWindowDrawList();
        const float scrollShift = ImGui::GetScrollY();
        float rowY = cardTop.y + headerH + 12.0f - scrollShift;

        {
            int count = 0;
            for (auto& t : nvrx::tweaks())
            {
                if (static_cast<int>(t.page) != page || std::strcmp(t.group, groupName) != 0
                    || (!FilterMatch(t.title, filter) && !FilterMatch(t.desc, filter)))
                {
                    continue;
                }
                ++count;

                constexpr float rowH = 52.0f;
                const bool applied = app.applied(t.id);
                const ImVec2 r0(contentLeft + 14.0f, rowY);
                const ImVec2 r1(contentRight - 14.0f, rowY + rowH);

                if (ImGui::IsMouseHoveringRect(r0, r1))
                {
                    cDL->AddRectFilled(r0, r1, Color(255, 255, 255, 7), 10.0f);
                }
                else if (count > 1)
                {
                    cDL->AddLine(ImVec2(r0.x + 42.0f, r0.y), ImVec2(r1.x - 42.0f, r0.y),
                        Color(255, 255, 255, 5), 1.0f);
                }

                const ImVec2 dc(r0.x + 16.0f, r0.y + rowH * 0.5f);
                if (applied)
                {
                    cDL->AddCircleFilled(dc, 6.5f, Color(63, 185, 80, 46), 20);
                    cDL->AddCircleFilled(dc, 3.5f, Color(63, 185, 80), 20);
                }
                else
                {
                    cDL->AddCircle(dc, 4.0f, Color(255, 255, 255, 36), 24, 1.6f);
                }

                const float btnW = 68.0f;
                const float btnH = 28.0f;
                const float textStart = r0.x + 38.0f;
                const float textMax = (r1.x - btnW - 26.0f) - textStart;
                ImFont* bm = typography.BodyMedium;
                const std::string title = Fitted(t.title, textMax, bm);
                ImVec4 titleCol = colors.TextPrimary;
                if (applied)
                    titleCol.w *= 0.62f;
                Components::DrawTextAt(ImVec2(textStart, r0.y + 8.0f), title.c_str(),
                    typography.BodyMedium, titleCol);

                std::string detail = t.desc ? t.desc : "";
                const std::string dfitted = Fitted(detail.c_str(), textMax, typography.Small);
                Components::DrawTextAt(ImVec2(textStart, r0.y + 29.0f), dfitted.c_str(),
                    typography.Small, colors.TextSecondary);

                const ImVec2 b0(r1.x - btnW - 12.0f, r0.y + (rowH - btnH) * 0.5f);
                const ImVec2 b1(b0.x + btnW, b0.y + btnH);
                char bid[96];
                snprintf(bid, sizeof(bid), "##nvrx_apply_%s", t.id);
                ImGui::SetCursorScreenPos(b0);
                const bool hitApply = ImGui::InvisibleButton(bid, ImVec2(btnW, btnH));
                const bool hovApply = ImGui::IsItemHovered() && !ImGui::IsItemActive();
                if (hitApply && !busy)
                    app.run_single(t.id, t.title);

                char lbl[32];
                snprintf(lbl, sizeof(lbl), "%s",
                    busy ? "Wait" : (applied ? "Applied" : "Apply"));
                ImU32 btnBg;
                ImVec4 btnFg;
                if (applied)
                {
                    btnBg = Color(63, 185, 80, 26);
                    btnFg = ImVec4(0.52f, 0.86f, 0.62f, 1.0f);
                }
                else if (hovApply)
                {
                    btnBg = Color(240, 240, 243);
                    btnFg = ImVec4(0.047f, 0.047f, 0.055f, 1.0f);
                }
                else
                {
                    btnBg = Color(255, 255, 255, 8);
                    btnFg = colors.TextSecondary;
                }
                if (busy && !applied)
                    btnFg = colors.TextDisabled;
                cDL->AddRectFilled(b0, b1, btnBg, 8.0f);
                const float lblW = Components::TextWidth(lbl, typography.Small);
                const float lblH = Components::TextHeight(typography.Small);
                Components::DrawTextAt(
                    ImVec2(b0.x + (btnW - lblW) * 0.5f, b0.y + (btnH - lblH) * 0.5f),
                    lbl, typography.Small, btnFg);

                rowY += rowH;
            }

            if (!count)
            {

                Components::DrawTextAt(ImVec2(contentLeft + 14.0f, rowY),
                    filter[0] ? "No tweaks match the search" : "Nothing to show here",
                    typography.Small, colors.TextSecondary);
                rowY += 24.0f;
            }
        }

        ImGui::SetCursorScreenPos(ImVec2(contentLeft, rowY));
        ImGui::Dummy(ImVec2(cardW, 20.0f));

        ImGui::EndChild();
        ImGui::PopStyleColor(4);
        ImGui::PopStyleVar(2);
    }

    void MainMenuScreen::DrawBiosScreen(ImDrawList* drawList, ImVec2 cardTop,
        ImVec2 cardBottom, const char* filter)
    {
        nvrx::app::App& app = nvrx::app::App::get();
        const ThemeColors& colors = Theme::Get().Colors();
        const ThemeTypography& typography = Theme::Get().Typography();
        const bool busy = app.busy();

        const float contentLeft = cardTop.x;
        const float contentRight = cardBottom.x;

        drawList->AddRectFilled(cardTop, cardBottom, Color(17, 20, 27), 14.0f);
        drawList->AddRect(cardTop, cardBottom, Color(255, 255, 255, 10), 14.0f);
        Components::DrawTextAt(ImVec2(cardTop.x + 14.0f, cardTop.y + 11.0f),
            "BIOS Tweaker (SCEWIN)", typography.BodyMedium, colors.TextPrimary);

        const int total = app.bios_item_count();
        int visible = 0;
        for (int i = 0; i < total; ++i)
        {
            nvrx::app::BiosItem probe;
            if (app.bios_item(i, &probe)
                && (FilterMatch(probe.title.c_str(), filter)
                 || FilterMatch(probe.detail.c_str(), filter)))
            {
                ++visible;
            }
        }
        {
            char cnt[24];
            snprintf(cnt, sizeof(cnt), "%d", visible);
            const float cntW = Components::TextWidth(cnt, typography.Small) + 18.0f;
            const ImVec2 c0(cardBottom.x - 14.0f - cntW, cardTop.y + 8.0f);
            const ImVec2 c1(cardBottom.x - 14.0f, cardTop.y + 30.0f);
            drawList->AddRectFilled(c0, c1, Color(255, 255, 255, 7), 11.0f);
            drawList->AddRect(c0, c1, Color(255, 255, 255, 12), 11.0f);
            const float cntH = Components::TextHeight(typography.Small);
            Components::DrawTextAt(ImVec2(c0.x + 9.0f, c0.y + (22.0f - cntH) * 0.5f),
                cnt, typography.Small, colors.TextSecondary);
        }
        DrawDivider(ImVec2(cardTop.x + 14.0f, cardTop.y + 34.0f),
            ImVec2(cardBottom.x - 14.0f, cardTop.y + 34.0f));

        const float stripY = cardTop.y + 44.0f;
        const float pillH = 28.0f;
        auto DrawPill = [&](const char* id, const char* label, float rightX, float w,
                            bool enabled, ImU32 tint, ImVec4 tintFg) -> bool
        {
            const ImVec2 b0(rightX - w, stripY);
            const ImVec2 b1(rightX, stripY + pillH);
            ImGui::SetCursorScreenPos(b0);
            char bid[64];
            snprintf(bid, sizeof(bid), "##bios_%s", id);
            const bool hit = ImGui::InvisibleButton(bid, ImVec2(w, pillH)) && enabled && !busy;
            const bool hov = ImGui::IsItemHovered() && !ImGui::IsItemActive();

            ImU32 bg = tint ? tint : Color(255, 255, 255, 8);
            ImVec4 fg = tint ? tintFg : colors.TextSecondary;
            if (!enabled || busy)
            {
                bg = Color(255, 255, 255, 5);
                fg = colors.TextDisabled;
            }
            else if (hov)
            {
                bg = tint ? (ImU32)Color(252, 176, 55) : Color(240, 240, 243);
                fg = tint ? ImVec4(0.047f, 0.04f, 0.0f, 1.0f)
                          : ImVec4(0.047f, 0.047f, 0.055f, 1.0f);
            }
            drawList->AddRectFilled(b0, b1, bg, 8.0f);
            const float lblW = Components::TextWidth(label, typography.Small);
            const float lblH = Components::TextHeight(typography.Small);
            Components::DrawTextAt(ImVec2(b0.x + (w - lblW) * 0.5f,
                b0.y + (pillH - lblH) * 0.5f), label, typography.Small, fg);
            return hit;
        };

        float rx = contentRight - 14.0f;
        const int changedNow = app.bios_changed_count();
        const bool hitImport = DrawPill("import", "Import Via SCEWIN", rx, 150.0f,
            changedNow > 0, Color(250, 164, 26, 30), ImVec4(0.98f, 0.76f, 0.22f, 1.0f));
        if (hitImport)
            app.bios_import();
        rx -= 160.0f;
        if (DrawPill("rec", "Recommended", rx, 132.0f, total > 0, 0, {}))
            app.bios_recommend_all();
        rx -= 142.0f;
        if (DrawPill("exp", "Export Settings", rx, 132.0f, true, 0, {}))
            app.bios_export();

        {
            const float pillsLeft = rx - 12.0f;
            const std::string s = Fitted(app.bios_status(),
                pillsLeft - (contentLeft + 14.0f), typography.Small);
            Components::DrawTextAt(ImVec2(contentLeft + 14.0f, stripY + 5.0f),
                s.c_str(), typography.Small, colors.TextSecondary);
        }

        Components::DrawTextAt(ImVec2(contentLeft + 14.0f, stripY + 32.0f),
            "BIOS Tweaker Is For Intel CPUs And Desktop PCs Only - "
            "Apply Via SCEWIN or manually in BIOS setup.",
            typography.Small, ImVec4(1.0f, 0.80f, 0.25f, 1.0f));
        Components::DrawTextAt(ImVec2(contentLeft + 14.0f, stripY + 52.0f),
            "SCEWIN writes the BIOS NVRAM directly. "
            "C:\\Nvrx\\BIOS\\nvram.txt.bak restores the previous state.",
            typography.Small, ImVec4(1.0f, 0.80f, 0.25f, 0.55f));

        const float headerH = 124.0f;

        ImGui::PushStyleColor(ImGuiCol_ScrollbarBg, ImVec4(0, 0, 0, 0));
        ImGui::PushStyleColor(ImGuiCol_ScrollbarGrab, ImVec4(1, 1, 1, 0.10f));
        ImGui::PushStyleColor(ImGuiCol_ScrollbarGrabHovered, ImVec4(1, 1, 1, 0.22f));
        ImGui::PushStyleColor(ImGuiCol_ScrollbarGrabActive, ImVec4(1, 1, 1, 0.32f));
        ImGui::PushStyleVar(ImGuiStyleVar_ScrollbarSize, 4.0f);
        ImGui::PushStyleVar(ImGuiStyleVar_ScrollbarRounding, 2.0f);
        ImGui::SetCursorScreenPos(ImVec2(contentLeft - 14.0f, cardTop.y + headerH));
        ImGui::BeginChild("##bios_scroll",
            ImVec2(contentRight - contentLeft + 28.0f,
                cardBottom.y - (cardTop.y + headerH) - 6.0f),
            ImGuiChildFlags_None, ImGuiWindowFlags_NoBackground);

        ImDrawList* cDL = ImGui::GetWindowDrawList();
        const float scrollShift = ImGui::GetScrollY();
        float rowY = cardTop.y + headerH + 4.0f - scrollShift;
        const float rowH = 64.0f;
        int count = 0;

        std::vector<std::string> labelsBuf;
        std::vector<const char*> labelsPtr;
        std::string lastGroup;

        for (int i = 0; i < total; ++i)
        {
            nvrx::app::BiosItem it;
            if (!app.bios_item(i, &it))
                continue;
            if (!FilterMatch(it.title.c_str(), filter) && !FilterMatch(it.detail.c_str(), filter))
                continue;
            ++count;

            if (it.group != lastGroup)
            {
                lastGroup = it.group;
                rowY += 6.0f;
                Components::DrawTextAt(ImVec2(contentLeft + 16.0f, rowY),
                    it.group.c_str(), typography.Small, colors.TextPrimary);
                cDL->AddLine(ImVec2(contentLeft + 160.0f, rowY + 9.0f),
                    ImVec2(contentRight - 14.0f, rowY + 9.0f), Color(255, 255, 255, 14), 1.0f);
                rowY += 26.0f;
            }

            const ImVec2 r0(contentLeft + 14.0f, rowY);
            const ImVec2 r1(contentRight - 14.0f, rowY + rowH);

            if (ImGui::IsMouseHoveringRect(r0, r1))
                cDL->AddRectFilled(r0, r1, Color(255, 255, 255, 7), 10.0f);
            else if (count > 1)
                cDL->AddLine(ImVec2(r0.x + 42.0f, r0.y), ImVec2(r1.x - 42.0f - 160.0f, r0.y),
                    Color(255, 255, 255, 5), 1.0f);

            const ImVec2 dc(r0.x + 16.0f, r0.y + rowH * 0.5f);
            if (!it.manual && it.pick >= 0 && it.changed)
            {
                cDL->AddCircleFilled(dc, 6.5f, Color(250, 164, 26, 46), 20);
                cDL->AddCircleFilled(dc, 3.5f, Color(250, 164, 26), 20);
            }
            else if (!it.manual && !it.current.empty() && it.current == it.recommended)
            {
                cDL->AddCircleFilled(dc, 6.5f, Color(63, 185, 80, 46), 20);
                cDL->AddCircleFilled(dc, 3.5f, Color(63, 185, 80), 20);
            }
            else
            {
                cDL->AddCircle(dc, 4.0f, it.manual ? Color(255, 255, 255, 22) : Color(255, 255, 255, 36), 24, 1.6f);
            }

            const bool hasOptions = !it.manual && app.bios_option_count(i) > 0;
            const float ddRight = r1.x - 12.0f;
            const float textMax = (ddRight - (hasOptions ? 202.0f : 0.0f) - 26.0f) - (r0.x + 38.0f);

            const std::string title = Fitted(it.title.c_str(), textMax, typography.BodyMedium);
            Components::DrawTextAt(ImVec2(r0.x + 38.0f, r0.y + 8.0f), title.c_str(),
                typography.BodyMedium, colors.TextPrimary);

            {
                const char* lbl = it.manual ? "Not On Board"
                    : (it.typed ? "Set In BIOS" : "On Board");
                const ImU32 bgC = it.manual ? Color(255, 255, 255, 8) : Color(255, 255, 255, 10);
                const ImVec4 fgC = it.manual
                    ? ImVec4(1.0f, 0.80f, 0.25f, 0.75f) : colors.TextDisabled;
                const float cw = Components::TextWidth(lbl, typography.Small) + 14.0f;
                const float chipX = r0.x + 38.0f
                    + Components::TextWidth(title.c_str(), typography.BodyMedium) + 10.0f;
                if (chipX + cw < (hasOptions ? ddRight - 202.0f : ddRight - 8.0f))
                {
                    cDL->AddRectFilled(ImVec2(chipX, r0.y + 8.0f),
                        ImVec2(chipX + cw, r0.y + 25.0f), bgC, 8.0f);
                    const float ch = Components::TextHeight(typography.Small);
                    Components::DrawTextAt(ImVec2(chipX + 7.0f,
                        r0.y + 8.0f + (17.0f - ch) * 0.5f), lbl, typography.Small, fgC);
                }
            }

            const std::string dfitted = Fitted(it.detail.c_str(), textMax, typography.Small);
            Components::DrawTextAt(ImVec2(r0.x + 38.0f, r0.y + 28.0f), dfitted.c_str(),
                typography.Small, it.manual ? colors.TextDisabled : colors.TextSecondary);

            if (hasOptions)
            {
                labelsBuf.clear();
                labelsPtr.clear();
                const int n = app.bios_option_count(i);

                int shown = it.pick;
                if (shown < 0)
                    for (int o = 0; o < n; ++o)
                        if (app.bios_option(i, o) == it.current) { shown = o; break; }
                if (shown < 0) shown = 0;

                for (int o = 0; o < n; ++o)
                    labelsBuf.push_back(
                        Fitted(app.bios_option(i, o).c_str(), 118.0f, typography.Small));
                for (const std::string& l : labelsBuf)
                    labelsPtr.push_back(l.c_str());

                const bool ddEnabled = !busy;
                char ddId[32];
                snprintf(ddId, sizeof(ddId), "##bios_dd_%d", i);
                if (DrawDropdown(ddId, ImVec2(ddRight - 190.0f, rowY + 14.0f),
                    190.0f, "", shown, labelsPtr.data(), n, ddEnabled))
                {
                    app.bios_set_pick(i, shown);
                }

                if (it.changed)
                    cDL->AddRect(ImVec2(ddRight - 154.0f, rowY + 11.0f),
                        ImVec2(ddRight, rowY + 42.0f), Color(250, 164, 26, 140), 12.0f, 0, 1.4f);
            }

            if (!it.manual)
            {
                const float vx = r0.x + 38.0f;
                const float vy = r0.y + 46.0f;
                const std::string nowSeg =
                    Fitted(std::string("Now: ").append(
                        it.current.empty() ? "-" : it.current).c_str(),
                        textMax, typography.Small);
                Components::DrawTextAt(ImVec2(vx, vy), nowSeg.c_str(),
                    typography.Small, colors.TextSecondary);
                if (!it.recommended.empty())
                {
                    const float w1 = Components::TextWidth(nowSeg.c_str(), typography.Small) + 20.0f;
                    if (w1 < textMax)
                    {
                        const bool match = it.recommended == it.current;
                        const float lblW = Components::TextWidth("Set To: ", typography.Small);
                        const std::string valSeg = Fitted(it.recommended.c_str(),
                            textMax - w1 - lblW, typography.Small);
                        Components::DrawTextAt(ImVec2(vx + w1, vy), "Set To: ",
                            typography.Small, colors.TextDisabled);
                        Components::DrawTextAt(ImVec2(vx + w1 + lblW, vy), valSeg.c_str(),
                            typography.Small,
                            match ? ImVec4(0.52f, 0.86f, 0.62f, 1.0f)
                                  : ImVec4(0.98f, 0.76f, 0.22f, 1.0f));
                    }
                }
            }

            rowY += rowH;
        }

        if (!count)
        {

            Components::DrawTextAt(ImVec2(contentLeft + 14.0f, rowY + 20.0f),
                "Nothing loaded yet", typography.BodyMedium, colors.TextPrimary);
            Components::DrawTextAt(ImVec2(contentLeft + 14.0f, rowY + 42.0f),
                "Checklist is for Intel CPUs and desktop PCs only - most options "
                "do not exist on notebooks or AMD boards.",
                typography.Small, ImVec4(1.0f, 0.80f, 0.25f, 0.75f));
            Components::DrawTextAt(ImVec2(contentLeft + 14.0f, rowY + 60.0f),
                "Press Export Settings - it stages the SCEWIN tool (one-time download) "
                "and dumps the current BIOS setup to C:\\Nvrx\\BIOS\\nvram.txt.",
                typography.Small, colors.TextSecondary);
            Components::DrawTextAt(ImVec2(contentLeft + 14.0f, rowY + 78.0f),
                "Pick values, press Recommended for the jecug defaults, then "
                "Import Via SCEWIN.",
                typography.Small, colors.TextSecondary);
            rowY += 114.0f;
        }
        else
        {

            cDL->AddLine(ImVec2(contentLeft + 14.0f, rowY), ImVec2(contentRight - 14.0f, rowY),
                Color(255, 255, 255, 5), 1.0f);
            Components::DrawTextAt(ImVec2(contentLeft + 14.0f, rowY + 8.0f),
                "Now = current dump value - Set To = jecug recommendation - green dot = already matching",
                typography.Small, colors.TextSecondary);
            rowY += 30.0f;
        }

        ImGui::SetCursorScreenPos(ImVec2(contentLeft, rowY));
        ImGui::Dummy(ImVec2(contentRight - contentLeft, 20.0f));

        ImGui::EndChild();
        ImGui::PopStyleColor(4);
        ImGui::PopStyleVar(2);
    }

    void MainMenuScreen::DrawGameScreen(ImDrawList* drawList, ImVec2 cardTop,
        ImVec2 cardBottom, const char* filter)
    {
        nvrx::app::App& app = nvrx::app::App::get();
        const ThemeColors& colors = Theme::Get().Colors();
        const ThemeTypography& typography = Theme::Get().Typography();
        const bool busy = app.busy();

        const float contentLeft = cardTop.x;
        const float contentRight = cardBottom.x;

        drawList->AddRectFilled(cardTop, cardBottom, Color(17, 20, 27), 14.0f);
        drawList->AddRect(cardTop, cardBottom, Color(255, 255, 255, 10), 14.0f);
        char titleBuf[64];
        snprintf(titleBuf, sizeof(titleBuf), "Game Tweaker - %s",
            app.game_tab_name(app.game_active_tab()));
        Components::DrawTextAt(ImVec2(cardTop.x + 14.0f, cardTop.y + 11.0f),
            titleBuf, typography.BodyMedium, colors.TextPrimary);

        const int total = app.game_item_count();
        int visible = 0;
        for (int i = 0; i < total; ++i)
        {
            nvrx::app::GameItem probe;
            if (app.game_item(i, &probe)
                && (FilterMatch(probe.title.c_str(), filter)
                 || FilterMatch(probe.detail.c_str(), filter)))
            {
                ++visible;
            }
        }

        const int tabN = app.game_tab_count() > 8 ? 8 : app.game_tab_count();
        float tabW[8] = {};
        float tabTotal = 0.0f;
        for (int i = 0; i < tabN; ++i)
        {
            tabW[i] = Components::TextWidth(app.game_tab_name(i), typography.Small) + 26.0f;
            tabTotal += tabW[i] + 8.0f;
        }
        const float tabsLeft = cardBottom.x - 14.0f - tabTotal;

        {
            char cnt[24];
            snprintf(cnt, sizeof(cnt), "%d", visible);
            const float cntW = Components::TextWidth(cnt, typography.Small) + 18.0f;
            const ImVec2 c0(tabsLeft - 12.0f - cntW, cardTop.y + 8.0f);
            const ImVec2 c1(tabsLeft - 12.0f, cardTop.y + 30.0f);
            drawList->AddRectFilled(c0, c1, Color(255, 255, 255, 7), 11.0f);
            drawList->AddRect(c0, c1, Color(255, 255, 255, 12), 11.0f);
            const float cntH = Components::TextHeight(typography.Small);
            Components::DrawTextAt(ImVec2(c0.x + 9.0f, c0.y + (22.0f - cntH) * 0.5f),
                cnt, typography.Small, colors.TextSecondary);
        }

        {
            float tx = cardBottom.x - 14.0f;
            for (int i = tabN - 1; i >= 0; --i)
            {
                const float w = tabW[i];
                const ImVec2 b0(tx - w, cardTop.y + 8.0f);
                const ImVec2 b1(tx, cardTop.y + 30.0f);
                ImGui::SetCursorScreenPos(b0);
                char tb[24];
                snprintf(tb, sizeof(tb), "##game_tab_%d", i);
                const bool hit = ImGui::InvisibleButton(tb, ImVec2(w, 22.0f)) && !busy;
                const bool hov = ImGui::IsItemHovered() && !ImGui::IsItemActive();
                const bool here = (i == app.game_active_tab());

                ImU32 bg = here ? Color(255, 255, 255, 26) : Color(255, 255, 255, 8);
                ImVec4 fg = here ? colors.TextPrimary : colors.TextSecondary;
                if (!here && !app.game_tab_ready(i))
                    fg = colors.TextDisabled;
                if (busy)
                {
                    bg = Color(255, 255, 255, 5);
                    fg = colors.TextDisabled;
                }
                else if (hov && !here)
                {
                    bg = Color(255, 255, 255, 18);
                    fg = colors.TextPrimary;
                }
                drawList->AddRectFilled(b0, b1, bg, 8.0f);
                drawList->AddRect(b0, b1, Color(255, 255, 255, 12), 8.0f);
                const float lw = Components::TextWidth(app.game_tab_name(i), typography.Small);
                const float lh = Components::TextHeight(typography.Small);
                Components::DrawTextAt(
                    ImVec2(b0.x + (w - lw) * 0.5f, b0.y + (22.0f - lh) * 0.5f),
                    app.game_tab_name(i), typography.Small, fg);
                if (hit)
                    app.game_set_active_tab(i);
                tx -= w + 8.0f;
            }
        }

        DrawDivider(ImVec2(cardTop.x + 14.0f, cardTop.y + 34.0f),
            ImVec2(cardBottom.x - 14.0f, cardTop.y + 34.0f));

        const float stripY = cardTop.y + 44.0f;
        const float pillH = 28.0f;
        auto DrawPill = [&](const char* id, const char* label, float rightX, float w,
                            bool enabled, ImU32 tint, ImVec4 tintFg) -> bool
        {
            const ImVec2 b0(rightX - w, stripY);
            const ImVec2 b1(rightX, stripY + pillH);
            ImGui::SetCursorScreenPos(b0);
            char bid[64];
            snprintf(bid, sizeof(bid), "##game_%s", id);
            const bool hit = ImGui::InvisibleButton(bid, ImVec2(w, pillH)) && enabled && !busy;
            const bool hov = ImGui::IsItemHovered() && !ImGui::IsItemActive();

            ImU32 bg = tint ? tint : Color(255, 255, 255, 8);
            ImVec4 fg = tint ? tintFg : colors.TextSecondary;
            if (!enabled || busy)
            {
                bg = Color(255, 255, 255, 5);
                fg = colors.TextDisabled;
            }
            else if (hov)
            {
                bg = tint ? (ImU32)Color(252, 176, 55) : Color(240, 240, 243);
                fg = tint ? ImVec4(0.047f, 0.04f, 0.0f, 1.0f)
                          : ImVec4(0.047f, 0.047f, 0.055f, 1.0f);
            }
            drawList->AddRectFilled(b0, b1, bg, 8.0f);
            const float lblW = Components::TextWidth(label, typography.Small);
            const float lblH = Components::TextHeight(typography.Small);
            Components::DrawTextAt(ImVec2(b0.x + (w - lblW) * 0.5f,
                b0.y + (pillH - lblH) * 0.5f), label, typography.Small, fg);
            return hit;
        };

        float rx = contentRight - 14.0f;
        const int changedNow = app.game_changed_count();
        if (DrawPill("apply", "Apply Settings", rx, 138.0f,
            changedNow > 0 || app.game_item_count() > 0,
            Color(250, 164, 26, 30), ImVec4(0.98f, 0.76f, 0.22f, 1.0f)))
            app.game_apply();
        rx -= 148.0f;
        if (DrawPill("rec", "Recommended", rx, 132.0f, total > 0, 0, {}))
            app.game_recommend_all();
        rx -= 142.0f;
        if (DrawPill("folder", "Open Folder", rx, 120.0f, true, 0, {}))
            app.game_open_folder();
        rx -= 132.0f;
        if (DrawPill("guide", "Guide", rx, 112.0f, app.game_guide_creatable(), 0, {}))
            app.game_open_guide();
        rx -= 126.0f;

        {
            const float pillsLeft = rx - 12.0f;
            const std::string s = Fitted(app.game_status(),
                pillsLeft - (contentLeft + 14.0f), typography.Small);
            Components::DrawTextAt(ImVec2(contentLeft + 14.0f, stripY + 5.0f),
                s.c_str(), typography.Small, colors.TextSecondary);
        }

        Components::DrawTextAt(ImVec2(contentLeft + 14.0f, stripY + 34.0f),
            app.game_banner(),
            typography.Small, ImVec4(1.0f, 0.80f, 0.25f, 1.0f));

        const float headerH = 106.0f;

        ImGui::PushStyleColor(ImGuiCol_ScrollbarBg, ImVec4(0, 0, 0, 0));
        ImGui::PushStyleColor(ImGuiCol_ScrollbarGrab, ImVec4(1, 1, 1, 0.10f));
        ImGui::PushStyleColor(ImGuiCol_ScrollbarGrabHovered, ImVec4(1, 1, 1, 0.22f));
        ImGui::PushStyleColor(ImGuiCol_ScrollbarGrabActive, ImVec4(1, 1, 1, 0.32f));
        ImGui::PushStyleVar(ImGuiStyleVar_ScrollbarSize, 4.0f);
        ImGui::PushStyleVar(ImGuiStyleVar_ScrollbarRounding, 2.0f);
        ImGui::SetCursorScreenPos(ImVec2(contentLeft - 14.0f, cardTop.y + headerH));
        ImGui::BeginChild("##game_scroll",
            ImVec2(contentRight - contentLeft + 28.0f,
                cardBottom.y - (cardTop.y + headerH) - 6.0f),
            ImGuiChildFlags_None, ImGuiWindowFlags_NoBackground);

        ImDrawList* cDL = ImGui::GetWindowDrawList();
        const float scrollShift = ImGui::GetScrollY();
        float rowY = cardTop.y + headerH + 4.0f - scrollShift;
        const float rowH = 64.0f;
        int count = 0;

        std::vector<std::string> labelsBuf;
        std::vector<const char*> labelsPtr;

        for (int i = 0; i < total; ++i)
        {
            nvrx::app::GameItem it;
            if (!app.game_item(i, &it))
                continue;
            if (!FilterMatch(it.title.c_str(), filter) && !FilterMatch(it.detail.c_str(), filter))
                continue;
            ++count;

            const ImVec2 r0(contentLeft + 14.0f, rowY);
            const ImVec2 r1(contentRight - 14.0f, rowY + rowH);

            if (ImGui::IsMouseHoveringRect(r0, r1))
                cDL->AddRectFilled(r0, r1, Color(255, 255, 255, 7), 10.0f);
            else if (count > 1)
                cDL->AddLine(ImVec2(r0.x + 42.0f, r0.y), ImVec2(r1.x - 42.0f - 160.0f, r0.y),
                    Color(255, 255, 255, 5), 1.0f);

            const ImVec2 dc(r0.x + 16.0f, r0.y + rowH * 0.5f);
            if (!it.missing && it.pick >= 0 && it.changed)
            {
                cDL->AddCircleFilled(dc, 6.5f, Color(250, 164, 26, 46), 20);
                cDL->AddCircleFilled(dc, 3.5f, Color(250, 164, 26), 20);
            }
            else if (!it.missing && !it.current.empty()
                && it.current == it.recommended)
            {
                cDL->AddCircleFilled(dc, 6.5f, Color(63, 185, 80, 46), 20);
                cDL->AddCircleFilled(dc, 3.5f, Color(63, 185, 80), 20);
            }
            else
            {
                cDL->AddCircle(dc, 4.0f, it.missing ? Color(255, 255, 255, 22)
                                                    : Color(255, 255, 255, 36),
                    24, 1.6f);
            }

            const bool hasOptions = app.game_option_count(i) > 0;
            const float ddRight = r1.x - 12.0f;
            const float textMax = (ddRight - (hasOptions ? 202.0f : 0.0f) - 26.0f)
                - (r0.x + 38.0f);

            const std::string title = Fitted(it.title.c_str(), textMax, typography.BodyMedium);
            Components::DrawTextAt(ImVec2(r0.x + 38.0f, r0.y + 8.0f), title.c_str(),
                typography.BodyMedium, colors.TextPrimary);

            {
                const char* lbl = it.missing ? "Not In File" : "In File";
                const ImU32 bgC = it.missing ? Color(255, 255, 255, 8) : Color(255, 255, 255, 10);
                const ImVec4 fgC = it.missing
                    ? ImVec4(1.0f, 0.80f, 0.25f, 0.75f) : colors.TextDisabled;
                const float cw = Components::TextWidth(lbl, typography.Small) + 14.0f;
                const float chipX = r0.x + 38.0f
                    + Components::TextWidth(title.c_str(), typography.BodyMedium) + 10.0f;
                if (chipX + cw < (hasOptions ? ddRight - 202.0f : ddRight - 8.0f))
                {
                    cDL->AddRectFilled(ImVec2(chipX, r0.y + 8.0f),
                        ImVec2(chipX + cw, r0.y + 25.0f), bgC, 8.0f);
                    const float ch = Components::TextHeight(typography.Small);
                    Components::DrawTextAt(ImVec2(chipX + 7.0f,
                        r0.y + 8.0f + (17.0f - ch) * 0.5f), lbl, typography.Small, fgC);
                }
            }

            const std::string dfitted = Fitted(it.detail.c_str(), textMax, typography.Small);
            Components::DrawTextAt(ImVec2(r0.x + 38.0f, r0.y + 28.0f), dfitted.c_str(),
                typography.Small, it.missing ? colors.TextDisabled : colors.TextSecondary);

            if (hasOptions)
            {
                labelsBuf.clear();
                labelsPtr.clear();
                const int n = app.game_option_count(i);

                int shown = it.pick;
                if (shown < 0)
                    shown = 0;

                for (int o = 0; o < n; ++o)
                    labelsBuf.push_back(
                        Fitted(app.game_option(i, o).c_str(), 118.0f, typography.Small));
                for (const std::string& l : labelsBuf)
                    labelsPtr.push_back(l.c_str());

                const bool ddEnabled = !busy;
                char ddId[32];
                snprintf(ddId, sizeof(ddId), "##game_dd_%d", i);
                if (DrawDropdown(ddId, ImVec2(ddRight - 190.0f, rowY + 14.0f),
                    190.0f, "", shown, labelsPtr.data(), n, ddEnabled))
                {
                    app.game_set_pick(i, shown);
                }

                if (it.changed)
                    cDL->AddRect(ImVec2(ddRight - 154.0f, rowY + 11.0f),
                        ImVec2(ddRight, rowY + 42.0f), Color(250, 164, 26, 140), 12.0f, 0, 1.4f);
            }

            {
                const float vx = r0.x + 38.0f;
                const float vy = r0.y + 46.0f;
                const std::string nowLbl =
                    it.current.empty() ? std::string("-") : it.current;
                const std::string nowSeg =
                    Fitted(std::string("Now: ").append(nowLbl).c_str(),
                        textMax, typography.Small);
                Components::DrawTextAt(ImVec2(vx, vy), nowSeg.c_str(),
                    typography.Small, colors.TextSecondary);
                if (!it.recommended.empty())
                {
                    const float w1 = Components::TextWidth(nowSeg.c_str(), typography.Small) + 20.0f;
                    if (w1 < textMax)
                    {
                        const bool match = it.current == it.recommended;
                        const float lblW = Components::TextWidth("Set To: ", typography.Small);
                        const std::string valSeg = Fitted(it.recommended.c_str(),
                            textMax - w1 - lblW, typography.Small);
                        Components::DrawTextAt(ImVec2(vx + w1, vy), "Set To: ",
                            typography.Small, colors.TextDisabled);
                        Components::DrawTextAt(ImVec2(vx + w1 + lblW, vy), valSeg.c_str(),
                            typography.Small,
                            match ? ImVec4(0.52f, 0.86f, 0.62f, 1.0f)
                                  : ImVec4(0.98f, 0.76f, 0.22f, 1.0f));
                    }
                }
            }

            rowY += rowH;
        }

        if (!count)
        {

            const int at = app.game_active_tab();
            const std::string nm = app.game_tab_name(at);
            const std::string fn = app.game_file_name(at);
            Components::DrawTextAt(ImVec2(contentLeft + 14.0f, rowY + 20.0f),
                (nm + " config not found").c_str(),
                typography.BodyMedium, colors.TextPrimary);
            Components::DrawTextAt(ImVec2(contentLeft + 14.0f, rowY + 42.0f),
                ("Launch " + nm + " once so it creates " + fn
                 + " - the optimizer then lists every setting with its live "
                   "value.").c_str(),
                typography.Small, colors.TextSecondary);
            Components::DrawTextAt(ImVec2(contentLeft + 14.0f, rowY + 60.0f),
                ("Pick values, press Recommended for the jecug defaults, then "
                 "Apply Settings with " + nm + " closed.").c_str(),
                typography.Small, colors.TextSecondary);
            rowY += 96.0f;
        }
        else
        {

            cDL->AddLine(ImVec2(contentLeft + 14.0f, rowY), ImVec2(contentRight - 14.0f, rowY),
                Color(255, 255, 255, 5), 1.0f);
            Components::DrawTextAt(ImVec2(contentLeft + 14.0f, rowY + 8.0f),
                "Now = value from your config - Set To = recommended - green dot = already matching",
                typography.Small, colors.TextSecondary);
            rowY += 30.0f;
        }

        ImGui::SetCursorScreenPos(ImVec2(contentLeft, rowY));
        ImGui::Dummy(ImVec2(contentRight - contentLeft, 20.0f));

        ImGui::EndChild();
        ImGui::PopStyleColor(4);
        ImGui::PopStyleVar(2);
    }

    void MainMenuScreen::DrawSystemCard(ImDrawList* drawList, ImVec2 mn, ImVec2 mx)
    {
        const ThemeColors& colors = Theme::Get().Colors();
        const ThemeTypography& typography = Theme::Get().Typography();
        nvrx::app::App& app = nvrx::app::App::get();

        drawList->AddRectFilled(mn, mx, Color(17, 20, 27), 14.0f);
        drawList->AddRect(mn, mx, Color(255, 255, 255, 10), 14.0f);
        Components::DrawTextAt(ImVec2(mn.x + 18.0f, mn.y + 9.0f),
            "System Status", typography.BodyMedium, colors.TextPrimary);
        Components::DrawTextAt(ImVec2(mn.x + 18.0f, mn.y + 30.0f),
            "Hardware and operating system", typography.Small, colors.TextSecondary);

        const float w = mx.x - mn.x - 36.0f;
        DrawStatusRow(ImVec2(mn.x + 18.0f, mn.y + 52.0f), w, "OS",
            Fitted(app.sys_os().c_str(), w - 92.0f, typography.Small).c_str(), true);
        DrawStatusRow(ImVec2(mn.x + 18.0f, mn.y + 72.0f), w, "PC",
            Fitted((app.sys_pc() + "  -  " + app.sys_user()).c_str(), w - 92.0f,
                typography.Small).c_str(), true);
        DrawStatusRow(ImVec2(mn.x + 18.0f, mn.y + 92.0f), w, "RAM",
            app.sys_ram().c_str(), true);
        DrawStatusRow(ImVec2(mn.x + 18.0f, mn.y + 112.0f), w, "CPU",
            FittedByCount(app.sys_cpu().c_str(), 40).c_str(), true);
        DrawStatusRow(ImVec2(mn.x + 18.0f, mn.y + 132.0f), w, "GPU",
            FittedByCount(app.sys_gpu().c_str(), 40).c_str(), true);
    }

    void MainMenuScreen::DrawUtilityCard(ImDrawList* drawList, ImVec2 mn, ImVec2 mx)
    {
        const ThemeColors& colors = Theme::Get().Colors();
        const ThemeTypography& typography = Theme::Get().Typography();
        nvrx::app::App& app = nvrx::app::App::get();
        (void)colors;

        drawList->AddRectFilled(mn, mx, Color(17, 20, 27), 14.0f);
        drawList->AddRect(mn, mx, Color(255, 255, 255, 10), 14.0f);
        Components::DrawTextAt(ImVec2(mn.x + 18.0f, mn.y + 9.0f),
            "Utility", typography.BodyMedium, colors.TextPrimary);
        Components::DrawTextAt(ImVec2(mn.x + 18.0f, mn.y + 30.0f),
            "Maintenance and information", typography.Small, colors.TextSecondary);

        const float w = mx.x - mn.x - 36.0f;
        DrawStatusRow(ImVec2(mn.x + 18.0f, mn.y + 52.0f), w,
            "Engine", "Embedded Batch Scripts", true);
        char scriptCount[64];
        snprintf(scriptCount, sizeof(scriptCount), "%d Total", app.tweak_count());
        DrawStatusRow(ImVec2(mn.x + 18.0f, mn.y + 72.0f), w,
            "Tweaks", scriptCount, true);

        if (DrawSmallButton("##set_open_folder", ImVec2(mn.x + 18.0f, mn.y + 98.0f),
            168.0f, 28.0f, "Open Utility Folder", false, false, true))
            app.open_folder();

        const std::string path = FittedByCount(app.exe_path().c_str(), 40);
        Components::DrawTextAt(ImVec2(mn.x + 18.0f, mx.y - 30.0f),
            ("by jecug  -  " + path).c_str(), typography.Small, ImVec4(0.47f, 0.47f, 0.51f, 1.0f));
    }

    void MainMenuScreen::DrawMergedOverview(ImDrawList* drawList, ImVec2 cardTop, ImVec2 cardBottom)
    {
        const float totalH = cardBottom.y - cardTop.y;
        const float gap = 24.0f;
        const float row1H = (std::min)(170.0f, (std::max)(120.0f, totalH * 0.5f - gap * 0.5f));
        const float row2H = (std::max)(110.0f, totalH - row1H - gap);
        const float leftW = 368.0f;

        const float row2Y = cardTop.y + row1H + gap;
        const ImVec2 a1(cardTop.x, cardTop.y);
        const ImVec2 a2(cardTop.x + leftW, cardTop.y + row1H);
        const ImVec2 b1(cardTop.x + leftW + gap, cardTop.y);
        const ImVec2 b2(cardBottom.x, cardTop.y + row1H);
        const ImVec2 c1(cardTop.x, row2Y);
        const ImVec2 c2(cardTop.x + leftW, row2Y + row2H);
        const ImVec2 d1(cardTop.x + leftW + gap, row2Y);
        const ImVec2 d2(cardBottom.x, row2Y + row2H);

        DrawActionsCard(drawList, a1, a2);
        DrawActivityCard(drawList, b1, b2);
        DrawSystemCard(drawList, c1, c2);
        DrawUtilityCard(drawList, d1, d2);
    }

    void MainMenuScreen::DrawStatusStrip(ImDrawList* drawList, ImVec2 mainMin, ImVec2 mainMax)
    {
        const ThemeColors& colors = Theme::Get().Colors();
        const ThemeTypography& typography = Theme::Get().Typography();
        nvrx::app::App& app = nvrx::app::App::get();

        const float inset = 28.0f;
        DrawDivider(ImVec2(mainMin.x + inset, mainMax.y - 32.0f),
            ImVec2(mainMax.x - inset, mainMax.y - 32.0f));

        char ver[92];
        snprintf(ver, sizeof(ver), "v3.0  -  %d tweaks  -  %s",
            app.tweak_count(), app.is_admin() ? "Admin" : "Not Admin");
        Components::DrawTextAt(ImVec2(mainMin.x + inset, mainMax.y - 24.0f), ver,
            typography.Small, colors.TextSecondary);

        const bool busy = app.busy();
        if (busy)
        {
            const float ta = static_cast<float>(ImGui::GetTime()) * 5.0f;
            drawList->PathArcTo(ImVec2(mainMax.x - inset - 6.0f, mainMax.y - 19.0f), 5.0f, ta, ta + 4.4f);
            drawList->PathStroke(Color(255, 255, 255, 230), 0, 1.6f);
        }
        char line[128]{};
        if (busy && app.total_count() > 0)
        {
            const std::string cur = Fitted(app.current().c_str(), 380.0f, typography.Small);
            snprintf(line, sizeof(line), "%d/%d  %s",
                app.done_count(), app.total_count(), cur.c_str());
        }
        else
        {
            snprintf(line, sizeof(line), "%s", app.status().c_str());
        }
        const float lineW = Components::TextWidth(line, typography.Small);
        Components::DrawTextAt(ImVec2(mainMax.x - inset - 14.0f - lineW, mainMax.y - 24.0f), line,
            typography.Small, busy ? colors.TextPrimary : colors.TextSecondary);

        if (busy && app.total_count() > 0)
        {
            const float frac = (std::max)(0.0f, (std::min)(1.0f,
                static_cast<float>(app.done_count()) / static_cast<float>(app.total_count())));
            const float trackY = mainMax.y - 7.0f;
            drawList->AddRectFilled(ImVec2(mainMin.x + inset, trackY),
                ImVec2(mainMax.x - inset, trackY + 2.0f), Color(255, 255, 255, 14), 1.0f);
            if (frac > 0.001f)
                drawList->AddRectFilled(ImVec2(mainMin.x + inset, trackY),
                    ImVec2(mainMin.x + inset + (mainMax.x - mainMin.x - inset * 2.0f) * frac,
                        trackY + 2.0f),
                    Color(240, 240, 243, 200), 1.0f);
        }
    }

    void MainMenuScreen::Draw(ImVec2 regionMin, ImVec2 regionSize)
    {
        const PanelRects panels = GetPanelRects(regionMin, regionSize);

        Components::GlassPanelStyle topBarStyle;
        topBarStyle.Radius = kTopBarRadius;
        topBarStyle.Shadow = false;
        topBarStyle.Sheen = false;
        topBarStyle.Border = false;
        topBarStyle.CustomSurface = true;
        topBarStyle.SurfaceColor = kTopSurface;
        Components::DrawGlassPanel(panels.TopMin, panels.TopMax, topBarStyle);

        Components::GlassPanelStyle panelStyle;
        panelStyle.Radius = kPanelRadius;
        panelStyle.Shadow = false;
        panelStyle.Sheen = false;
        panelStyle.Border = false;
        panelStyle.CustomSurface = true;
        panelStyle.SurfaceColor = kMainSurface;
        Components::DrawGlassPanel(panels.MainMin, panels.MainMax, panelStyle);

        ImDrawList* drawList = ImGui::GetWindowDrawList();

        if (m_ActiveTab != m_LastTab)
        {
            if (m_LastTab == 1)
                m_Filter[0] = '\0';
            m_LastTab = m_ActiveTab;
        }

        DrawTopBar(drawList, panels);

        if (m_ActiveTab == 1)
            DrawGroupRail(drawList, panels);

        const ImVec2 mainMin = panels.MainMin;
        const ImVec2 mainMax = panels.MainMax;
        const float contentTop = mainMin.y + 92.0f;
        const float contentBottom = mainMax.y - 44.0f;

        DrawBrand(drawList, mainMin);

        if (m_ActiveTab == 1)
        {
            const float width = 220.0f;
            const float x = mainMax.x - 22.0f - width;
            const bool focusRequest =
                ImGui::GetIO().KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_F, false);
            DrawSearchField(ImVec2(x, mainMin.y + 12.0f), width,
                m_Filter, sizeof(m_Filter), focusRequest);
        }

        const float pageEase = 1.0f - (1.0f - m_PageTransitionT) * (1.0f - m_PageTransitionT);
        const float pageOffset = (1.0f - pageEase) * 6.0f;
        RenderOpacity::Push(pageEase);

        const ImVec2 cardTop(panels.MainMin.x + 28.0f, contentTop + pageOffset);
        const ImVec2 cardBottom(panels.MainMax.x - 28.0f, contentBottom);
        switch (m_ActiveTab)
        {
        case 0: DrawMergedOverview(drawList, cardTop, cardBottom); break;
        case 1: DrawListPage(drawList, cardTop, cardBottom, 1); break;
        default: break;
        }

        RenderOpacity::Pop();

        DrawStatusStrip(drawList, mainMin, mainMax);
    }
}
