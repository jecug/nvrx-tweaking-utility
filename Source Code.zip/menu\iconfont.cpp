#include "iconfont.h"

namespace UI::Icons
{
    const ImWchar* SymbolRanges()
    {

        static const ImWchar ranges[] = {
            0xf00d, 0xf00d,
            0xf068, 0xf068,
            0xf002, 0xf002,
            0xf021, 0xf021,
            0xf023, 0xf023,
            0xf085, 0xf085,
            0xf1de, 0xf1de,
            0xf1eb, 0xf1eb,
            0xf1f8, 0xf1f8,
            0xf1c0, 0xf1c0,
            0xf287, 0xf287,
            0xf2db, 0xf2db,
            0xf3ed, 0xf3ed,
            0xf468, 0xf468,
            0xf53f, 0xf53f,
            0xf538, 0xf538,
            0xf625, 0xf625,
            0 };
        return ranges;
    }

    const ImWchar* BrandRanges()
    {
        static const ImWchar ranges[] = { 0xf392, 0xf392, 0 };
        return ranges;
    }
}
