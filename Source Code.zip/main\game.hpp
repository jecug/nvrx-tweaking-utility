#pragma once

#include <string>
#include <vector>

namespace nvrx { namespace game {

struct Item {
    std::string title;
    std::string detail;
    std::string current;
    std::string recommended;
    bool missing = false;
    bool changed = false;
    int pick = -1;
};

int game_count();
const char* game_name(int index);
const char* game_file(int index);
const char* game_banner(int index);
bool game_ready(int index);
int game_active();
void set_active(int index);
unsigned epoch();

bool load();
bool loaded();
void reset();
int item_count();
const Item* item(int index);
int option_count(int index);
std::string option(int index, int optionIndex);
void pick(int index, int optionIndex);
void recommend_all();
int changed_count();

bool config_file_exists();

bool config_creatable();

bool guide_creatable();
bool write_guide(std::string* outPath);

const char* config_path();
bool game_running();
bool apply();
std::string status_text();

}}
