#pragma once

#include "screen.h"
#include "texture.h"

namespace UI::Screens
{
    class MainMenuScreen : public Screen
    {
    public:
        struct PanelRects
        {
            ImVec2 TopMin;
            ImVec2 TopMax;
            ImVec2 LeftMin;
            ImVec2 LeftMax;
            ImVec2 MainMin;
            ImVec2 MainMax;
        };

        static PanelRects GetPanelRects(ImVec2 regionMin, ImVec2 regionSize);
        static float PanelRadius();

        void Initialize(ID3D11Device* device) override;
        void Update(float deltaSeconds) override;
        void Draw(ImVec2 regionMin, ImVec2 regionSize) override;

    private:
        void DrawTopBar(ImDrawList* drawList, const PanelRects& panels);
        void DrawGroupRail(ImDrawList* drawList, const PanelRects& panels);
        void DrawBrand(ImDrawList* drawList, ImVec2 mainMin);
        void DrawMergedOverview(ImDrawList* drawList, ImVec2 cardTop, ImVec2 cardBottom);
        void DrawActionsCard(ImDrawList* drawList, ImVec2 mn, ImVec2 mx);
        void DrawActivityCard(ImDrawList* drawList, ImVec2 mn, ImVec2 mx);
        void DrawSystemCard(ImDrawList* drawList, ImVec2 mn, ImVec2 mx);
        void DrawUtilityCard(ImDrawList* drawList, ImVec2 mn, ImVec2 mx);
        void DrawListPage(ImDrawList* drawList, ImVec2 cardTop, ImVec2 cardBottom, int page);
        void DrawBiosScreen(ImDrawList* drawList, ImVec2 cardTop, ImVec2 cardBottom,
            const char* filter);
        void DrawGameScreen(ImDrawList* drawList, ImVec2 cardTop, ImVec2 cardBottom,
            const char* filter);
        void DrawStatusStrip(ImDrawList* drawList, ImVec2 mainMin, ImVec2 mainMax);
        void DrawSearchField(const ImVec2& origin, float width, char* buffer,
            size_t bufferSize, bool focusRequest);
        bool DrawSmallButton(const char* id, ImVec2 origin, float width, float height,
            const char* label, bool filled, bool danger, bool enabled);

        Renderer::Texture m_Icons[2];
        static constexpr int kTabCount = 2;
        struct TabSpec
        {
            const char* Label;
        };
        TabSpec m_Tabs[kTabCount]{
            { "Overview" },
            { "Tweaks" },
        };
        float m_TabHoverT[kTabCount] = {};
        float m_PageTransitionT = 1.0f;
        int   m_ActiveTab = 0;
        int   m_LastTab = -1;

        char  m_Filter[96]{};
        char  m_SelectedGroup[64]{};
    };
}
