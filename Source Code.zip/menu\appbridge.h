#pragma once

#include <string>
#include <vector>

namespace nvrx::app {

struct LogEntry {
    std::string time;
    std::string text;
    int level = 0;
};

struct BiosItem {
    std::string title;
    std::string detail;
    std::string group;
    std::string current;
    std::string recommended;
    bool manual = false;
    bool typed = false;
    bool changed = false;
    int pick = -1;
};

struct GameItem {
    std::string title;
    std::string detail;
    std::string current;
    std::string recommended;
    bool missing = false;
    bool changed = false;
    int pick = -1;
};

class App {
public:
    static App& get();

    bool busy() const;
    int done_count() const;
    int total_count() const;
    const std::string& status() const;
    const std::string& current() const;

    bool applied(const char* id) const;

    void run_single(const char* id, const char* title);
    void run_recommended();
    void restore_point();
    void reboot_now();
    void open_folder();

    int tab() const;
    void set_tab(int tab);

    const std::string& sys_os() const;
    const std::string& sys_pc() const;
    const std::string& sys_user() const;
    const std::string& sys_ram() const;
    const std::string& sys_cpu() const;
    const std::string& sys_gpu() const;
    bool is_admin() const;
    int tweak_count() const;
    std::string exe_path() const;

    std::vector<LogEntry> log_snapshot(int maxLines) const;
    void clear_log();
    void copy_log();

    void bios_export();
    void bios_import();
    void bios_open_folder();
    int bios_item_count() const;
    bool bios_item(int index, BiosItem* out) const;
    int bios_option_count(int index) const;
    std::string bios_option(int index, int optionIndex) const;
    void bios_set_pick(int index, int optionIndex);
    void bios_recommend_all();
    int bios_changed_count() const;
    const char* bios_status() const;

    void game_apply();
    void game_open_folder();
    bool game_guide_creatable() const;
    void game_open_guide();
    int game_item_count() const;
    bool game_item(int index, GameItem* out) const;
    int game_option_count(int index) const;
    std::string game_option(int index, int optionIndex) const;
    void game_set_pick(int index, int optionIndex);
    void game_recommend_all();
    int game_changed_count() const;
    const char* game_status() const;
    int game_tab_count() const;
    const char* game_tab_name(int index) const;
    bool game_tab_ready(int index) const;
    int game_active_tab() const;
    void game_set_active_tab(int index);
    const char* game_banner() const;
    const char* game_file_name(int index) const;
};

}
