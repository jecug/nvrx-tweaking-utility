#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <shellapi.h>

#include <atomic>
#include <chrono>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <deque>
#include <map>
#include <mutex>
#include <string>
#include <sys/stat.h>
#include <thread>
#include <vector>

#include "imgui.h"
#include "backends/imgui_impl_win32.h"
#include "backends/imgui_impl_dx11.h"

#include "../menu/appbridge.h"
#include "../menu/win32window.h"
#include "../menu/d3d11renderer.h"
#include "../menu/texture.h"
#include "../menu/windowchrome.h"
#include "../menu/theme.h"
#include "../menu/iconfont.h"
#include "../menu/menuwidgets.h"
#include "../menu/embeddedassets.h"
#include "../menu/imagedecoder.h"
#include "../menu/mainmenuscreen.h"

#include "ui.hpp"
#include "munchi.hpp"
#include "tweaks.hpp"
#include "scripts.hpp"
#include "bios.hpp"
#include "game.hpp"
#include "executor.hpp"
#include "util.hpp"
#include "../res/resource.h"

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "dwmapi.lib")
#pragma comment(lib, "shell32.lib")

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

namespace nvrx::ui {
namespace eng {

std::string stamp_now() {
    SYSTEMTIME st{};
    GetLocalTime(&st);
    char b[16]{};
    snprintf(b, sizeof(b), "%02u:%02u:%02u", st.wHour, st.wMinute, st.wSecond);
    return b;
}

struct LogLine {
    std::string time;
    std::string text;
    int level = 0;
};

struct State {
    std::atomic<bool> busy{ false };
    std::atomic<int> done{ 0 };
    std::atomic<int> total{ 0 };
    std::string status = "Idle";
    std::string current;
    std::mutex log_mtx;
    std::deque<LogLine> logs;
    int tab = 0;
    std::map<std::string, bool> applied;
    bool is_admin = false;
    std::string sys_os = "?";
    std::string sys_pc = "?";
    std::string sys_user = "?";
    std::string sys_ram = "?";
    std::string sys_cpu = "?";
    std::string sys_gpu = "?";
};

State g;
HWND g_hwnd = nullptr;

void add_log(int lv, const std::string& s) {
    std::lock_guard<std::mutex> lk(g.log_mtx);
    g.logs.push_back({ stamp_now(), s, lv });
    while (g.logs.size() > 800) g.logs.pop_front();
}

void set_status(const std::string& s) { g.status = s; }

std::wstring ini_path() { return util::exe_dir() + L"\\nvrx.ini"; }

void ini_save();

void ini_load() {
    wchar_t v[16]{};
    for (auto& t : tweaks()) {
        std::wstring key(t.id, t.id + strlen(t.id));
        GetPrivateProfileStringW(L"applied", key.c_str(), L"0", v, 16, ini_path().c_str());
        g.applied[t.id] = (v[0] == L'1');
    }
    g.tab = GetPrivateProfileIntW(L"ui", L"page", 0, ini_path().c_str());
    if (g.tab < 0 || g.tab > 1) g.tab = 0;
}

void ini_save() {
    for (auto& t : tweaks()) {
        std::wstring key(t.id, t.id + strlen(t.id));
        WritePrivateProfileStringW(L"applied", key.c_str(),
            g.applied[t.id] ? L"1" : L"0", ini_path().c_str());
    }
    WritePrivateProfileStringW(L"ui", L"page", std::to_wstring(g.tab).c_str(), ini_path().c_str());
}

void set_tab(int t) {
    if (t < 0) t = 0;
    if (t > 1) t = 1;
    if (t == g.tab) return;
    g.tab = t;
    ini_save();
}

std::string reg_sz_str(HKEY root, const wchar_t* sub, const wchar_t* val) {
    wchar_t b[256]{};
    DWORD n = sizeof(b);
    if (RegGetValueW(root, sub, val, RRF_RT_REG_SZ, nullptr, b, &n) == ERROR_SUCCESS)
        return util::utf8(b);
    return {};
}

void collect_sysinfo() {
    char pc[MAX_COMPUTERNAME_LENGTH + 1]{};
    DWORD pcn = sizeof(pc);
    if (GetComputerNameA(pc, &pcn)) g.sys_pc = pc;
    char un[256]{};
    DWORD unn = sizeof(un);
    if (GetUserNameA(un, &unn)) g.sys_user = un;
    MEMORYSTATUSEX ms{ sizeof(ms) };
    if (GlobalMemoryStatusEx(&ms)) {
        char b[64]{};
        snprintf(b, sizeof(b), "%.1f GB", ms.ullTotalPhys / 1073741824.0);
        g.sys_ram = b;
    }
    char cpu[256]{};
    DWORD cpn = sizeof(cpu);
    if (RegGetValueA(HKEY_LOCAL_MACHINE, "HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0",
                     "ProcessorNameString", RRF_RT_REG_SZ, nullptr, cpu, &cpn) == ERROR_SUCCESS) {
        std::string s = cpu;
        while (!s.empty() && (s.back() == ' ' || s.back() == '\0')) s.pop_back();
        while (!s.empty() && s.front() == ' ') s.erase(s.begin());
        if (!s.empty()) g.sys_cpu = s;
    }
    std::string pn = reg_sz_str(HKEY_LOCAL_MACHINE, L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion", L"ProductName");
    std::string dv = reg_sz_str(HKEY_LOCAL_MACHINE, L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion", L"DisplayVersion");
    std::string cb = reg_sz_str(HKEY_LOCAL_MACHINE, L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion", L"CurrentBuild");
    int build = 0;
    try { build = std::stoi(cb); } catch (...) { build = 0; }
    if (build >= 22000) {

        const std::string from = "Windows 10";
        const auto pos = pn.find(from);
        if (pos != std::string::npos) pn.replace(pos, from.size(), "Windows 11");
        else if (pn.empty()) pn = "Windows 11";
    }
    if (!pn.empty()) {
        g.sys_os = pn;
        if (!dv.empty()) g.sys_os += " " + dv;
        if (!cb.empty()) g.sys_os += " (" + cb + ")";
    }
    g.is_admin = exec::is_admin();
}

void worker_run_list(std::vector<std::string> ids, const std::string& label) {

    std::vector<std::string> seq, par;
    for (auto& id : ids) {
        const Tweak* tw = nullptr;
        for (auto& t : tweaks()) if (id == t.id) { tw = &t; break; }
        if (tw && tw->interactive) seq.push_back(id);
        else par.push_back(id);
    }
    g.busy.store(true);
    g.done.store(0);
    g.total.store((int)ids.size());
    g.current.clear();
    set_status(label);
    add_log(exec::L_INFO, "[Nvrx] === " + label + " (" + std::to_string(ids.size()) + ") ===");
    std::atomic<int> ok{ 0 };

    auto run_one = [&](const std::string& id) {
        if (!::IsWindow(g_hwnd)) return;
        const Tweak* tw = nullptr;
        for (auto& t : tweaks()) if (id == t.id) { tw = &t; break; }
        const std::string title = tw ? tw->title : id;
        g.current = title;
        const char* script = tweak_script(id.c_str());
        if (!script) script = nvrx::bios::script(id.c_str());
        const ULONGLONG t0 = GetTickCount64();
        struct Line { int lv; std::string at; std::string tx; };
        std::vector<Line> buf;
        buf.reserve(64);
        bool r = exec::run_script(id.c_str(), script,
            [&](int lv, const std::string& ln) { buf.push_back({ lv, stamp_now(), ln }); });
        char took[32]{};
        snprintf(took, sizeof(took), " (%.1fs)", (GetTickCount64() - t0) / 1000.0);
        {
            std::lock_guard<std::mutex> lk(g.log_mtx);
            g.logs.push_back({ stamp_now(), "--- " + title + " ---", exec::L_INFO });
            for (auto& l : buf) g.logs.push_back({ l.at, l.tx, l.lv });
            if (r) {
                ok.fetch_add(1);
                g.applied[id] = true;
                g.logs.push_back({ stamp_now(), std::string("[Nvrx] OK: ") + title + took, exec::L_OK });
            } else {
                g.logs.push_back({ stamp_now(), std::string("[Nvrx] FAILED: ") + title + took, exec::L_ERR });
            }
            while (g.logs.size() > 800) g.logs.pop_front();
            const int d = g.done.fetch_add(1) + 1;
            g.status = label + "  " + std::to_string(d) + "/" + std::to_string(ids.size());
        }
    };

    unsigned nw = std::thread::hardware_concurrency();
    if (nw < 2) nw = 2;
    if (nw > 8) nw = 8;
    if (par.size() < nw) nw = (unsigned)par.size();
    std::atomic<size_t> next{ 0 };
    std::vector<std::thread> pool;
    for (unsigned k = 0; k < nw; ++k)
        pool.emplace_back([&] {
            while (true) {
                const size_t i = next.fetch_add(1);
                if (i >= par.size()) break;
                run_one(par[i]);
            }
        });
    for (auto& th : pool) th.join();
    for (auto& id : seq) run_one(id);

    g.current.clear();
    ini_save();
    const int ok_n = ok.load();
    set_status(ok_n == (int)ids.size()
        ? "All Done"
        : ("Done " + std::to_string(ok_n) + "/" + std::to_string(ids.size())));
    add_log(ok_n == (int)ids.size() ? exec::L_OK : exec::L_WARN,
        "[Nvrx] === Finished: " + std::to_string(ok_n) + "/" + std::to_string(ids.size()) + " OK ===");
    if (ok_n == (int)ids.size())
        munchi::notify_add("All Tweaks Applied", munchi::NotifyType::Success, label);
    else
        munchi::notify_add("Finished With Errors", munchi::NotifyType::Warning,
            std::to_string(ok_n) + "/" + std::to_string(ids.size()) + " OK - See Log");
    g.busy.store(false);
    g.done.store(0);
    g.total.store(0);
}

void do_run_ids(std::vector<std::string> ids, const std::string& label) {
    if (g.busy.load() || ids.empty()) return;
    std::thread(worker_run_list, std::move(ids), label).detach();
}

void do_run_single(const char* id, const char* title) {
    if (g.busy.load()) return;
    do_run_ids({ id }, title && *title ? title : id);
}

void do_run_recommended() {
    if (g.busy.load()) return;
    std::vector<std::string> ids;
    for (auto& t : tweaks()) if (t.recommended) ids.push_back(t.id);
    do_run_ids(std::move(ids), "Recommended Tweaks");
}

void do_restore_point() {
    if (g.busy.load()) return;
    g.busy.store(true);
    set_status("Restore Point...");
    std::thread([] {
        exec::create_restore_point([](int lv, const std::string& ln) { add_log(lv, ln); });
        set_status("Idle");
        munchi::notify_add("Restore Point", munchi::NotifyType::Success, "Checkpoint Requested - See Log");
        g.busy.store(false);
    }).detach();
}

void open_utility_folder() {
    exec::open_folder(util::exe_dir());
}

void copy_log_to_clipboard() {
    std::string text;
    {
        std::lock_guard<std::mutex> lk(g.log_mtx);
        for (auto& l : g.logs) {
            text += l.time;
            text += "  ";
            text += l.text;
            text += "\r\n";
        }
    }
    if (text.empty()) return;
    if (OpenClipboard(g_hwnd)) {
        EmptyClipboard();
        HGLOBAL hg = GlobalAlloc(GMEM_MOVEABLE, text.size() + 1);
        if (hg) {
            if (void* p = GlobalLock(hg)) {
                memcpy(p, text.c_str(), text.size() + 1);
                GlobalUnlock(hg);
                SetClipboardData(CF_TEXT, hg);
            } else {
                GlobalFree(hg);
            }
        }
        CloseClipboard();
    }
    add_log(exec::L_INFO, "[Nvrx] Log copied to clipboard");
}

}

static ImFont* load_embedded_font(ImGuiIO& io, int resourceId, float size, const ImWchar* ranges) {
    const Utilities::EmbeddedAsset asset = Utilities::LoadEmbeddedAsset(resourceId);
    if (!asset.IsValid())
        return io.Fonts->AddFontDefault();
    ImFontConfig config;
    config.FontDataOwnedByAtlas = false;
    config.OversampleH = 2;
    config.OversampleV = 2;
    ImFont* font = io.Fonts->AddFontFromMemoryTTF(
        (void*)asset.Data, (int)asset.Size, size, &config, ranges);
    return font ? font : io.Fonts->AddFontDefault();
}

static void load_fonts(ImGuiIO& io) {
    auto& typography = UI::Theme::Get().MutableTypography();
    typography.Body = load_embedded_font(io, IDR_FT_SORA_REG, 15.0f, nullptr);
    typography.BodyMedium = load_embedded_font(io, IDR_FT_SORA_MED, 15.0f, nullptr);
    typography.Small = load_embedded_font(io, IDR_FT_SORA_REG, 13.5f, nullptr);

    typography.Heading = typography.BodyMedium;
    typography.IconControl = load_embedded_font(io, IDR_FT_SYMBOL, 15.0f, UI::Icons::SymbolRanges());
    typography.IconSymbol = typography.IconControl;
    typography.IconAction = typography.IconControl;
    typography.IconBrand = typography.IconControl;
    typography.IconAwesome = typography.IconControl;
    io.FontDefault = typography.Body;
    io.Fonts->Build();
}

static Renderer::Texture load_png_texture(ID3D11Device* device, int resourceId) {
    Renderer::Texture tex;
    const HRSRC res = FindResourceW(GetModuleHandleW(nullptr), MAKEINTRESOURCEW(resourceId), L"PNG");
    if (!res) return tex;
    const HGLOBAL block = LoadResource(nullptr, res);
    if (!block) return tex;
    const void* data = LockResource(block);
    const DWORD size = SizeofResource(nullptr, res);
    if (!data || !size) return tex;
    Utilities::DecodedImage image = Utilities::DecodeImage(static_cast<const uint8_t*>(data), size);
    if (!image.IsValid()) return tex;
    tex.Create(device, image.Frames.front().Pixels.data(), image.Width, image.Height);
    return tex;
}

static void load_gpu_name(ID3D11Device* device) {
    std::string name;
    IDXGIDevice* dxgiDevice = nullptr;
    if (device && SUCCEEDED(device->QueryInterface(__uuidof(IDXGIDevice), (void**)&dxgiDevice)) && dxgiDevice) {
        IDXGIAdapter* adapter = nullptr;
        if (SUCCEEDED(dxgiDevice->GetAdapter(&adapter)) && adapter) {
            DXGI_ADAPTER_DESC desc{};
            if (SUCCEEDED(adapter->GetDesc(&desc)))
                name = util::utf8(desc.Description);
            adapter->Release();
        }
        dxgiDevice->Release();
    }
    eng::g.sys_gpu = name.empty() ? std::string("?") : name;
}

int run() {
    eng::ini_load();
    eng::collect_sysinfo();

    Window::Win32Window window;
    if (!window.Create(L"Nvrx PC Tweaking Utility v3.0", (int)UI::Menu::kMenuWidth, (int)UI::Menu::kMenuHeight))
        return 1;
    eng::g_hwnd = window.Handle();

    Renderer::D3D11Renderer renderer;
    if (!renderer.Initialize(window.Handle()))
        return 1;
    window.SetOnResize([&](int width, int height) {
        renderer.ResizeSwapChain(width, height);
        });

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.LogFilename = nullptr;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    ImGui::GetStyle().AntiAliasedLines = true;
    ImGui::GetStyle().AntiAliasedFill = true;

    load_fonts(io);

    ImGui_ImplWin32_Init(window.Handle());
    ImGui_ImplDX11_Init(renderer.Device(), renderer.Context());

    load_gpu_name(renderer.Device());

    UI::Components::WindowChrome chrome(window);
    chrome.Initialize();

    UI::Screens::MainMenuScreen screen;
    screen.Initialize(renderer.Device());

    const auto panels = UI::Screens::MainMenuScreen::GetPanelRects(
        ImVec2(0.0f, 0.0f), ImVec2((float)window.Width(), (float)window.Height()));
    const auto toRect = [](const ImVec2& mn, const ImVec2& mx) {
        return RECT{ (LONG)mn.x, (LONG)mn.y, (LONG)mx.x, (LONG)mx.y };
        };
    bool leftPanels = false;
    const auto applyRegions = [&]() {

        const bool wantLeft = (eng::g.tab == 1);
        std::vector<RECT> islands{
            toRect(panels.TopMin, panels.TopMax),
            toRect(panels.MainMin, panels.MainMax) };
        if (wantLeft)
            islands.push_back(toRect(panels.LeftMin, panels.LeftMax));
        window.SetIslandRegion(islands, (int)UI::Screens::MainMenuScreen::PanelRadius());
        leftPanels = wantLeft;
    };
    applyRegions();

    window.SetDragRegion(std::vector<RECT>{
        RECT{ (LONG)panels.MainMin.x, (LONG)panels.MainMin.y,
              (LONG)(panels.MainMin.x + 420.0f), (LONG)(panels.MainMin.y + 44.0f) },
        RECT{ (LONG)(panels.TopMin.x + 260.0f), (LONG)(panels.TopMin.y + 4.0f),
              (LONG)(panels.TopMax.x - 92.0f), (LONG)(panels.TopMax.y - 4.0f) } });

    window.Show();

    eng::add_log(exec::L_INFO, "[Nvrx] Nvrx PC Tweaking Utility v3.0 ready");
    eng::add_log(exec::L_INFO,
        std::string("[Nvrx] ") + std::to_string(tweaks().size() + 2)
        + " tweaks embedded in the binary (incl. BIOS and Game tweakers)");
    if (eng::g.is_admin)
        eng::add_log(exec::L_OK, "[Nvrx] Running with administrator privileges");
    else
        eng::add_log(exec::L_WARN, "[Nvrx] Administrator privileges unavailable");

    const UI::ThemeColors& colors = UI::Theme::Get().Colors();
    const UI::ThemeTypography& typography = UI::Theme::Get().Typography();

    using Clock = std::chrono::steady_clock;
    Clock::time_point last = Clock::now();
    float deltaSeconds = 1.0f / 60.0f;

    while (window.PumpMessages()) {
        if (window.IsMinimized()) {
            last = Clock::now();
            continue;
        }

        const bool wantLeft = (eng::g.tab == 1);
        if (wantLeft != leftPanels)
            applyRegions();
        const Clock::time_point now = Clock::now();
        deltaSeconds = std::min(0.1f, std::max(0.001f,
            std::chrono::duration<float>(now - last).count()));
        last = now;

        chrome.Update(deltaSeconds);
        screen.Update(deltaSeconds);

        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();

        ImGui::SetNextWindowPos(ImVec2(0.0f, 0.0f));
        ImGui::SetNextWindowSize(ImVec2((float)window.Width(), (float)window.Height()));
        ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0.0f);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0.0f, 0.0f));
        constexpr ImGuiWindowFlags rootFlags = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize
            | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings
            | ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoNavFocus
            | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoBackground;
        ImGui::Begin("##nvrx_root", nullptr, rootFlags);
        ImGui::PopStyleVar(3);

        screen.Draw(ImVec2(0.0f, 0.0f), ImVec2((float)window.Width(), (float)window.Height()));

        chrome.DrawInHeader(panels.TopMin,
            ImVec2(panels.TopMax.x, panels.TopMax.y));

        ImGui::End();

        munchi::notify_render(typography.Body, 15.0f, typography.Small,
            ImVec2(panels.MainMax.x - 14.0f, panels.MainMax.y - 76.0f));

        ImGui::Render();
        renderer.BeginFrame(colors.Background);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        renderer.EndFrame(true);
    }

    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    renderer.Shutdown();
    return 0;
}

}

namespace nvrx::app {

App& App::get() { static App inst; return inst; }

bool App::busy() const { return nvrx::ui::eng::g.busy.load(); }
int App::done_count() const { return nvrx::ui::eng::g.done.load(); }
int App::total_count() const { return nvrx::ui::eng::g.total.load(); }
const std::string& App::status() const { return nvrx::ui::eng::g.status; }
const std::string& App::current() const { return nvrx::ui::eng::g.current; }

bool App::applied(const char* id) const {
    const auto it = nvrx::ui::eng::g.applied.find(id ? id : "");
    return it != nvrx::ui::eng::g.applied.end() && it->second;
}

void App::run_single(const char* id, const char* title) {
    nvrx::ui::eng::do_run_single(id ? id : "", title);
}
void App::run_recommended() { nvrx::ui::eng::do_run_recommended(); }
void App::restore_point() { nvrx::ui::eng::do_restore_point(); }
void App::open_folder() { nvrx::ui::eng::open_utility_folder(); }

void App::reboot_now() {
    if (nvrx::ui::eng::g.busy.load()) return;
    if (MessageBoxW(nvrx::ui::eng::g_hwnd, L"Reboot the computer now?",
        L"Nvrx PC Tweaking Utility v3.0",
        MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) != IDYES)
        return;
    nvrx::ui::eng::g.busy.store(true);
    nvrx::ui::eng::set_status("Reboot...");
    std::thread([] {
        nvrx::ui::eng::add_log(exec::L_INFO, "[Nvrx] Reboot requested");
        exec::reboot_now([](int lv, const std::string& ln) { nvrx::ui::eng::add_log(lv, ln); });
        nvrx::ui::eng::set_status("Idle");
        nvrx::ui::eng::g.busy.store(false);
    }).detach();
}

int App::tab() const { return nvrx::ui::eng::g.tab; }
void App::set_tab(int tab) { nvrx::ui::eng::set_tab(tab); }

const std::string& App::sys_os() const { return nvrx::ui::eng::g.sys_os; }
const std::string& App::sys_pc() const { return nvrx::ui::eng::g.sys_pc; }
const std::string& App::sys_user() const { return nvrx::ui::eng::g.sys_user; }
const std::string& App::sys_ram() const { return nvrx::ui::eng::g.sys_ram; }
const std::string& App::sys_cpu() const { return nvrx::ui::eng::g.sys_cpu; }
const std::string& App::sys_gpu() const { return nvrx::ui::eng::g.sys_gpu; }
bool App::is_admin() const { return nvrx::ui::eng::g.is_admin; }
int App::tweak_count() const {
    int n = (int)nvrx::tweaks().size();
    n += 2;
    return n;
}

std::string App::exe_path() const {
    wchar_t buf[MAX_PATH]{};
    GetModuleFileNameW(nullptr, buf, MAX_PATH);
    return util::utf8(buf);
}

std::vector<LogEntry> App::log_snapshot(int maxLines) const {
    std::vector<LogEntry> out;
    auto& state = nvrx::ui::eng::g;
    std::lock_guard<std::mutex> lk(state.log_mtx);
    const size_t take = maxLines > 0 ? (size_t)maxLines : state.logs.size();
    const size_t first = state.logs.size() > take ? state.logs.size() - take : 0;
    for (size_t i = first; i < state.logs.size(); ++i) {
        const auto& line = state.logs[i];
        out.push_back({ line.time, line.text, line.level });
    }
    return out;
}

void App::clear_log() {
    auto& state = nvrx::ui::eng::g;
    {
        std::lock_guard<std::mutex> lk(state.log_mtx);
        state.logs.clear();
    }
    nvrx::ui::eng::add_log(exec::L_INFO, "[Nvrx] Log cleared");
}

void App::copy_log() { nvrx::ui::eng::copy_log_to_clipboard(); }

namespace {

void BiosSync() {
    const std::string dump = nvrx::bios::work_dir() + "\\nvram.txt";

    static long long s_sig = -1;
    static long long s_loadedSig = -2;
    static int s_steady = 0;
    struct _stat64 st{};
    if (_stat64(dump.c_str(), &st) == 0) {
        const long long sig = (long long)st.st_mtime * 1000003LL + (long long)st.st_size;
        if (sig != s_sig) {
            s_sig = sig;
            s_steady = 0;
        } else if (s_steady < 12) {
            ++s_steady;
        }
        if (sig != s_loadedSig && s_steady >= 12) {
            s_loadedSig = sig;
            nvrx::bios::load(dump);
        }
    } else if (s_sig != -1) {

        s_sig = -1;
        s_loadedSig = -2;
        s_steady = 0;
        nvrx::bios::reset();
    }

    static bool s_importSeen = false;
    auto& a = nvrx::ui::eng::g.applied;
    const auto it = a.find("bios_import");
    if (!s_importSeen && it != a.end() && it->second) {
        s_importSeen = true;
        nvrx::bios::mark_import_sent();
    }
}

void GameSync() {
    const std::string shed = nvrx::game::config_path();

    static long long s_sig = -1;
    static long long s_loadedSig = -2;
    static int s_steady = 0;
    static unsigned s_epoch = 0;
    struct _stat64 st{};
    if (_stat64(shed.c_str(), &st) == 0) {
        const long long sig = (long long)st.st_mtime * 1000003LL + (long long)st.st_size;
        const unsigned ep = nvrx::game::epoch();
        if (ep != s_epoch) {

            s_epoch = ep;
            s_sig = sig;
            s_loadedSig = sig;
            s_steady = 12;
        } else if (sig != s_sig) {
            s_sig = sig;
            s_steady = 0;
        } else if (s_steady < 12) {
            ++s_steady;
        }
        if (sig != s_loadedSig && s_steady >= 12) {
            s_loadedSig = sig;
            nvrx::game::load();
        }
    } else if (s_sig != -1) {

        s_sig = -1;
        s_loadedSig = -2;
        s_steady = 0;
        if (!nvrx::game::config_creatable())
            nvrx::game::reset();
    }
}

}

void App::bios_export() {
    if (nvrx::ui::eng::g.busy.load()) return;
    nvrx::ui::eng::add_log(exec::L_INFO, "[Nvrx] BIOS pipeline started (download if needed + export)");
    nvrx::ui::eng::do_run_ids({ "bios_export" }, "BIOS Export Via SCEWIN");
}

void App::bios_import() {
    if (nvrx::ui::eng::g.busy.load()) return;
    BiosSync();
    if (!nvrx::bios::loaded()) return;
    if (!nvrx::bios::write_import()) {
        nvrx::ui::eng::add_log(exec::L_WARN,
            "[Nvrx] BIOS import refused - nothing changed or plan invalid");
        return;
    }
    nvrx::ui::eng::add_log(exec::L_INFO,
        "[Nvrx] BIOS plan written to C:\\Nvrx\\BIOS\\bios_import.txt - SCEWIN import follows");
    nvrx::ui::eng::do_run_ids({ "bios_import" }, "BIOS Import Via SCEWIN");
}

void App::bios_open_folder() {
    const std::string d = nvrx::bios::work_dir();
    if (GetFileAttributesA(d.c_str()) == INVALID_FILE_ATTRIBUTES)
        CreateDirectoryA(d.c_str(), nullptr);
    ShellExecuteA(nullptr, "open", d.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
}

int App::bios_item_count() const {
    BiosSync();
    return nvrx::bios::item_count();
}

bool App::bios_item(int index, BiosItem* out) const {
    BiosSync();
    const nvrx::bios::Item* it = nvrx::bios::item(index);
    if (!it || !out) return false;
    out->title = it->title;
    out->detail = it->detail;
    out->group = it->group;
    out->current = it->current;
    out->recommended = it->recommended;
    out->manual = it->manual;
    out->typed = it->typed;
    out->changed = it->changed;
    out->pick = it->pick;
    return true;
}

int App::bios_option_count(int index) const {
    BiosSync();
    return nvrx::bios::option_count(index);
}

std::string App::bios_option(int index, int optionIndex) const {
    BiosSync();
    return nvrx::bios::option(index, optionIndex);
}

void App::bios_set_pick(int index, int optionIndex) { nvrx::bios::pick(index, optionIndex); }

void App::bios_recommend_all() { nvrx::bios::recommend_all(); }

int App::bios_changed_count() const {
    BiosSync();
    return nvrx::bios::changed_count();
}

const char* App::bios_status() const {
    BiosSync();
    static std::string s;
    s = nvrx::bios::status_text();
    return s.c_str();
}

void App::game_apply() {
    if (nvrx::ui::eng::g.busy.load()) return;
    GameSync();
    if (!nvrx::game::loaded()) return;
    const std::string gname =
        nvrx::game::game_name(nvrx::game::game_active());
    const bool hadBackup = nvrx::game::config_file_exists();
    if (!hadBackup && !nvrx::game::config_creatable()) {
        nvrx::ui::eng::add_log(exec::L_WARN,
            std::string("[Nvrx] Game apply refused - ") + gname
                + " config not found");
        return;
    }
    if (nvrx::game::game_running()) {
        nvrx::ui::eng::add_log(exec::L_WARN,
            std::string("[Nvrx] Game apply refused - ") + gname
                + " is running and rewrites the config on exit. Close it "
                  "first, then Apply.");
        return;
    }
    const int n = nvrx::game::changed_count();
    if (!nvrx::game::apply()) {
        nvrx::ui::eng::add_log(exec::L_WARN,
            "[Nvrx] Game apply refused - nothing changed or write failed");
        return;
    }
    nvrx::ui::eng::add_log(exec::L_INFO,
        std::string("[Nvrx] ") + gname + " config updated - "
            + std::to_string(n) + " value(s) written to "
            + nvrx::game::game_file(nvrx::game::game_active())
            + (hadBackup ? " (backup: .bak)" : " (created)"));
}

void App::game_open_folder() {
    const std::string p = nvrx::game::config_path();
    const size_t cut = p.find_last_of('\\');
    const std::string d = cut == std::string::npos ? p : p.substr(0, cut);
    if (GetFileAttributesA(d.c_str()) == INVALID_FILE_ATTRIBUTES)
        CreateDirectoryA(d.c_str(), nullptr);
    ShellExecuteA(nullptr, "open", d.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
}

bool App::game_guide_creatable() const {
    return nvrx::game::guide_creatable();
}

void App::game_open_guide() {
    std::string p;
    if (!nvrx::game::write_guide(&p)) {
        nvrx::ui::eng::add_log(exec::L_WARN,
            "[Nvrx] No guide bundled for this game - nothing written");
        return;
    }
    nvrx::ui::eng::add_log(exec::L_INFO,
        std::string("[Nvrx] Guide written and opened - ") + p);
    ShellExecuteA(nullptr, "open", p.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
}

int App::game_item_count() const {
    GameSync();
    return nvrx::game::item_count();
}

bool App::game_item(int index, GameItem* out) const {
    GameSync();
    const nvrx::game::Item* it = nvrx::game::item(index);
    if (!it || !out) return false;
    out->title = it->title;
    out->detail = it->detail;
    out->current = it->current;
    out->recommended = it->recommended;
    out->missing = it->missing;
    out->changed = it->changed;
    out->pick = it->pick;
    return true;
}

int App::game_option_count(int index) const {
    GameSync();
    return nvrx::game::option_count(index);
}

std::string App::game_option(int index, int optionIndex) const {
    GameSync();
    return nvrx::game::option(index, optionIndex);
}

void App::game_set_pick(int index, int optionIndex) {
    nvrx::game::pick(index, optionIndex);
}

void App::game_recommend_all() { nvrx::game::recommend_all(); }

int App::game_changed_count() const {
    GameSync();
    return nvrx::game::changed_count();
}

const char* App::game_status() const {
    GameSync();
    static std::string s;
    s = nvrx::game::status_text();
    return s.c_str();
}

int App::game_tab_count() const { return nvrx::game::game_count(); }

const char* App::game_tab_name(int index) const {

    static std::string s[8];
    if (index < 0 || index >= nvrx::game::game_count()) return "";
    s[index] = nvrx::game::game_name(index);
    return s[index].c_str();
}

bool App::game_tab_ready(int index) const {
    return nvrx::game::game_ready(index);
}

int App::game_active_tab() const { return nvrx::game::game_active(); }

void App::game_set_active_tab(int index) {
    nvrx::game::set_active(index);
}

const char* App::game_banner() const {
    static std::string s;
    s = nvrx::game::game_banner(nvrx::game::game_active());
    return s.c_str();
}

const char* App::game_file_name(int index) const {

    static std::string s[8];
    if (index < 0 || index >= nvrx::game::game_count()) return "";
    s[index] = nvrx::game::game_file(index);
    return s[index].c_str();
}

}
