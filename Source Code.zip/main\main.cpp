#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include "ui.hpp"

int WINAPI wWinMain(HINSTANCE, HINSTANCE, LPWSTR, int) {
    return nvrx::ui::run();
}
