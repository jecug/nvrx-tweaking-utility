#include "game.hpp"

#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

#include <windows.h>
#include <tlhelp32.h>
#include <shlobj_core.h>
#pragma comment(lib, "Shell32.lib")

namespace nvrx { namespace game {

namespace {

std::string Lower(const std::string& v) {
    std::string s = v;
    std::transform(s.begin(), s.end(), s.begin(),
                   [](unsigned char c) { return (char)std::tolower(c); });
    return s;
}

bool CiEq(const std::string& a, const char* b) { return Lower(a) == Lower(b); }

bool CiEq(const std::string& a, const std::string& b) { return Lower(a) == Lower(b); }

std::string Trim(const std::string& v) {
    size_t a = 0, b = v.size();
    while (a < b && (v[a] == ' ' || v[a] == '\t')) ++a;
    while (b > a && (v[b - 1] == ' ' || v[b - 1] == '\t')) --b;
    return v.substr(a, b - a);
}

bool ReadFile(const char* path, std::string& data) {
    std::FILE* f = nullptr;
    if (fopen_s(&f, path, "rb") != 0 || !f) return false;
    data.clear();
    char buf[65536];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), f)) > 0) data.append(buf, n);
    fclose(f);
    return true;
}

bool WriteFile(const char* path, const std::string& data) {
    std::FILE* f = nullptr;
    if (fopen_s(&f, path, "wb") != 0 || !f) return false;
    fwrite(data.data(), 1, data.size(), f);
    fclose(f);
    return true;
}

bool FileExists(const char* path) {
    return GetFileAttributesA(path) != INVALID_FILE_ATTRIBUTES;
}

enum Fmt { FmtIni, FmtKv, FmtXml };

const char* IniLineValue(const std::string& line, const char* key) {
    if (line.empty()) return nullptr;
    const size_t eq = line.find('=');
    if (eq == std::string::npos) return nullptr;
    if (!CiEq(line.substr(0, eq), key)) return nullptr;
    static std::string value;
    value = line.substr(eq + 1);
    return value.c_str();
}

const char* KvLineValue(const std::string& line, const char* key) {
    if (line.size() < 4) return nullptr;
    const size_t q1 = line.find('"');
    if (q1 == std::string::npos) return nullptr;
    const size_t q2 = line.find('"', q1 + 1);
    if (q2 == std::string::npos) return nullptr;
    if (!CiEq(line.substr(q1 + 1, q2 - q1 - 1), key)) return nullptr;
    const size_t q3 = line.find('"', q2 + 1);
    if (q3 == std::string::npos) return nullptr;
    const size_t q4 = line.find('"', q3 + 1);
    if (q4 == std::string::npos) return nullptr;
    static std::string value;
    value = line.substr(q3 + 1, q4 - q3 - 1);
    return value.c_str();
}

const char* XmlLineValue(const std::string& line, const char* key,
                         size_t* vStart = nullptr, size_t* vEnd = nullptr) {
    if (line.size() < 8) return nullptr;
    const std::string low = Lower(line);
    size_t at = 0;
    for (;;) {
        at = low.find("name=", at);
        if (at == std::string::npos) return nullptr;
        const size_t kq = at + 5;
        if (kq >= line.size()) return nullptr;
        const char q = line[kq];
        if (q != '"' && q != '\'') { at = kq; continue; }
        const size_t kstart = kq + 1;
        const size_t kend = line.find(q, kstart);
        if (kend == std::string::npos) return nullptr;
        if (kend > kstart && CiEq(line.substr(kstart, kend - kstart), key)) {
            const size_t gt = line.find('>', kend);
            if (gt == std::string::npos) return nullptr;
            const size_t vt = line.find('<', gt + 1);
            if (vt == std::string::npos) return nullptr;
            if (vStart) *vStart = gt + 1;
            if (vEnd) *vEnd = vt;
            static std::string value;
            value = Trim(line.substr(gt + 1, vt - gt - 1));
            return value.c_str();
        }
        at = kstart;
    }
}

bool SetValue(std::string& line, Fmt fmt, const char* key, const std::string& want) {
    if (fmt == FmtIni) {
        const size_t eq = line.find('=');
        if (eq == std::string::npos) return false;
        line = line.substr(0, eq + 1) + want;
        return true;
    }
    if (fmt == FmtKv) {
        const size_t q1 = line.find('"');
        if (q1 == std::string::npos) return false;
        const size_t q2 = line.find('"', q1 + 1);
        if (q2 == std::string::npos) return false;
        const size_t q3 = line.find('"', q2 + 1);
        if (q3 == std::string::npos) return false;
        const size_t q4 = line.find('"', q3 + 1);
        if (q4 == std::string::npos) return false;
        line = line.substr(0, q3) + "\"" + want + "\""
             + (q4 + 1 < line.size() ? line.substr(q4 + 1) : "");
        return true;
    }
    size_t vs = 0, ve = 0;
    if (!XmlLineValue(line, key, &vs, &ve)) return false;
    line = line.substr(0, vs) + want + line.substr(ve);
    return true;
}

std::string CurrentValue(const std::string& line, Fmt fmt, const std::string& key) {
    const char* v = fmt == FmtIni ? IniLineValue(line, key.c_str())
                  : fmt == FmtKv  ? KvLineValue(line, key.c_str())
                                  : XmlLineValue(line, key.c_str());
    return v ? Trim(v) : std::string();
}

struct RuleOpt {
    const char* label;
    const char* value;
};

struct Rule {
    const char* title;
    const char* detail;
    const char* section;
    const char* recommended;
    const char* keys[3];
    RuleOpt opts[8];
};

const Rule* FortniteRules(size_t* count) {
    static const Rule all[] = {
        { "Mouse Acceleration",
          "Raw 1:1 pointer movement - no acceleration curve on top.",
          "[/Script/FortniteGame.FortGameUserSettings]", "True",
          { "bDisableMouseAcceleration" },
          { { "On (Raw Input)", "True" }, { "Off (Accel)", "False" } } },

        { "NVIDIA Reflex",
          "Reflex Low Latency with Boost - lowest end-to-end latency.",
          "[/Script/FortniteGame.FortGameUserSettings]", "2",
          { "LatencyTweak2" },
          { { "Off", "0" }, { "On", "1" }, { "On + Boost", "2" } } },

        { "Low Input Latency Mode",
          "Fortnite's built-in low-latency toggle - pinned on.",
          "[/Script/FortniteGame.FortGameUserSettings]", "True",
          { "LowInputLatencyModeIsEnabled" },
          { { "On", "True" }, { "Off", "False" } } },

        { "VSync",
          "Vertical sync off - no monitor-swap buffer delay.",
          "[/Script/FortniteGame.FortGameUserSettings]", "False",
          { "bUseVSync" },
          { { "Off", "False" }, { "On", "True" } } },

        { "Frame Rate Limit",
          "In-battle fps cap - Unlimited (0) never queues frames.",
          "[/Script/FortniteGame.FortGameUserSettings]", "240.000000",
          { "FrameRateLimit" },
          { { "240", "240.000000" }, { "165", "165.000000" },
            { "144", "144.000000" }, { "120", "120.000000" },
            { "Unlimited", "0.000000" } } },

        { "Rendering Mode",
          "es31 = Performance mode - lowest render cost pipeline.",
          "[D3DRHIPreference]", "es31",
          { "PreferredFeatureLevel" },
          { { "Performance (es31)", "es31" },
            { "DirectX 11 (sm5)", "sm5" },
            { "DirectX 12 (sm6)", "sm6" } } },

        { "Anti-Aliasing Method",
          "Upscaler picker - DLSS on RTX; TSR for Fortnite's own.",
          "[/Script/FortniteGame.FortGameUserSettings]", "DLSS",
          { "FortAntiAliasingMethod" },
          { { "DLSS", "DLSS" }, { "TSR", "TSR" },
            { "Disabled", "Disabled" } } },

        { "Fullscreen Mode",
          "Windowed fullscreen - instant alt-tab, full composition.",
          "[/Script/FortniteGame.FortGameUserSettings]", "1",
          { "PreferredFullscreenMode", "LastConfirmedFullscreenMode" },
          { { "Fullscreen", "0" }, { "Windowed Fullscreen", "1" },
            { "Windowed", "2" } } },

        { "DLSS Frame Generation",
          "Frame generation adds input lag - off for latency.",
          "[/Script/FortniteGame.FortGameUserSettings]", "False",
          { "bEnableDLSSFrameGeneration" },
          { { "Off", "False" }, { "On", "True" } } },

        { "Arm ASR Upscaler",
          "Arm software upscaler off - no double scaling pass.",
          "[/Script/FortniteGame.FortGameUserSettings]", "False",
          { "bArmASREnabled" },
          { { "Off", "False" }, { "On", "True" } } },

        { "GPU Crash Debugging",
          "Debug assists off - no extra GPU interception.",
          "[/Script/FortniteGame.FortGameUserSettings]", "False",
          { "bUseGPUCrashDebugging" },
          { { "Off", "False" }, { "On", "True" } } },

        { "Motion Blur",
          "Motion blur trails off - cleaner frames.",
          "[/Script/FortniteGame.FortGameUserSettings]", "False",
          { "bMotionBlur" },
          { { "Off", "False" }, { "On", "True" } } },

        { "Show Grass",
          "In-game grass toggled off for more frames.",
          "[/Script/FortniteGame.FortGameUserSettings]", "False",
          { "bShowGrass" },
          { { "Off", "False" }, { "On", "True" } } },

        { "Headphone Mode",
          "3D headphone mix off - lighter audio path.",
          "[/Script/FortniteGame.FortGameUserSettings]", "False",
          { "bUseHeadphoneMode" },
          { { "Off", "False" }, { "On", "True" } } },

        { "Nanite",
          "Nanite mesh streaming off - classic shading path.",
          "[/Script/FortniteGame.FortGameUserSettings]", "False",
          { "bUseNanite" },
          { { "Off", "False" }, { "On", "True" } } },

        { "Cosmetic Streaming",
          "Stops runtime cosmetic asset streaming - fewer hitches.",
          "[/Script/FortniteGame.FortGameUserSettings]", "CodeSet_Disabled",
          { "CosmeticStreamingEnabled" },
          { { "Disabled", "CodeSet_Disabled" },
            { "Enabled", "CodeSet_Enabled" } } },

        { "3D Resolution Quality",
          "Internal render scale - 100 stays sharp, lower buys fps.",
          "[ScalabilityGroups]", "100",
          { "sg.ResolutionQuality" },
          { { "100", "100" }, { "95", "95" }, { "90", "90" },
            { "85", "85" }, { "80", "80" }, { "75", "75" },
            { "70", "70" } } },

        { "3D Render Target Width",
          "Internal render width - Fortnite upscales it to full res.",
          "[/Script/FortniteGame.FortGameUserSettings]", "1280",
          { "DesiredScreenWidth", "LastUserConfirmedDesiredScreenWidth" },
          { { "1280", "1280" }, { "1600", "1600" },
            { "1920", "1920" } } },

        { "3D Render Target Height",
          "Internal render height - pair it with the width row.",
          "[/Script/FortniteGame.FortGameUserSettings]", "720",
          { "DesiredScreenHeight", "LastUserConfirmedDesiredScreenHeight" },
          { { "720", "720" }, { "900", "900" },
            { "1080", "1080" } } },

        { "Dynamic Resolution",
          "Fixed internal target - stable frametimes, no blur pumping.",
          "[/Script/FortniteGame.FortGameUserSettings]", "False",
          { "bUseDynamicResolution" },
          { { "Off", "False" }, { "On", "True" } } },

        { "View Distance",
          "Draw distance 0 for maximum frames - visibility trade.",
          "[ScalabilityGroups]", "0",
          { "sg.ViewDistanceQuality" },
          { { "Off", "0" }, { "Low", "1" }, { "Medium", "2" },
            { "High", "3" } } },

        { "Anti-Aliasing",
          "Legacy AA slot 0 - the image stays controlled by the "
          "upscaler selection instead.",
          "[ScalabilityGroups]", "0",
          { "sg.AntiAliasingQuality" },
          { { "Off", "0" }, { "Low", "1" }, { "Medium", "2" },
            { "High", "3" } } },

        { "Shadows",
          "Shadow casting 0 - light cost drops hard.",
          "[ScalabilityGroups]", "0",
          { "sg.ShadowQuality" },
          { { "Off", "0" }, { "Low", "1" }, { "Medium", "2" },
            { "High", "3" } } },

        { "Global Illumination",
          "GI tier 0 - no dynamic light bounce pass.",
          "[ScalabilityGroups]", "0",
          { "sg.GlobalIlluminationQuality" },
          { { "Off", "0" }, { "Low", "1" }, { "Medium", "2" },
            { "High", "3" } } },

        { "Reflections",
          "Reflection tier 0 - SSR and probes off.",
          "[ScalabilityGroups]", "0",
          { "sg.ReflectionQuality" },
          { { "Off", "0" }, { "Low", "1" }, { "Medium", "2" },
            { "High", "3" } } },

        { "Post Processing",
          "Post pass 0 - bloom / motion effects off.",
          "[ScalabilityGroups]", "0",
          { "sg.PostProcessQuality" },
          { { "Off", "0" }, { "Low", "1" }, { "Medium", "2" },
            { "High", "3" } } },

        { "Shading",
          "Material shading cost lowest - raise if visuals matter.",
          "[ScalabilityGroups]", "0",
          { "sg.ShadingQuality" },
          { { "Off", "0" }, { "Low", "1" }, { "Medium", "2" },
            { "High", "3" } } },

        { "Textures",
          "Texture tier 0 - lowest vram, stable frametimes.",
          "[ScalabilityGroups]", "0",
          { "sg.TextureQuality" },
          { { "Off", "0" }, { "Low", "1" }, { "Medium", "2" },
            { "High", "3" } } },

        { "Effects",
          "Effect pool 0 - explosions stay cheap.",
          "[ScalabilityGroups]", "0",
          { "sg.EffectsQuality" },
          { { "Off", "0" }, { "Low", "1" }, { "Medium", "2" },
            { "High", "3" } } },

        { "Foliage",
          "Foliage tier 0 - bushes at render distance.",
          "[ScalabilityGroups]", "0",
          { "sg.FoliageQuality" },
          { { "Off", "0" }, { "Low", "1" }, { "Medium", "2" },
            { "High", "3" } } },

        { "Landscape Quality",
          "Terrain mesh tier lowest - retains hitboxes.",
          "[ScalabilityGroups]", "0",
          { "sg.LandscapeQuality" },
          { { "Off", "0" }, { "Low", "1" }, { "Medium", "2" },
            { "High", "3" } } },

        { "Audio Quality",
          "Mix quality tier 0 - frees a bit of CPU.",
          "[/Script/FortniteGame.FortGameUserSettings]", "0",
          { "AudioQualityLevel", "LastConfirmedAudioQualityLevel" },
          { { "Low", "0" }, { "Medium", "1" }, { "High", "2" } } },
    };
    *count = sizeof(all) / sizeof(all[0]);
    return all;
}

const Rule* Cs2Rules(size_t* count) {
    static const Rule all[] = {
        { "NVIDIA Reflex",
          "Reflex Low Latency with Boost - lowest end-to-end latency.",
          "", "2",
          { "setting.r_low_latency" },
          { { "Off", "0" }, { "On", "1" }, { "On + Boost", "2" } } },

        { "MSAA",
          "Hardware multisampling off - the biggest CS2 fps lever.",
          "", "0",
          { "setting.msaa_samples" },
          { { "Off", "0" }, { "2x", "2" }, { "4x", "4" }, { "8x", "8" } } },

        { "CMAA",
          "Extra anti-alias pass off - skin it and the MSAA row win.",
          "", "0",
          { "setting.r_csgo_cmaa_enable" },
          { { "Off", "0" }, { "On", "1" } } },

        { "Shader Detail",
          "Shader tier 0 - cheapest pixel pipeline. Launch builds slower.",
          "", "0",
          { "setting.shaderquality" },
          { { "Low", "0" }, { "Medium", "1" }, { "High", "2" },
            { "Ultra", "3" } } },

        { "GPU Detail",
          "GPU-side preset index - Low for the lightest pass.",
          "", "0",
          { "setting.gpu_level" },
          { { "Low", "0" }, { "Medium", "1" }, { "High", "2" },
            { "Ultra", "3" } } },

        { "CPU Detail",
          "CPU-side preset index (props / ragdolls) - Low frees frames.",
          "", "0",
          { "setting.cpu_level" },
          { { "Low", "0" }, { "Medium", "1" }, { "High", "2" },
            { "Ultra", "3" } } },

        { "Memory Detail",
          "Texture pool budget - Ultra stages less, fewer hitches; "
          "Low frees vram.",
          "", "3",
          { "setting.gpu_mem_level" },
          { { "Low", "0" }, { "Medium", "1" }, { "High", "2" },
            { "Ultra", "3" } } },

        { "Texture Filtering",
          "Filtering tier - Medium reads the same on most setups.",
          "", "2",
          { "setting.r_texturefilteringquality" },
          { { "Lowest", "0" }, { "Low", "1" }, { "Medium", "2" },
            { "High", "3" } } },

        { "Shadow Quality",
          "Shadow casting off - light cost drops hard.",
          "", "0",
          { "setting.videocfg_shadow_quality" },
          { { "Off", "0" }, { "Low", "1" }, { "Medium", "2" },
            { "High", "3" } } },

        { "Dynamic Shadows",
          "Moving shadow pass off - statics stay as-is.",
          "", "0",
          { "setting.videocfg_dynamic_shadows" },
          { { "Off", "0" }, { "On", "1" } } },

        { "Texture Detail",
          "Surface detail tier 0 - lowest vram and bandwidth.",
          "", "0",
          { "setting.videocfg_texture_detail" },
          { { "Low", "0" }, { "Medium", "1" }, { "High", "2" } } },

        { "Particle Detail",
          "Effect particle tier 0 - nades stay cheap.",
          "", "0",
          { "setting.videocfg_particle_detail" },
          { { "Low", "0" }, { "Medium", "1" }, { "High", "2" } } },

        { "Ambient Occlusion",
          "AO shading pass off - corners lose contact shading.",
          "", "0",
          { "setting.videocfg_ao_detail" },
          { { "Off", "0" }, { "Medium", "1" }, { "High", "2" } } },

        { "HDR Detail",
          "Source 2 tone pipeline (in-game: High Dynamic Range). 0 strips "
          "tonemapping - sunny maps wash out; 3 looks right for ~2% fps.",
          "", "3",
          { "setting.videocfg_hdr_detail" },
          { { "Quality (Normal)", "3" }, { "Off (Washed-Out)", "0" } } },

        { "FSR Upscaling",
          "FidelityFX super resolution off - native res only.",
          "", "0",
          { "setting.videocfg_fsr_detail" },
          { { "Off", "0" }, { "Ultra Quality", "1" }, { "Quality", "2" },
            { "Balanced", "3" }, { "Performance", "4" },
            { "Ultra Performance", "5" } } },

        { "VSync",
          "Vertical sync off - no monitor-swap buffer delay.",
          "", "0",
          { "setting.mat_vsync" },
          { { "Off", "0" }, { "On", "1" } } },

        { "Fullscreen Mode",
          "Fullscreen flag - with Borderless Off this is exclusive.",
          "", "0",
          { "setting.fullscreen" },
          { { "Windowed", "0" }, { "Fullscreen", "1" } } },

        { "Borderless Mode",
          "Borderless flag - On + Fullscreen Off = borderless window.",
          "", "1",
          { "setting.nowindowborder" },
          { { "Off", "0" }, { "On", "1" } } },
    };
    *count = sizeof(all) / sizeof(all[0]);
    return all;
}

const Rule* RobloxRules(size_t* count) {
    static const Rule all[] = {
        { "Graphics Quality",
          "Automatic lets the engine float it; Level 1 pins the lightest tier.",
          "", "1",
          { "SavedQualityLevel" },
          { { "Automatic", "0" }, { "Level 1 (Lowest)", "1" }, { "Level 3", "3" },
            { "Level 5", "5" }, { "Level 7", "7" }, { "Level 10 (Max)", "10" } } },

        { "Optimization Mode",
          "Manual-quality preference - Performance favors frames.",
          "", "0",
          { "GraphicsOptimizationMode" },
          { { "Performance", "0" }, { "Balanced", "1" }, { "Quality", "2" } } },

        { "Frame Cap",
          "Default (60) is the engine cap; a value sets the real ceiling.",
          "", "240",
          { "FramerateCap" },
          { { "240", "240" }, { "144", "144" }, { "120", "120" },
            { "60", "60" }, { "Default (60)", "-1" } } },

        { "Fullscreen",
          "Exclusive rendering beats windowed composition for latency.",
          "", "true",
          { "Fullscreen" },
          { { "On", "true" }, { "Off", "false" } } },

        { "Max Quality",
          "Forward-compat max render preset - off for frames.",
          "", "false",
          { "MaxQualityEnabled" },
          { { "Off", "false" }, { "On", "true" } } },
    };
    *count = sizeof(all) / sizeof(all[0]);
    return all;
}

const Rule* RobloxFlagRules(size_t* count) {
    static const Rule all[] = {
        { "Texture Override",
          "Master switch - the level row only takes effect while On.",
          "", "true",
          { "DFFlagTextureQualityOverrideEnabled" },
          { { "On", "True" }, { "Off", "False" } } },

        { "Texture Level",
          "0 keeps stored textures smallest, 3 loads max resolution.",
          "", "0",
          { "DFIntTextureQualityOverride" },
          { { "Level 0", "0" }, { "Level 1", "1" }, { "Level 2", "2" },
            { "Level 3", "3" } } },

        { "Anti-Aliasing",
          "Forced MSAA samples - 1 is none, each step costs fill rate.",
          "", "1",
          { "FIntDebugForceMSAASamples" },
          { { "Off (1x)", "1" }, { "2x", "2" }, { "4x", "4" },
            { "8x", "8" } } },

        { "Grass Distance",
          "0 strips terrain grass; larger values show more of it.",
          "", "0",
          { "FIntFRMMaxGrassDistance", "FIntFRMMinGrassDistance" },
          { { "Off", "0" }, { "250", "250" }, { "1000", "1000" } } },

        { "Lighting Updates",
          "Pauses dynamic relighting - shadows freeze until undone.",
          "", "true",
          { "DFFlagDebugPauseVoxelizer" },
          { { "On", "True" }, { "Off", "False" } } },

        { "Sky Gray",
          "Flat gray sky instead of a rendered skybox - cheapest backdrop.",
          "", "true",
          { "FFlagDebugSkyGray" },
          { { "On", "True" }, { "Off", "False" } } },
    };
    *count = sizeof(all) / sizeof(all[0]);
    return all;
}

const Rule* RocketLeagueRules(size_t* count) {
    static const Rule all[] = {
        { "Frame Sleep",
          "False drops the per-frame sleep/yield throttle - frames run free.",
          "", "False",
          { "AllowPerFrameSleep", "AllowPerFrameYield" },
          { { "Off (uncapped)", "False" }, { "On", "True" } } },

        { "Vertical Sync",
          "Off keeps the swap chain unthrottled by the monitor.",
          "", "False",
          { "UseVsync" },
          { { "Off", "False" }, { "On", "True" } } },

        { "Dynamic Shadows",
          "Shadow map pass off - heavy render cost gone.",
          "", "False",
          { "DynamicShadows" },
          { { "Off", "False" }, { "On", "True" } } },

        { "Ambient Occlusion",
          "Contact-shading pass off.",
          "", "False",
          { "AmbientOcclusion" },
          { { "Off", "False" }, { "On", "True" } } },

        { "Bloom",
          "Glow pass off.",
          "", "False",
          { "Bloom" },
          { { "Off", "False" }, { "On", "True" } } },

        { "Motion Blur",
          "Blur pass off.",
          "", "False",
          { "MotionBlur" },
          { { "Off", "False" }, { "On", "True" } } },

        { "Depth of Field",
          "Focus blur pass off.",
          "", "False",
          { "DepthOfField" },
          { { "Off", "False" }, { "On", "True" } } },

        { "World Detail",
          "Decor mesh tier (props/grass) - the knob behind the in-game menu.",
          "", "0",
          { "DetailMode" },
          { { "Low", "0" }, { "Medium", "1" }, { "High", "2" } } },

        { "Quality Shaders",
          "High-quality material shaders off - simpler material cost.",
          "", "False",
          { "bAllowHighQualityMaterials" },
          { { "Off", "False" }, { "On", "True" } } },

        { "MSAA",
          "Multisample count - 1 is none (the file's own off value); each level costs fill rate.",
          "", "1",
          { "MaxMultiSamples" },
          { { "Off (1x)", "1" }, { "2x", "2" }, { "4x", "4" } } },

        { "Anisotropic",
          "0 = plain filtering; distant texture clarity costs a little.",
          "", "0",
          { "MaxAnisotropy" },
          { { "Off", "0" }, { "8x", "8" }, { "16x", "16" } } },
    };
    *count = sizeof(all) / sizeof(all[0]);
    return all;
}

const Rule* ValorantRules(size_t* count) {
    static Rule all[] = {
        { "Vertical Sync",
          "UE4 bUseVSync from the account file - syncs frames to the monitor, adds input latency.",
          "", "False",
          { "bUseVSync" },
          { { "Off", "False" }, { "On", "True" } } },

        { "Texture Quality",
          "Scalability bucket sg.TextureQuality - the file currently holds 2 where the menu shows High, so Low is bucket 0.",
          "", "0",
          { "sg.TextureQuality" },
          { { "Low", "0" }, { "Med", "1" }, { "High", "2" } } },
    };
    *count = sizeof(all) / sizeof(all[0]);
    return all;
}

const char* ValorantGuide() {
    return
"==============================================================\n"
" VALORANT - NVRX GUIDE: SETTINGS THE UTILITY CANNOT CHANGE\n"
"==============================================================\n"
"\n"
"ALREADY SET BY THE UTILITY (do not touch these in-game)\n"
"----------------------------------------\n"
"  Vertical Sync ..................... off (bUseVSync)\n"
"  Texture Quality ................... Low (sg bucket 0)\n"
"\n"
"Check the VIDEO tab: these two should already show the\n"
"values above without you touching anything. If your own\n"
"list shows something else, the Riot account sync rewrote\n"
"the file - run the utility's Apply again with the game\n"
"closed, or tell the assistant so the rows can be cut.\n"
"\n"
"STILL TO SET INSIDE THE GAME (one time, about 30 seconds)\n"
"------------------------------------------------------\n"
"Open:  Valorant -> SETTINGS -> VIDEO tab\n"
"\n"
"GENERAL TAB:\n"
"  1. LIMIT FRAMERATE ALWAYS ......... OFF (the big one -\n"
"                             an ON cap of 60 keeps the\n"
"                             whole game at sixty)\n"
"  2. MAX FPS ALWAYS ................. only if limit\n"
"                             stays: uncapped or 240+\n"
"  3. LIMIT FPS ON BATTERY ........... OFF (laptops;\n"
"                             desktop rows stay grey)\n"
"  4. LIMIT FPS IN MENUS ............. OFF (no gameplay\n"
"                             impact either way)\n"
"  5. LIMIT FPS IN BACKGROUND ........ keep ON at 30\n"
"                             (hidden client stops eating\n"
"                             the GPU when alt-tabbed)\n"
"  6. NVIDIA REFLEX LOW LATENCY ...... ON + Boost\n"
"  7. DISPLAY MODE ................... keep Fullscreen,\n"
"                             native resolution, right\n"
"                             monitor\n"
"\n"
"GRAPHICS QUALITY TAB:\n"
"  8. MULTITHREADED RENDERING ........ keep ON\n"
"  9. MATERIAL QUALITY ............... Low\n"
" 10. TEXTURE QUALITY ................ Low (from file)\n"
" 11. DETAIL QUALITY ................. Low\n"
" 12. UI QUALITY ..................... Low\n"
" 13. VIGNETTE ....................... Off\n"
" 14. VSYNC .......................... Off (from file)\n"
" 15. ANTI-ALIASING .................. None (or 2x if\n"
"                             edges shimmer too much)\n"
" 16. ANISOTROPIC FILTERING .......... 1x (lowest)\n"
" 17. IMPROVE CLARITY ................ Off\n"
" 18. EXPERIMENTAL SHARPENING ........ Off\n"
" 19. BLOOM QUALITY .................. Off\n"
" 20. DISTORTION ..................... Off\n"
" 21. CAST SHADOWS ................... Off\n"
"\n"
" 22. Press APPLY (it sits beside REVERT, above the FPS\n"
"     limit rows). Do NOT press REVERT - it undoes the\n"
"     whole page.\n"
"\n"
"WHY THESE ARE NOT IN THE UTILITY\n"
"--------------------------------\n"
"Every setting above is stored in the game's own binary\n"
"per-account store and synced to your Riot account - none\n"
"of them exists as a plain key in GameUserSettings.ini,\n"
"so no outside editor can touch them. Same story as the\n"
"Rocket League encrypted save, but with plaintext files\n"
"left alone: the utility writes only the two honest file\n"
"rows and never the store.\n";
}

const char* RocketLeagueGuide() {
    return
"==============================================================\n"
" ROCKET LEAGUE - NVRX GUIDE: SETTINGS THE UTILITY CANNOT CHANGE\n"
"==============================================================\n"
"\n"
"ALREADY SET BY THE UTILITY (do not touch these in-game)\n"
"-------------------------------------------------------\n"
"  High quality shaders ............... off\n"
"  World detail ....................... performance (low)\n"
"  Dynamic shadows .................... off\n"
"  Bloom (glow) ....................... off\n"
"  Depth of field ..................... off\n"
"  Motion blur ........................ off\n"
"  Vertical sync ...................... off\n"
"  Anti-aliasing (MSAA) ............... off (1x)\n"
"  Anisotropic filtering .............. off (0)\n"
"  Per-frame FPS limiter (throttle) ... removed (FPS runs free)\n"
"  Ambient occlusion .................. off (file value)\n"
"\n"
"STILL TO SET INSIDE THE GAME (one time, about 30 seconds)\n"
"-------------------------------------------------------\n"
"Open:  Rocket League -> SETTINGS -> GRAPHICS tab\n"
"\n"
"ADVANCED SETTINGS (right column):\n"
"  1. TEXTURE QUALITY ....... pick the lowest entry\n"
"  2. PARTICLE QUALITY ...... the slot may display EMPTY (known\n"
"                             quirk) - just open the list and\n"
"                             pick the lowest entry; this also\n"
"                             repairs the blank readout\n"
"  3. EFFECT INTENSITY ...... pick any non-default (reduced)\n"
"                             entry\n"
"  4. LIGHT SHAFTS .......... uncheck\n"
"  5. LENS FLARES ........... uncheck\n"
"  6. WEATHER EFFECTS ....... uncheck\n"
"  7. VOLUMETRIC LIGHT ...... leave unchecked\n"
"  8. HIGH QUALITY SHADERS .. leave unchecked (already done)\n"
"\n"
"BASIC SETTINGS (left column):\n"
"  9. RENDER QUALITY ........ lowest entry. NOTE: this is the\n"
"                            render scale - the picture gets\n"
"                            softer while FPS goes up. If you\n"
"                            dislike the look, set it back to\n"
"                            High in-game.\n"
" 10. IMAGE QUALITY ......... lowest entry\n"
" 11. FRAME RATE ............ pick the MAXIMUM value in the\n"
"                            list (it is the fps CAP - a higher\n"
"                            cap means more frames)\n"
"\n"
" 12. Press APPLY (the button under WINDOW SETTINGS), leave\n"
"     the menu, then quit Rocket League once.\n"
"\n"
"IMPORTANT\n"
"---------\n"
" - Do NOT press \"BY DEFAULT\" - it resets everything to High.\n"
" - After you quit the game it rewrites TASystemSettings.ini and\n"
"   the light shafts / lens flares lines settle to False - the\n"
"   utility then loads the Rocket League tab all green.\n"
" - The config-side .bak file restores the utility-owned half\n"
"   (there is also an \"Open Folder\" button on the card).\n";
}

using RulesFn = const Rule* (*)(size_t*);
using PathFn = std::string (*)(void);

std::string FortnitePath();
std::string Cs2Path();
std::string RobloxPath();
std::string RobloxFlagsPath();
std::string RocketLeaguePath();
std::string ValorantPath();

struct Profile {
    const char* id;
    const char* name;
    const wchar_t* procs[3];
    Fmt fmt;
    bool allowInsert;
    RulesFn rules;
    PathFn paths;
    bool allowCreate;
    const char* file;
    const char* banner;
    const char* guide;
};

const Profile k_profiles[] = {
    { "fortnite", "Fortnite",
      { L"FortniteClient-Win64-Shipping.exe",
        L"FortniteClient-Win64-Shipping_EOS.exe", nullptr },
      FmtIni, true, &FortniteRules, &FortnitePath, false, "GameUserSettings.ini",
      "Writes Fortnite GameUserSettings.ini directly - close Fortnite "
      "first, the game rewrites the file on exit. "
      "GameUserSettings.ini.bak restores the previous state.",
      nullptr },

    { "cs2", "CS2",
      { L"cs2.exe", nullptr, nullptr },
      FmtKv, false, &Cs2Rules, &Cs2Path, false, "cs2_video.txt",
      "Writes CS2 cs2_video.txt directly - close CS2 first, the game "
      "rewrites the file on exit. cs2_video.txt.bak restores the "
      "previous state.",
      nullptr },

    { "roblox", "Roblox",
      { L"RobloxPlayerBeta.exe", nullptr, nullptr },
      FmtXml, false, &RobloxRules, &RobloxPath, false, "GlobalBasicSettings_13.xml",
      "Writes Roblox GlobalBasicSettings_13.xml directly - close Roblox "
      "first, the game rewrites the file on exit. The .bak restores the "
      "previous state.",
      nullptr },

    { "robloxff", "Roblox FFlags",
      { L"RobloxPlayerBeta.exe", nullptr, nullptr },
      FmtKv, false, &RobloxFlagRules, &RobloxFlagsPath, true, "ClientAppSettings.json",
      "Writes the FFlag file inside the Roblox version folder - Apply "
      "creates it if missing. Loads on the next launch; only allowlisted "
      "flags take effect, and a Roblox update replaces the file.",
      nullptr },

    { "rocketleague", "Rocket League",
      { L"RocketLeague.exe", nullptr, nullptr },
      FmtIni, false, &RocketLeagueRules, &RocketLeaguePath, false, "TASystemSettings.ini",
      "Writes Rocket League TASystemSettings.ini directly - close the game "
      "first, it rewrites the file on exit. The .bak restores the previous "
      "state.",
      RocketLeagueGuide() },

    { "valorant", "Valorant",
      { L"VALORANT-Win64-Shipping.exe", nullptr, nullptr },
      FmtIni, false, &ValorantRules, &ValorantPath, false, "GameUserSettings.ini",
      "Writes Valorant GameUserSettings.ini directly - close the game first; "
      "Riot-account settings sync can overwrite file edits on boot.",
      ValorantGuide() },
};

const size_t k_profileCount = sizeof(k_profiles) / sizeof(k_profiles[0]);

std::string FortnitePath() {
    char buf[MAX_PATH]{};
    if (!GetEnvironmentVariableA("LOCALAPPDATA", buf, MAX_PATH) || !buf[0])
        return "C:\\Users\\suhoj\\AppData\\Local\\FortniteGame\\Saved\\Config"
               "\\WindowsClient\\GameUserSettings.ini";
    return std::string(buf)
        + "\\FortniteGame\\Saved\\Config\\WindowsClient\\GameUserSettings.ini";
}

std::string SteamRoot() {
    char buf[MAX_PATH * 2]{};
    DWORD size = sizeof(buf);
    if (RegGetValueA(HKEY_CURRENT_USER, "Software\\Valve\\Steam", "SteamPath",
                     RRF_RT_REG_SZ, nullptr, buf, &size) == ERROR_SUCCESS
        && buf[0])
    {
        std::string s = buf;
        for (char& c : s)
            if (c == '/') c = '\\';
        while (s.size() > 1 && s.back() == '\\') s.pop_back();
        return s;
    }
    char pf[MAX_PATH]{};
    if (GetEnvironmentVariableA("ProgramFiles(x86)", pf, MAX_PATH) && pf[0])
        return std::string(pf) + "\\Steam";
    return "C:\\Program Files (x86)\\Steam";
}

std::string Cs2Path() {
    const std::string root = SteamRoot();
    WIN32_FIND_DATAA fd{};
    const std::string pat = root + "\\userdata\\*";
    HANDLE h = FindFirstFileA(pat.c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return std::string();
    std::string found;
    do {
        if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) continue;
        if (fd.cFileName[0] == '.') continue;
        const std::string cand = root + "\\userdata\\" + fd.cFileName
            + "\\730\\local\\cfg\\cs2_video.txt";
        if (FileExists(cand.c_str())) {
            found = cand;
            break;
        }
    } while (FindNextFileA(h, &fd));
    FindClose(h);
    return found;
}

std::string RobloxPath() {
    char buf[MAX_PATH]{};
    if (!GetEnvironmentVariableA("LOCALAPPDATA", buf, MAX_PATH) || !buf[0])
        return std::string();
    return std::string(buf) + "\\Roblox\\GlobalBasicSettings_13.xml";
}

std::string RobloxFlagsPath() {
    char buf[MAX_PATH]{};
    if (!GetEnvironmentVariableA("LOCALAPPDATA", buf, MAX_PATH) || !buf[0])
        return std::string();
    const std::string root = std::string(buf) + "\\Roblox\\Versions";
    WIN32_FIND_DATAA fd{};
    HANDLE h = FindFirstFileA((root + "\\*").c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return std::string();
    std::string found;
    FILETIME best{};
    do {
        if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) continue;
        if (fd.cFileName[0] == '.') continue;
        if (!FileExists((root + "\\" + fd.cFileName + "\\RobloxPlayerBeta.exe").c_str()))
            continue;
        if (found.empty() || CompareFileTime(&fd.ftLastWriteTime, &best) > 0) {
            best = fd.ftLastWriteTime;
            found = root + "\\" + fd.cFileName
                + "\\ClientSettings\\ClientAppSettings.json";
        }
    } while (FindNextFileA(h, &fd));
    FindClose(h);
    return found;
}

std::string RocketLeaguePath() {
    PWSTR w = nullptr;
    if (FAILED(SHGetKnownFolderPath(FOLDERID_Documents, 0, nullptr, &w)))
        return std::string();
    std::string docs;
    if (w) {
        const int need =
            WideCharToMultiByte(CP_ACP, 0, w, -1, nullptr, 0, nullptr, nullptr);
        if (need > 1) {
            docs.resize((size_t)need - 1);
            WideCharToMultiByte(CP_ACP, 0, w, -1, docs.data(), need,
                                nullptr, nullptr);
        }
        CoTaskMemFree(w);
    }
    return docs.empty()
        ? std::string()
        : docs + "\\My Games\\Rocket League\\TAGame\\Config"
                 "\\TASystemSettings.ini";
}

std::string ValorantPath() {

    char home[MAX_PATH];
    home[0] = 0;
    if (GetEnvironmentVariableA("LOCALAPPDATA", home, MAX_PATH) == 0)
        return std::string();
    const std::string base = std::string(home) + "\\VALORANT\\Saved\\Config";

    std::string bestBucket;
    FILETIME ftBucket;
    std::string bestAny;
    FILETIME ftAny;

    WIN32_FIND_DATAA fd;
    HANDLE h = FindFirstFileA((base + "\\*").c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return std::string();
    do {
        if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) continue;
        if (strcmp(fd.cFileName, ".") == 0 || strcmp(fd.cFileName, "..") == 0)
            continue;
        char buf[512];
        snprintf(buf, sizeof(buf), "%s\\%s\\WindowsClient\\GameUserSettings.ini",
            base.c_str(), fd.cFileName);
        if (!FileExists(buf)) continue;
        std::string data;
        if (!ReadFile(buf, data)) continue;

        HANDLE f = CreateFileA(buf, GENERIC_READ, FILE_SHARE_READ, nullptr,
            OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
        FILETIME ft{};
        if (f != INVALID_HANDLE_VALUE) {
            GetFileTime(f, nullptr, nullptr, &ft);
            CloseHandle(f);
        }
        const bool buckets =
            data.find("[ScalabilityGroups]") != std::string::npos;
        if (buckets) {
            if (bestBucket.empty()
                || CompareFileTime(&ft, &ftBucket) > 0) {
                bestBucket = buf;
                ftBucket = ft;
            }
        } else if (bestAny.empty() || CompareFileTime(&ft, &ftAny) > 0) {
            bestAny = buf;
            ftAny = ft;
        }
    } while (FindNextFileA(h, &fd));
    FindClose(h);
    return !bestBucket.empty() ? bestBucket : bestAny;
}

std::string ProfilePath(int index) {
    if (index < 0 || index >= (int)k_profileCount) return std::string();
    return k_profiles[index].paths();
}

int g_active = 0;
unsigned g_epoch = 0;

struct Row {
    std::string title;
    std::string detail;
    const Rule* rule = nullptr;
    int keyCount = 0;
    std::vector<std::string> keys;
    std::vector<std::string> mark;
    std::vector<int> lineIdx;
    std::vector<std::vector<int>> hits;
    int sectionLine = 0;
    int recIndex = -1;
    int currentIndex = -1;
    int pickIndex = -1;
    bool missing = false;
};

bool g_ready = false;
std::vector<std::string> g_lines;
std::vector<Row> g_rows;

void BuildRows() {
    g_rows.clear();
    const Profile& prof = k_profiles[g_active];
    size_t ruleCount = 0;
    const Rule* rules = prof.rules(&ruleCount);
    for (size_t r = 0; r < ruleCount; ++r) {
        const Rule& rule = rules[r];
        Row row;
        row.title = rule.title;
        row.detail = rule.detail;
        row.rule = &rule;

        for (int k = 0; k < 3 && rule.keys[k] && *rule.keys[k]; ++k) {
            row.keys.push_back(rule.keys[k]);
            row.mark.push_back("");
            row.lineIdx.push_back(-1);
            row.hits.push_back({});
        }
        row.keyCount = (int)row.keys.size();

        for (int o = 0; o < 8 && rule.opts[o].label; ++o) {
            if (CiEq(rule.opts[o].value, rule.recommended))
                row.recIndex = o;
        }

        row.sectionLine = -1;
        for (size_t i = 0; i < g_lines.size(); ++i) {
            const std::string& line = g_lines[i];
            if (prof.fmt == FmtIni && line.size() >= 2 && line[0] == '[') {
                if (row.sectionLine < 0 && CiEq(line, rule.section))
                    row.sectionLine = (int)i;
                continue;
            }
            for (int k = 0; k < row.keyCount; ++k) {
                if (row.lineIdx[k] >= 0) continue;
                const char* v = prof.fmt == FmtIni
                    ? IniLineValue(line, row.keys[k].c_str())
                    : prof.fmt == FmtKv
                        ? KvLineValue(line, row.keys[k].c_str())
                        : XmlLineValue(line, row.keys[k].c_str());
                if (!v) continue;
                row.mark[k] = Trim(v);
                row.lineIdx[k] = (int)i;
                row.hits[k].push_back((int)i);
            }
        }

        bool allSameValue = true;
        for (int k = 0; k < row.keyCount; ++k)
            if (row.mark[k] != row.mark[0]) allSameValue = false;
        const bool anyFound = row.lineIdx[0] >= 0;
        row.missing = !anyFound;

        const std::string raw = row.mark.empty() ? "" : row.mark[0];
        if (anyFound) {
            if (!allSameValue) {

                std::string joined = row.mark[0];
                for (int k = 1; k < row.keyCount; ++k)
                    joined += (k == 1 ? "  /  " : " / ") + row.mark[k];
                row.title += " (mixed)";
                row.currentIndex = -2;
            } else {
                for (int o = 0; o < 8 && rule.opts[o].label; ++o)
                    if (CiEq(rule.opts[o].value, raw)) {
                        row.currentIndex = o;
                        break;
                    }
            }
        }

        g_rows.push_back(std::move(row));
    }
    g_ready = !g_rows.empty();
}

struct Insert {
    size_t afterLine;
    std::string text;
};

bool CreateFlagsFile(const std::string& path) {
    std::vector<std::pair<std::string, std::string>> entries;
    for (const Row& row : g_rows) {
        if (row.pickIndex < 0) continue;
        const std::string val = row.rule->opts[row.pickIndex].value;
        for (int k = 0; k < row.keyCount; ++k)
            entries.push_back({ row.keys[k], val });
    }
    if (entries.empty()) return false;

    std::string news = "{\n";
    for (size_t i = 0; i < entries.size(); ++i) {
        news += "    \"" + entries[i].first + "\": \"" + entries[i].second + "\"";
        news += (i + 1 < entries.size()) ? ",\n" : "\n";
    }
    news += "}\n";

    const size_t cut = path.find_last_of('\\');
    if (cut != std::string::npos)
        CreateDirectoryA(path.substr(0, cut).c_str(), nullptr);
    const std::string tmp = path + ".nvrx";
    if (!WriteFile(tmp.c_str(), news)) return false;
    if (!MoveFileExA(tmp.c_str(), path.c_str(), MOVEFILE_REPLACE_EXISTING)) {
        DeleteFileA(tmp.c_str());
        return false;
    }
    return true;
}

bool Apply() {
    if (!g_ready) return false;
    const Profile& prof = k_profiles[g_active];

    const std::string ini = ProfilePath(g_active);
    if (ini.empty()) return false;
    if (!FileExists(ini.c_str())) {
        if (!prof.allowCreate) return false;
        return CreateFlagsFile(ini);
    }
    std::string data;
    if (!ReadFile(ini.c_str(), data)) return false;

    std::vector<std::string> out = g_lines;
    std::vector<Insert> inserts;
    int edits = 0;

    for (const Row& row : g_rows) {
        if (row.pickIndex < 0) continue;
        const Rule& rule = *row.rule;
        const char* want = rule.opts[row.pickIndex].value;
        for (int k = 0; k < row.keyCount; ++k) {
            int li = row.lineIdx[k];
            if (li < 0 || li >= (int)out.size()) {

                if (!prof.allowInsert) continue;
                size_t sec = (size_t)-1;
                for (size_t i = 0; i < out.size(); ++i)
                    if (CiEq(out[i], rule.section)) { sec = i; break; }
                if (sec == (size_t)-1) return false;
                inserts.push_back({ sec, std::string(rule.keys[k]) + "=" + want });
                continue;
            }
            std::string& line = out[(size_t)li];
            const std::string cur = CurrentValue(line, prof.fmt, rule.keys[k]);
            if (CiEq(cur, want)) continue;
            if (!SetValue(line, prof.fmt, rule.keys[k], want)) continue;
            ++edits;
        }
    }

    if (!inserts.empty())
        std::sort(inserts.begin(), inserts.end(),
                  [](const Insert& a, const Insert& b) {
                      return a.afterLine < b.afterLine;
                  });
    for (size_t i = inserts.size(); i-- > 0;) {
        size_t at = inserts[i].afterLine + 1;
        out.insert(out.begin() + (std::ptrdiff_t)at, inserts[i].text);
        ++edits;
    }
    if (!edits) return false;

    std::string news;
    for (size_t i = 0; i < out.size(); ++i) {
        news += out[i];
        news += "\r\n";
    }

    if (!WriteFile((ini + ".bak").c_str(), data)) return false;

    const std::string tmp = ini + ".nvrx";
    if (!WriteFile(tmp.c_str(), news)) return false;
    if (!MoveFileExA(tmp.c_str(), ini.c_str(), MOVEFILE_REPLACE_EXISTING)) {
        DeleteFileA(tmp.c_str());
        return false;
    }
    return true;
}

bool GameRunning() {
    const Profile& prof = k_profiles[g_active];
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return false;

    PROCESSENTRY32W pe{};
    pe.dwSize = sizeof(pe);
    bool found = false;
    if (Process32FirstW(snap, &pe)) {
        do {
            for (int i = 0; i < 3 && prof.procs[i]; ++i)
                if (_wcsicmp(pe.szExeFile, prof.procs[i]) == 0) {
                    found = true;
                    break;
                }
        } while (Process32NextW(snap, &pe) && !found);
    }
    CloseHandle(snap);
    return found;
}

}

int game_count() { return (int)k_profileCount; }

const char* game_name(int index) {
    if (index < 0 || index >= (int)k_profileCount) return "";
    return k_profiles[index].name;
}

const char* game_file(int index) {
    if (index < 0 || index >= (int)k_profileCount) return "";
    return k_profiles[index].file;
}

const char* game_banner(int index) {
    if (index < 0 || index >= (int)k_profileCount) return "";
    return k_profiles[index].banner;
}

bool game_ready(int index) {
    if (index < 0 || index >= (int)k_profileCount) return false;
    const std::string p = ProfilePath(index);
    if (p.empty()) return false;
    return FileExists(p.c_str()) || k_profiles[index].allowCreate;
}

int game_active() { return g_active; }

void set_active(int index) {
    if (index < 0 || index >= (int)k_profileCount) return;
    if (index == g_active) return;
    g_active = index;
    load();
}

unsigned epoch() { return g_epoch; }

bool config_file_exists() {
    const std::string p = ProfilePath(g_active);
    return !p.empty() && FileExists(p.c_str());
}

bool config_creatable() {
    if (g_active < 0 || g_active >= (int)k_profileCount) return false;
    return k_profiles[g_active].allowCreate && !ProfilePath(g_active).empty();
}

bool guide_creatable() {
    if (g_active < 0 || g_active >= (int)k_profileCount) return false;
    return k_profiles[g_active].guide != nullptr;
}

bool write_guide(std::string* outPath) {
    if (g_active < 0 || g_active >= (int)k_profileCount) return false;
    const Profile& prof = k_profiles[g_active];
    if (!prof.guide) return false;
    const std::string cfg = prof.paths();
    if (cfg.empty()) return false;
    const size_t cut = cfg.find_last_of('\\');
    if (cut == std::string::npos) return false;
    const std::string dir = cfg.substr(0, cut);
    if (GetFileAttributesA(dir.c_str()) == INVALID_FILE_ATTRIBUTES)
        CreateDirectoryA(dir.c_str(), nullptr);
    const std::string gpath =
        dir + "\\Nvrx guide - " + std::string(prof.name)
            + " in-game settings.txt";
    if (!WriteFile(gpath.c_str(), prof.guide)) return false;
    if (outPath) *outPath = gpath;
    return true;
}

const char* config_path() {
    static std::string s;
    s = ProfilePath(g_active);
    return s.c_str();
}

bool loaded() { return g_ready; }

void reset() {
    g_ready = false;
    g_lines.clear();
    g_rows.clear();
}

bool load() {
    const std::string ini = ProfilePath(g_active);
    const Profile& prof = k_profiles[g_active];
    std::string data;
    if (ini.empty() || (!ReadFile(ini.c_str(), data) && !prof.allowCreate)) {
        reset();
        return false;
    }

    g_lines.clear();
    size_t p = 0;
    while (p <= data.size()) {
        const size_t e = data.find('\n', p);
        if (e == std::string::npos) {
            if (p < data.size()) g_lines.push_back(data.substr(p));
            break;
        }
        g_lines.push_back(data.substr(p, e - p));
        p = e + 1;
    }
    for (std::string& l : g_lines)
        if (!l.empty() && l.back() == '\r') l.pop_back();

    BuildRows();
    ++g_epoch;
    return g_ready;
}

int item_count() { return (int)g_rows.size(); }

const Item* item(int index) {
    static Item snap;
    if (index < 0 || index >= (int)g_rows.size()) return nullptr;
    const Row& r = g_rows[(size_t)index];
    const Rule& rule = *r.rule;

    snap.title = r.title;
    snap.detail = r.detail;
    snap.missing = r.missing;
    snap.recommended = rule.recommended;
    if (r.recIndex >= 0) snap.recommended = rule.opts[r.recIndex].label;

    snap.current.clear();
    if (r.missing)
        snap.current = "-";
    else if (r.currentIndex >= 0)
        snap.current = rule.opts[r.currentIndex].label;
    else
        snap.current = r.mark.empty() ? "" : r.mark[0];

    snap.changed = false;
    if (r.pickIndex >= 0 && !r.missing) {
        const char* want = rule.opts[r.pickIndex].value;
        for (int k = 0; k < r.keyCount; ++k)
            if (!CiEq(r.mark[k], want)) { snap.changed = true; break; }
    } else if (r.missing && r.pickIndex >= 0) {
        snap.changed = true;
    }

    snap.pick = r.pickIndex;
    return &snap;
}

int option_count(int index) {
    if (index < 0 || index >= (int)g_rows.size()) return 0;
    int n = 0;
    for (int o = 0; o < 8 && g_rows[(size_t)index].rule->opts[o].label; ++o) ++n;
    return n;
}

std::string option(int index, int optionIndex) {
    if (index < 0 || index >= (int)g_rows.size()) return {};
    if (optionIndex < 0 || optionIndex >= 8
        || !g_rows[(size_t)index].rule->opts[optionIndex].label)
        return {};
    return g_rows[(size_t)index].rule->opts[optionIndex].label;
}

void pick(int index, int optionIndex) {
    if (index < 0 || index >= (int)g_rows.size()) return;
    Row& r = g_rows[(size_t)index];
    const int n = option_count(index);
    r.pickIndex = (optionIndex >= 0 && optionIndex < n) ? optionIndex : -1;
}

void recommend_all() {
    for (Row& r : g_rows)
        if (r.recIndex >= 0) r.pickIndex = r.recIndex;
}

int changed_count() {
    int n = 0;
    for (const Row& r : g_rows) {
        if (r.pickIndex < 0) continue;
        const Rule& rule = *r.rule;
        const char* want = rule.opts[r.pickIndex].value;
        bool differs = false;
        for (int k = 0; k < r.keyCount; ++k)
            if (r.lineIdx[k] < 0 || !CiEq(r.mark[k], want)) {
                differs = true;
                break;
            }
        if (differs) ++n;
    }
    return n;
}

int MismatchCount() {
    int n = 0;
    for (const Row& r : g_rows) {
        if (r.missing || r.lineIdx[0] < 0) continue;
        const Rule& rule = *r.rule;
        bool differs = false;
        for (int k = 0; k < r.keyCount; ++k)
            if (!CiEq(r.mark[k], rule.recommended)) {
                differs = true;
                break;
            }
        if (differs) ++n;
    }
    return n;
}

bool game_running() { return GameRunning(); }

bool apply() { return Apply(); }

std::string status_text() {
    const Profile& prof = k_profiles[g_active];
    const std::string ini = ProfilePath(g_active);
    if (ini.empty())
        return std::string(prof.name) + " Config Not Found - Launch The Game Once";
    if (!FileExists(ini.c_str())) {
        if (!prof.allowCreate)
            return std::string(prof.name) + " Config Not Found - Launch The Game Once";
        const int ch = changed_count();
        if (ch > 0) {
            char buf2[96];
            snprintf(buf2, sizeof(buf2),
                     "No File Yet - %d Change(s) Staged - Press Apply Settings", ch);
            return buf2;
        }
        return std::string("No File Yet - Press Recommended For The Suggested ")
            + "Values";
    }
    if (!g_ready)
        return "Config Found - Could Not Be Parsed";
    const int ch = changed_count();
    if (GameRunning())
        return std::string("Loaded - Close ") + prof.name + " Before Applying"
            + (ch > 0 ? (" - " + std::to_string(ch) + " Changed")
                      : MismatchCount() > 0 ? " - Not At Recommended"
                                            : " - At Recommended");
    if (ch > 0) {
        char buf[96];
        snprintf(buf, sizeof(buf),
                 "Loaded - %d Changed - Press Apply Settings", ch);
        return buf;
    }
    if (MismatchCount() > 0)
        return "Loaded - Press Recommended For The Suggested Values";
    return "Loaded - Already At The Recommended Values";
}

}}
