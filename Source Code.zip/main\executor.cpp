#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <shellapi.h>
#include <string>
#include <vector>
#include "executor.hpp"

#pragma comment(lib, "shell32.lib")

namespace nvrx::exec {

std::wstring exe_dir() {
    wchar_t buf[MAX_PATH]{};
    GetModuleFileNameW(nullptr, buf, MAX_PATH);
    std::wstring s = buf;
    if (auto p = s.find_last_of(L"\\/"); p != std::wstring::npos) s.resize(p);
    return s;
}

bool is_admin() {
    BOOL admin = FALSE;
    SID_IDENTIFIER_AUTHORITY nt = SECURITY_NT_AUTHORITY;
    PSID group = nullptr;
    if (AllocateAndInitializeSid(&nt, 2, SECURITY_BUILTIN_DOMAIN_RID, DOMAIN_ALIAS_RID_ADMINS,
                                 0, 0, 0, 0, 0, 0, &group)) {
        CheckTokenMembership(nullptr, group, &admin);
        FreeSid(group);
    }
    return admin == TRUE;
}

std::string utf8_from_wide(const std::wstring& w) {
    if (w.empty()) return {};
    int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), nullptr, 0, nullptr, nullptr);
    std::string o((size_t)n, 0);
    WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), o.data(), n, nullptr, nullptr);
    return o;
}

std::string utf8_from_oem(const char* data, size_t len) {
    if (!data || !len) return {};
    int wn = MultiByteToWideChar(CP_OEMCP, 0, data, (int)len, nullptr, 0);
    if (wn <= 0) return std::string(data, len);
    std::wstring w((size_t)wn, 0);
    MultiByteToWideChar(CP_OEMCP, 0, data, (int)len, w.data(), wn);
    return utf8_from_wide(w);
}

static void emit_lines(std::string& buf, LogCb& cb) {
    size_t pos = 0;
    while (true) {
        size_t e = buf.find('\n', pos);
        if (e == std::string::npos) break;
        std::string line = buf.substr(pos, e - pos);
        if (!line.empty() && line.back() == '\r') line.pop_back();

        while (!line.empty() && (line.back() == ' ' || line.back() == '\t')) line.pop_back();
        if (!line.empty()) {
            int lv = L_DIM;
            if (line.rfind("[Nvrx]", 0) == 0) lv = L_INFO;
            if (line.find("Done:") != std::string::npos) lv = L_OK;
            if (line.find("FAILED") != std::string::npos || line.find("failed") != std::string::npos ||
                line.find("ERROR") != std::string::npos || line.find("error") != std::string::npos)
                lv = L_ERR;
            cb(lv, line);
        }
        pos = e + 1;
    }
    buf.erase(0, pos);
}

bool run_script(const char* id, const char* script, LogCb cb) {
    if (!id || !*id || !script || !*script) {
        cb(L_ERR, std::string("Empty Script: ") + (id ? id : "?"));
        return false;
    }

    wchar_t tmpdir[MAX_PATH]{};
    if (!GetTempPathW(MAX_PATH, tmpdir)) {
        cb(L_ERR, "Cannot Resolve Temp Path");
        return false;
    }
    wchar_t pgmdir[MAX_PATH]{};
    std::wstring stagedir;
    if (GetEnvironmentVariableW(L"ProgramData", pgmdir, MAX_PATH) > 0) {
        stagedir = std::wstring(pgmdir) + L"\\Nvrx\\";
        CreateDirectoryW(stagedir.c_str(), nullptr);
    } else {
        stagedir = tmpdir;
    }
    int n = MultiByteToWideChar(CP_UTF8, 0, id, -1, nullptr, 0);
    std::wstring wid((size_t)(n > 1 ? n - 1 : 0), 0);
    if (n > 1) MultiByteToWideChar(CP_UTF8, 0, id, -1, wid.data(), n);
    const std::wstring bat = stagedir + L"nvrx_" + wid + L".bat";
    {
        HANDLE f = CreateFileW(bat.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
        if (f == INVALID_HANDLE_VALUE) {
            cb(L_ERR, "Cannot Stage Temp Script");
            return false;
        }
        DWORD written = 0;
        const DWORD len = (DWORD)strlen(script);
        const BOOL okw = WriteFile(f, script, len, &written, nullptr);
        CloseHandle(f);
        if (!okw || written != len) {
            DeleteFileW(bat.c_str());
            cb(L_ERR, "Cannot Stage Temp Script");
            return false;
        }
    }

    SECURITY_ATTRIBUTES sa{};
    sa.nLength = sizeof(sa);
    sa.bInheritHandle = TRUE;
    HANDLE rd = nullptr, wr = nullptr;
    if (!CreatePipe(&rd, &wr, &sa, 0)) {
        DeleteFileW(bat.c_str());
        cb(L_ERR, "Cannot Create Pipe");
        return false;
    }
    SetHandleInformation(rd, HANDLE_FLAG_INHERIT, 0);

    std::wstring cmd = L"cmd.exe /d /c \"\"" + bat + L"\"\"";
    STARTUPINFOW si{};
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
    si.hStdOutput = wr;
    si.hStdError = wr;
    si.hStdInput = GetStdHandle(STD_INPUT_HANDLE);
    si.wShowWindow = SW_HIDE;
    PROCESS_INFORMATION pi{};
    BOOL started = CreateProcessW(nullptr, cmd.data(), nullptr, nullptr, TRUE,
                                  CREATE_NO_WINDOW | CREATE_UNICODE_ENVIRONMENT,
                                  nullptr, nullptr, &si, &pi);
    CloseHandle(wr);
    wr = nullptr;
    if (!started) {
        CloseHandle(rd);
        DeleteFileW(bat.c_str());
        cb(L_ERR, "Cannot Launch cmd.exe");
        return false;
    }

    char chunk[4096];
    DWORD got = 0;
    std::string pending;
    bool pipe_open = true;
    while (pipe_open) {
        BOOL r = ReadFile(rd, chunk, sizeof(chunk), &got, nullptr);
        if (!r || got == 0) {
            if (WaitForSingleObject(pi.hProcess, 50) == WAIT_OBJECT_0) {

                while (true) {
                    DWORD avail = 0;
                    if (!PeekNamedPipe(rd, nullptr, 0, nullptr, &avail, nullptr) || avail == 0) break;
                    if (!ReadFile(rd, chunk, sizeof(chunk), &got, nullptr) || got == 0) break;
                    pending += utf8_from_oem(chunk, got);
                    emit_lines(pending, cb);
                }
                pipe_open = false;
            }
            continue;
        }
        pending += utf8_from_oem(chunk, got);
        emit_lines(pending, cb);
    }
    if (!pending.empty()) {
        while (!pending.empty() && (pending.back() == '\r' || pending.back() == '\n' || pending.back() == ' ')) pending.pop_back();
        if (!pending.empty()) cb(L_DIM, pending);
    }
    DWORD code = 1;
    GetExitCodeProcess(pi.hProcess, &code);
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    CloseHandle(rd);
    DeleteFileW(bat.c_str());
    return code == 0;
}

void create_restore_point(LogCb cb) {
    cb(L_INFO, "[Nvrx] Creating Restore Point (Nvrx Pre-Tweak)...");
    std::wstring cmd = L"powershell -NoProfile -ExecutionPolicy Bypass -Command \""
        L"Enable-ComputerRestore -Drive $env:SystemDrive -EA SilentlyContinue; "
        L"Checkpoint-Computer -Description 'Nvrx Pre-Tweak' -RestorePointType 'MODIFY_SETTINGS'\"";
    STARTUPINFOW si{ sizeof(si) };
    PROCESS_INFORMATION pi{};
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    if (CreateProcessW(nullptr, cmd.data(), nullptr, nullptr, FALSE,
                       CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi)) {
        WaitForSingleObject(pi.hProcess, 120000);
        DWORD code = 1;
        GetExitCodeProcess(pi.hProcess, &code);
        CloseHandle(pi.hThread);
        CloseHandle(pi.hProcess);
        if (code == 0) cb(L_OK, "[Nvrx] Restore Point Created");
        else cb(L_WARN, "[Nvrx] Restore Point Failed (Code " + std::to_string(code) + ") - Continuing");
    } else {
        cb(L_WARN, "[Nvrx] Cannot Start PowerShell For Restore Point");
    }
}

void reboot_now(LogCb ) {
    HANDLE tok{};
    if (OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &tok)) {
        LUID luid{};
        if (LookupPrivilegeValueW(nullptr, SE_SHUTDOWN_NAME, &luid)) {
            TOKEN_PRIVILEGES tp{};
            tp.PrivilegeCount = 1;
            tp.Privileges[0].Luid = luid;
            tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
            AdjustTokenPrivileges(tok, FALSE, &tp, sizeof(tp), nullptr, nullptr);
        }
        CloseHandle(tok);
    }
    ExitWindowsEx(EWX_REBOOT | EWX_FORCEIFHUNG, SHTDN_REASON_MAJOR_OTHER);
}

void open_folder(const std::wstring& path) {
    ShellExecuteW(nullptr, L"explore", path.c_str(), nullptr, nullptr, SW_SHOW);
}

}
