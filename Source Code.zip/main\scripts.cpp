#include "scripts.hpp"
#include <cstring>

namespace nvrx {

static const char* S_perf_win32priority =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Win32Priority
echo [Nvrx] === Win32Priority ===
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\PriorityControl" /v Win32PrioritySeparation /t REG_DWORD /d 0x18 /f
echo [Nvrx] Done: Win32Priority
exit /b 0
)NVRXBAT";

static const char* S_perf_mmcss =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Optimize MMCSS
echo [Nvrx] === Optimize MMCSS ===
reg add "HKLM\SYSTEM\CurrentControlSet\Services\MMCSS" /v "Start" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "NoLazyMode" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "NetworkThrottlingIndex" /t REG_DWORD /d 10 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "SystemResponsiveness" /t REG_DWORD /d 10 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "LazyModeTimeout" /t REG_DWORD /d 4294967295 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "SchedulerPeriod" /t REG_DWORD /d 1000000 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "IdleDetectionCycles" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "SchedulerTimerResolution" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Audio" /v "Priority" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Audio" /v "Scheduling Category" /t REG_SZ /d "High" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Audio" /v "Priority When Yielded" /t REG_DWORD /d 19 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Pro Audio" /v "Priority" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Pro Audio" /v "Scheduling Category" /t REG_SZ /d "High" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Pro Audio" /v "Priority When Yielded" /t REG_DWORD /d 19 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Playback" /v "Priority" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Playback" /v "Scheduling Category" /t REG_SZ /d "High" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Playback" /v "Priority When Yielded" /t REG_DWORD /d 19 /f
echo [Nvrx] Done: Optimize MMCSS
exit /b 0
)NVRXBAT";

static const char* S_perf_fth =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Disable FTH
echo [Nvrx] === Disable FTH ===
reg add "HKLM\SOFTWARE\Microsoft\FTH" /v "Enabled" /t REG_DWORD /d "0" /f
echo [Nvrx] Done: Disable FTH
exit /b 0
)NVRXBAT";

static const char* S_perf_hags =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Enable HAGS
echo [Nvrx] === Enable HAGS ===
reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v "HwSchMode" /t REG_DWORD /d "2" /f
echo [Nvrx] Done: Enable HAGS
exit /b 0
)NVRXBAT";

static const char* S_perf_gamebar_dvr =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Disable Gamebar and GameDVR
echo [Nvrx] === Disable Gamebar and GameDVR ===
reg add "HKLM\SOFTWARE\Microsoft\WindowsRuntime\ActivatableClassId\Windows.Gaming.GameBar.PresenceServer.Internal.PresenceWriter" /v "ActivationType" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR" /v "AppCaptureEnabled" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v "AppCaptureEnabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\GameBar" /v "AllowAutoGameMode" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\GameBar" /v "GamePanelStartupTipIndex" /t REG_DWORD /d 3 /f
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\ApplicationManagement\AllowGameDVR" /v "value" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\GameBar" /v "ShowStartupPanel" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\GameBar" /v "UseNexusForGameBarEnabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\GameBar" /v "AutoGameModeEnabled" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR" /v "AutoGameModeEnabled" /t REG_DWORD /d 1 /f
echo [Nvrx] Done: Disable Gamebar and GameDVR
exit /b 0
)NVRXBAT";

static const char* S_perf_fse =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Enable FSE
echo [Nvrx] === Enable FSE ===
reg add "HKCU\System\GameConfigStore" /v "GameDVR_FSEBehavior" /t REG_DWORD /d 2 /f
reg add "HKCU\System\GameConfigStore" /v "GameDVR_FSEBehaviorMode" /t REG_DWORD /d 2 /f
reg add "HKCU\System\GameConfigStore" /v "GameDVR_HonorUserFSEBehaviorMode" /t REG_DWORD /d 1 /f
reg add "HKCU\System\GameConfigStore" /v "GameDVR_DXGIHonorFSEWindowsCompatible" /t REG_DWORD /d 1 /f
reg add "HKCU\System\GameConfigStore" /v "GameDVR_EFSEFeatureFlags" /t REG_DWORD /d 0 /f
echo [Nvrx] Done: Enable FSE
exit /b 0
)NVRXBAT";

static const char* S_perf_gamemode =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Enable GameMode
echo [Nvrx] === Enable GameMode ===
reg add "HKCU\SOFTWARE\Microsoft\GameBar" /v "AllowAutoGameMode" /t REG_DWORD /d "1" /f
echo [Nvrx] Done: Enable GameMode
exit /b 0
)NVRXBAT";

static const char* S_perf_windowed_opt =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Enable Windowed Game Optimizations
echo [Nvrx] === Enable Windowed Game Optimizations ===
reg add "HKCU\SOFTWARE\Microsoft\DirectX\UserGpuPreferences" /v "DirectXUserGlobalSettings" /t REG_SZ /d "VRROptimizeEnable=0;SwapEffectUpgradeEnable=1;" /f
echo [Nvrx] Done: Enable Windowed Game Optimizations
exit /b 0
)NVRXBAT";

static const char* S_perf_nvidia =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Nvidia GPU Optimization
echo [Nvrx] === Nvidia GPU Optimization ===
reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v "TdrDelay" /t REG_DWORD /d 8 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v "TdrDdiDelay" /t REG_DWORD /d 8 /f
reg delete "HKLM\SOFTWARE\Microsoft\Windows\Dwm" /v "OverlayTestMode" /f
set "base=HKLM\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}"
for /f "tokens=*" %%A in ('reg query "%base%" /k /f "*" ^| findstr /r "\\....$"') do (
    reg query "%%A" /v "ProviderName" 2>nul | find /i "NVIDIA" >nul
    if not errorlevel 1 (
        echo NVIDIA GPU Found: %%A
        goto :nvidiatweaks
    )
)
echo No NVIDIA GPU Found - Skipped
exit /b 0

:nvidiatweaks
powershell -NoProfile -ExecutionPolicy Bypass -Command "& { $gpus = Get-PnpDevice -Class Display | Where-Object { $_.InstanceId -match '^PCI\\VEN_(10DE|1002)' }; if (-not $gpus) { Write-Host 'No NVIDIA/AMD GPU found (PCI\VEN_10DE / PCI\VEN_1002)' } else { foreach ($g in $gpus) { $p = ('HKLM:\SYSTEM\CurrentControlSet\Enum\' + $g.InstanceId + '\Device Parameters\Interrupt Management\MessageSignaledInterruptProperties'); if (-not (Test-Path $p)) { New-Item -Path $p -Force | Out-Null }; $cur = (Get-ItemProperty -Path $p -Name MSISupported -ErrorAction SilentlyContinue).MSISupported; if ($cur -ne 1) { Set-ItemProperty -Path $p -Name MSISupported -Value 1; Write-Host ('MSI ON  -> ' + $g.FriendlyName) } else { Write-Host ('Already MSI -> ' + $g.FriendlyName) } } } }"
curl -g -L -# --fail --connect-timeout 20 --retry 2 --max-time 120 -o "C:\Nvrx\nvidiaProfileInspector.zip" "https://github.com/Orbmu2k/nvidiaProfileInspector/releases/download/v3.0.2.1/nvidiaProfileInspector.zip"
powershell -NoProfile -Command "Expand-Archive -Path 'C:\Nvrx\nvidiaProfileInspector.zip' -DestinationPath 'C:\Nvrx\NvidiaProfileInspector' -Force"
curl -g -L -# --fail --connect-timeout 20 --retry 2 --max-time 120 -o "C:\Nvrx\NvidiaProfileInspector\Nvrx Tweaking NVPI V3.nip" "https://www.dropbox.com/scl/fi/q1qwvr0byk4dguj6h6qf1/Nvrx-Tweaking-NVPI-V3.nip?rlkey=4pcez6axeq7g1xcvhag9cajb3&st=b2f1m2wd&dl=1"
start "" /wait "C:\Nvrx\NvidiaProfileInspector\nvidiaProfileInspector.exe" -silentImport "C:\Nvrx\NvidiaProfileInspector\Nvrx Tweaking NVPI V3.nip"
del /f /q "C:\Nvrx\nvidiaProfileInspector.zip"
reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v MiracastForceDisable /t REG_DWORD /d 1 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v HwSchMode /t REG_DWORD /d 2 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v EnableRuntimePowerManagement /t REG_DWORD /d 0 /f
echo [Nvrx] Done: Nvidia GPU Optimization
exit /b 0
)NVRXBAT";

static const char* S_perf_amd =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - AMD GPU Optimization
echo [Nvrx] === AMD GPU Optimization ===
set "base=HKLM\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}"
set "target="
for /f "tokens=*" %%A in ('reg query "%base%" /k /f "*" ^| findstr /r "\\....$"') do (
    reg query "%%A" /v "ProviderName" 2>nul | find /i "Advanced Micro Devices, Inc." >nul
    if not errorlevel 1 (
        set "target=%%A"
        echo AMD GPU Found: %%A
        goto :amdtweaks
    )
)
echo No AMD GPU Found - Skipped
exit /b 0

:amdtweaks
powershell -NoProfile -ExecutionPolicy Bypass -Command "& { $gpus = Get-PnpDevice -Class Display | Where-Object { $_.InstanceId -match '^PCI\\VEN_(10DE|1002)' }; if (-not $gpus) { Write-Host 'No NVIDIA/AMD GPU found (PCI\VEN_10DE / PCI\VEN_1002)' } else { foreach ($g in $gpus) { $p = ('HKLM:\SYSTEM\CurrentControlSet\Enum\' + $g.InstanceId + '\Device Parameters\Interrupt Management\MessageSignaledInterruptProperties'); if (-not (Test-Path $p)) { New-Item -Path $p -Force | Out-Null }; $cur = (Get-ItemProperty -Path $p -Name MSISupported -ErrorAction SilentlyContinue).MSISupported; if ($cur -ne 1) { Set-ItemProperty -Path $p -Name MSISupported -Value 1; Write-Host ('MSI ON  -> ' + $g.FriendlyName) } else { Write-Host ('Already MSI -> ' + $g.FriendlyName) } } } }"
reg add "%target%" /v "ReportAnalytics" /t REG_DWORD /d 0 /f
reg add "%target%" /v "NotifySubscription" /t REG_DWORD /d 0 /f
reg add "%target%" /v "AllowSubscription" /t REG_DWORD /d 0 /f
reg add "%target%" /v "ShowReleaseNotes" /t REG_DWORD /d 0 /f
reg add "%target%" /v "KMD_ChillEnabled" /t REG_DWORD /d 0 /f
reg add "%target%" /v "KMD_RadeonBoostEnabled" /t REG_DWORD /d 0 /f
reg add "%target%" /v "EnableUlps" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\AMD\CN" /v "AutoUpdate" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\AMD\CN" /v "AutoUpdateTriggered" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\AMD\CN" /v "PowerSaverAutoEnable_CUR" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\AMD\CN" /v "AllowWebContent" /t REG_SZ /d "false" /f
reg add "HKCU\Software\AMD\CN" /v "CN_Hide_Toast_Notification" /t REG_SZ /d "true" /f
reg add "HKCU\Software\AMD\CN" /v "AnimationEffect" /t REG_SZ /d "false" /f
reg add "HKCU\Software\AMD\DVR" /v "PrevInstantReplayEnable" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\AMD\DVR" /v "PrevInGameReplayEnabled" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\AMD\DVR" /v "PrevInstantGifEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v "TdrDelay" /t REG_DWORD /d 8 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v "TdrDdiDelay" /t REG_DWORD /d 8 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\Dwm" /v "OverlayTestMode" /t REG_DWORD /d 5 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v MiracastForceDisable /t REG_DWORD /d 1 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v HwSchMode /t REG_DWORD /d 2 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v EnableRuntimePowerManagement /t REG_DWORD /d 0 /f
echo [Nvrx] Done: AMD GPU Optimization
exit /b 0
)NVRXBAT";

static const char* S_sys_ntfs =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - NTFS Tweaks
echo [Nvrx] === NTFS Tweaks ===
fsutil 8dot3name set 1
fsutil behavior set disablelastaccess 1
fsutil behavior set encryptpagingfile 0
fsutil behavior set DisableDeleteNotify 0
echo [Nvrx] Done: NTFS Tweaks
exit /b 0
)NVRXBAT";

static const char* S_sys_hibernation =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Disable Hibernation
echo [Nvrx] === Disable Hibernation ===
powercfg /h off
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v "HibernateChecksummingEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v "SkipHibernateMemoryMapValidation" /t REG_DWORD /d 1 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v "AllowHibernate" /t REG_DWORD /d 0 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v "HibernateEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v "HiberbootEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power" /v "HibernateEnabledDefault" /t REG_DWORD /d 0 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power\ForceHibernateDisabled" /v "Policy" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\FlyoutMenuSettings" /v "ShowHibernateOption" /t REG_DWORD /d 0 /f
echo [Nvrx] Done: Disable Hibernation
exit /b 0
)NVRXBAT";

static const char* S_sys_power_plan =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Import Nvrx Power Plan
echo [Nvrx] === Import Nvrx Power Plan ===
if not exist "C:\Nvrx\Power Plan\" mkdir "C:\Nvrx\Power Plan\"
echo Get Nvrx Ultimate Power Plan V2.1.pow
curl -g -L --fail -sS --connect-timeout 20 --retry 2 --remove-on-error -o "C:\Nvrx\Power Plan\Nvrx Ultimate Power Plan V2.1.pow" "https://www.dropbox.com/scl/fi/9rekkoww3ym9d9gyruv1m/Nvrx-Ultimate-Power-Plan-V2.1.pow?rlkey=wlxqzjcyrlx62ds3ojbduvnls&st=0v8127et&dl=1"
if exist "C:\Nvrx\Power Plan\Nvrx Ultimate Power Plan V2.1.pow" (
powercfg -import "C:\Nvrx\Power Plan\Nvrx Ultimate Power Plan V2.1.pow" 99771111-4b7f-1111-8888-771177884b7f
powercfg -setactive 99771111-4b7f-1111-8888-771177884b7f
)
echo [Nvrx] Done: Import Nvrx Power Plan
exit /b 0
)NVRXBAT";

static const char* S_sys_kbm =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Apply KBM Tweaks
echo [Nvrx] === Apply KBM Tweaks ===
reg add "HKCU\Control Panel\Mouse" /v MouseSpeed /t REG_SZ /d "0" /f
reg add "HKCU\Control Panel\Mouse" /v MouseThreshold1 /t REG_SZ /d "0" /f
reg add "HKCU\Control Panel\Mouse" /v MouseThreshold2 /t REG_SZ /d "0" /f
reg add "HKCU\Control Panel\Mouse" /v MouseSensitivity /t REG_SZ /d "10" /f
reg add "HKCU\Control Panel\Mouse" /v MouseTrails /t REG_SZ /d "0" /f
reg add "HKCU\Control Panel\Mouse" /v "RawMouseThrottleDuration" /t REG_DWORD /d 20 /f
reg add "HKCU\Control Panel\Keyboard" /v KeyboardDelay /t REG_SZ /d "0" /f
reg add "HKCU\Control Panel\Keyboard" /v KeyboardSpeed /t REG_SZ /d "31" /f
reg add "HKCU\Control Panel\Keyboard" /v InitialKeyboardIndicators /t REG_SZ /d "2" /f
reg add "HKEY_USERS\.DEFAULT\Control Panel\Keyboard" /v InitialKeyboardIndicators /t REG_SZ /d "2" /f
reg add "HKEY_USERS\.DEFAULT\Control Panel\Keyboard" /v KeyboardDelay /t REG_SZ /d "0" /f
reg add "HKEY_USERS\.DEFAULT\Control Panel\Keyboard" /v KeyboardSpeed /t REG_SZ /d "31" /f
reg add "HKCU\Control Panel\Accessibility\MouseKeys" /v "Flags" /t REG_SZ /d "0" /f
reg add "HKCU\Control Panel\Accessibility\StickyKeys" /v "Flags" /t REG_SZ /d "0" /f
reg add "HKCU\Control Panel\Accessibility\ToggleKeys" /v "Flags" /t REG_SZ /d "0" /f
reg add "HKCU\Control Panel\Accessibility\Keyboard Response" /v "Flags" /t REG_DWORD /d "0" /f
reg add "HKCU\Control Panel\Accessibility\Keyboard Response" /v "DelayBeforeAcceptance" /t REG_SZ /d "0" /f
reg add "HKCU\Control Panel\Accessibility\Keyboard Response" /v "Last BounceKey Setting" /t REG_DWORD /d "0" /f
reg add "HKCU\Control Panel\Accessibility\Keyboard Response" /v "Last Valid Delay" /t REG_DWORD /d "0" /f
reg add "HKCU\Control Panel\Accessibility\Keyboard Response" /v "Last Valid Repeat" /t REG_DWORD /d "0" /f
reg add "HKCU\Control Panel\Accessibility\Keyboard Response" /v "Last Valid Wait" /t REG_DWORD /d "0" /f
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='SilentlyContinue'; $ProgressPreference='SilentlyContinue'; $HKLM='HKLM:\SYSTEM\CurrentControlSet'; New-ItemProperty -Path \"$HKLM\Services\USB\" -Name DisableSelectiveSuspend -Value 1 -PropertyType DWord -Force | Out-Null; New-ItemProperty -Path \"$HKLM\Services\usbhub\" -Name DisableSelectiveSuspend -Value 1 -PropertyType DWord -Force | Out-Null; New-ItemProperty -Path \"$HKLM\Control\usb\Usb20HardwareLpm\" -Name Usb20HardwareLpmOverride -Value 0 -PropertyType DWord -Force | Out-Null; New-ItemProperty -Path \"$HKLM\Control\usb\UsbLtm\" -Name UsbLtmEnable -Value 0 -PropertyType DWord -Force | Out-Null; $devs=@(); foreach($cls in @('USB','HIDClass','Mouse','Keyboard','USBDevice','HID')){ $devs+=@(Get-PnpDevice -PresentOnly -Class $cls) }; $seen=@{}; foreach($d in $devs){ if(-not $d){continue}; $id=[string]$d.InstanceId; if([string]::IsNullOrWhiteSpace($id) -or $seen.ContainsKey($id)){continue}; $seen[$id]=$true; $p=\"$HKLM\Enum\$id\Device Parameters\"; foreach($flag in @('EnhancedPowerManagementEnabled','AllowIdleIrpInD3','SelectiveSuspendEnabled','SelectiveSuspendOn','DeviceIdleEnabled','D3ColdSupported','EnableSelectiveSuspend')){ Set-ItemProperty -Path $p -Name $flag -Value 0 -Type DWord -Force } }; $powerList=Get-CimInstance -Namespace root\wmi -ClassName MSPower_DeviceEnable; if($powerList){ foreach($power in $powerList){ if($power.Enable){ Set-CimInstance -InputObject $power -Property @{Enable=$false} } } }; Get-PnpDevice -PresentOnly | ForEach-Object { $id=[string]$_.InstanceId; $name=[string]$_.FriendlyName; $isUsb = ($id -like 'PCI\VEN_*') -and (($id -match 'VEN_8086' -and $name -match 'USB|xHCI|eXtensible|Thunderbolt') -or ($id -match 'VEN_1022' -and $name -match 'USB|xHCI|eXtensible|Promontory|400 Series|500 Series|600 Series|800 Series') -or ($id -match 'VEN_1022' -and ($_.Class -eq 'USB' -or $name -match 'USB')) -or ($id -match 'VEN_1B21') -or ($name -match 'USB [23]|xHCI|eXtensible Host Controller|AMD USB|Intel\(R\) USB') -or ($_.Class -eq 'USB')); if($isUsb){ $mp=\"$HKLM\Enum\$id\Device Parameters\Interrupt Management\MessageSignaledInterruptProperties\"; if(-not (Test-Path $mp)){ New-Item $mp -Force | Out-Null }; New-ItemProperty -Path $mp -Name MSISupported -PropertyType DWord -Value 1 -Force | Out-Null } }"
echo [Nvrx] Done: Apply KBM Tweaks
exit /b 0
)NVRXBAT";

static const char* S_sys_xhci_imod =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Disable xHCI-IMOD
echo [Nvrx] === Disable xHCI-IMOD ===
if not exist "C:\Nvrx\xHCI IMOD Disabler\" mkdir "C:\Nvrx\xHCI IMOD Disabler\"
echo Get xHCI-IMOD-Disabler-V1.1.zip
curl -g -L --fail -sS --connect-timeout 20 --retry 2 --remove-on-error -o "C:\Nvrx\xHCI IMOD Disabler\xHCI-IMOD-Disabler-V1.1.zip" "https://www.dropbox.com/scl/fi/sxlld5spfn9qxpt9plnkr/xHCI-IMOD-Disabler-V1.1.zip?rlkey=697ht1ncxxzinkexebsvz80xa&st=6gijqsih&dl=1"
if exist "C:\Nvrx\xHCI IMOD Disabler\xHCI-IMOD-Disabler-V1.1.zip" powershell -NoProfile -Command "Expand-Archive -Path 'C:\Nvrx\xHCI IMOD Disabler\xHCI-IMOD-Disabler-V1.1.zip' -DestinationPath 'C:\Nvrx\xHCI IMOD Disabler' -Force -ErrorAction SilentlyContinue"
del /f /q "C:\Nvrx\xHCI IMOD Disabler\xHCI-IMOD-Disabler-V1.1.zip"
set "XHCI="
for /f "delims=" %%F in ('dir /b /s "C:\Nvrx\xHCI IMOD Disabler\xHCI IMOD Disabler.exe" 2^>nul') do set "XHCI=%%F"
if not defined XHCI (
    echo xHCI IMOD Disabler.exe not found after extraction
    exit /b 2
)
echo Using: %XHCI%
start "" /wait "%XHCI%"
powershell -NoProfile -Command "$exe=$env:XHCI; $a=New-ScheduledTaskAction -Execute $exe -Argument '--Silent'; $t=New-ScheduledTaskTrigger -AtLogOn; $p=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest; Register-ScheduledTask -TaskName 'Nvrx xHCI IMOD' -Action $a -Trigger $t -Principal $p -Force | Out-Null"
echo [Nvrx] Done: Disable xHCI-IMOD
exit /b 0
)NVRXBAT";

static const char* S_sys_network =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Apply Network Tweaks
echo [Nvrx] === Apply Network Tweaks ===
ipconfig /release
ipconfig /renew
ipconfig /flushdns
netsh int ip reset
netsh int ipv4 reset
netsh int ipv6 reset
netsh int tcp reset
netsh winsock reset
netsh advfirewall reset
netsh branchcache reset
netsh http flush logbuffer
netsh int tcp set global rss=enabled
netsh int tcp set global autotuninglevel=normal
netsh int tcp set global rsc=disabled
netsh int tcp set global timestamps=disabled
netsh int tcp set global fastopen=enabled
netsh int isatap set state disabled
netsh int teredo set state disabled
netsh int ip set global neighborcachelimit=4096
netsh int tcp set global fastopenfallback=enabled
netsh int tcp set heuristics disabled
netsh int tcp set supplemental template=custom icw=10
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v "EnableLMHOSTS" /t REG_DWORD /d 0 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v "SackOpts" /t REG_DWORD /d 1 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v "MaxUserPort" /t REG_DWORD /d 65534 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v "TcpTimedWaitDelay" /t REG_DWORD /d 30 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters" /v "MaxCacheEntryTtlLimit" /t REG_DWORD /d 64000 /f
reg add "HKLM\Software\Microsoft\PolicyManager\default\WiFi\AllowAutoConnectToWiFiSenseHotspots" /v "value" /t REG_DWORD /d "0" /f
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-NetAdapter | Where-Object {$_.Status -eq 'Up'} | ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.InterfaceIndex -ServerAddresses @('1.1.1.1','1.0.0.1') -EA SilentlyContinue }; Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters\Interfaces\*' | ForEach-Object { Set-ItemProperty -Path $_.PSPath -Name NetbiosOptions -Value 2 -EA SilentlyContinue }; Get-NetAdapter | Disable-NetAdapterPowerManagement -EA SilentlyContinue; Get-NetAdapter -IncludeHidden | Set-NetIPInterface -WeakHostSend Enabled -WeakHostReceive Enabled -EA SilentlyContinue"
for /f "tokens=*" %%n in ('Reg query "HKLM\SYSTEM\CurrentControlSet\Control\Class\{4D36E972-E325-11CE-BFC1-08002bE10318}" /f "*SpeedDuplex" /s ^| findstr "HKEY"') do (
    reg add "%%n" /v "*EnergyEfficientEthernet" /t REG_SZ /d "0" /f
    reg add "%%n" /v "*EEE" /t REG_SZ /d "0" /f
    reg add "%%n" /v "EEE" /t REG_SZ /d "0" /f
    reg add "%%n" /v "EnableGreenEthernet" /t REG_SZ /d "0" /f
    reg add "%%n" /v "EnablePowerManagement" /t REG_SZ /d "0" /f
    reg add "%%n" /v "PowerSavingMode" /t REG_SZ /d "0" /f
    reg add "%%n" /v "ULPMode" /t REG_SZ /d "0" /f
    reg add "%%n" /v "AutoDisableGigabit" /t REG_SZ /d "0" /f
    reg add "%%n" /v "TCPChecksumOffloadIPv4" /t REG_SZ /d "3" /f
    reg add "%%n" /v "TCPChecksumOffloadIPv6" /t REG_SZ /d "3" /f
    reg add "%%n" /v "UDPChecksumOffloadIPv4" /t REG_SZ /d "3" /f
    reg add "%%n" /v "UDPChecksumOffloadIPv6" /t REG_SZ /d "3" /f
    reg add "%%n" /v "LsoV2IPv4" /t REG_SZ /d "1" /f

reg add "%%n" /v "LsoV2IPv6" /t REG_SZ /d "1" /f
    reg add "%%n" /v "RSS" /t REG_SZ /d "1" /f
    reg add "%%n" /v "*NumRssQueues" /t REG_SZ /d "2" /f
    reg add "%%n" /v "ReceiveBuffers" /t REG_SZ /d "512" /f
    reg add "%%n" /v "TransmitBuffers" /t REG_SZ /d "512" /f
    reg add "%%n" /v "JumboPacket" /t REG_SZ /d "1514" /f
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-NetAdapter | Where-Object { $_.Status -eq 'Up' } | ForEach-Object { $n = $_.Name; @{ 'Speed & Duplex'='Auto Negotiation'; '*SpeedDuplex'='Auto Negotiation' }.GetEnumerator() | ForEach-Object { try { Set-NetAdapterAdvancedProperty -Name $n -DisplayName $_.Name -DisplayValue $_.Value -ErrorAction SilentlyContinue } catch {} } }; $nic='HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4D36E972-E325-11CE-BFC1-08002bE10318}'; Get-ChildItem $nic -EA SilentlyContinue | Where-Object {$_.PSChildName -match '^\d{4}$'} | ForEach-Object { $p='HKLM:\SYSTEM\CurrentControlSet\Enum\'+$_.InstanceId+'\Device Parameters\WDF'; if(!(Test-Path $p)){New-Item $p -Force|Out-Null}; Set-ItemProperty $p 'IdleInD3' 0 -EA SilentlyContinue }"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\NDIS\Parameters" /v "PacketCoalescing" /t REG_DWORD /d 0 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\NDIS\Parameters" /v "NoPauseOnSuspend" /t REG_DWORD /d 1 /f
powershell -NoProfile -ExecutionPolicy Bypass -Command "$patterns = @('Microsoft ISATAP Adapter','Microsoft 6to4 Adapter','Fax','Send to OneNote'); Get-PnpDevice -PresentOnly:$false | Where-Object { $patterns -contains $_.FriendlyName } | ForEach-Object { try { Disable-PnpDevice -InstanceId $_.InstanceId -Confirm:$false -ErrorAction Stop } catch {} }; $keys=Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}' -ErrorAction SilentlyContinue; foreach($key in $keys){ if(Get-ItemProperty -Path $key.PSPath -Name DriverDesc -ErrorAction SilentlyContinue){ New-ItemProperty -Path $key.PSPath -Name PnPCapabilities -PropertyType DWord -Value 24 -Force -ErrorAction SilentlyContinue | Out-Null } }"
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\ServiceProvider" /v "LocalPriority" /t REG_DWORD /d 4 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\ServiceProvider" /v "HostsPriority" /t REG_DWORD /d 5 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\ServiceProvider" /v "DnsPriority" /t REG_DWORD /d 6 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\ServiceProvider" /v "NetbtPriority" /t REG_DWORD /d 7 /f
powershell -NoProfile -ExecutionPolicy Bypass -Command "Set-NetTCPSetting -SettingName internet -MinRto 300 -ErrorAction SilentlyContinue; Disable-NetAdapterBinding -Name '*' -ComponentID ms_lldp -ErrorAction SilentlyContinue; Disable-NetAdapterBinding -Name '*' -ComponentID ms_lltdio -ErrorAction SilentlyContinue; Disable-NetAdapterBinding -Name '*' -ComponentID ms_rspndr -ErrorAction SilentlyContinue; Disable-NetAdapterBinding -Name '*' -ComponentID ms_implat -ErrorAction SilentlyContinue; Disable-NetAdapterBinding -Name '*' -ComponentID ms_rdma_ndk -ErrorAction SilentlyContinue; Disable-NetAdapterQos -Name '*' -ErrorAction SilentlyContinue; Disable-NetAdapterChecksumOffload -Name '*' -ErrorAction SilentlyContinue; Disable-NetAdapterLso -Name '*' -ErrorAction SilentlyContinue; Disable-NetAdapterRsc -Name '*' -ErrorAction SilentlyContinue; Disable-NetAdapterIPsecOffload -Name '*' -ErrorAction SilentlyContinue; Get-NetAdapter -Physical | ForEach-Object { Restart-NetAdapter -Name $_.Name -Confirm:$false -ErrorAction SilentlyContinue }"
w32tm /config /syncfromflags:manual /manualpeerlist:"0.pool.ntp.org 1.pool.ntp.org 2.pool.ntp.org 3.pool.ntp.org"
sc queryex "w32time" | find "STATE" | find /v "RUNNING" >nul || net stop w32time
net start w32time
w32tm /config /update
w32tm /resync /nowait
echo [Nvrx] Done: Apply Network Tweaks
exit /b 0
)NVRXBAT";

static const char* S_sys_device_manager =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Device Manager Tweaks
echo [Nvrx] === Device Manager Tweaks ===
powershell -NoProfile -ExecutionPolicy Bypass -Command "'ACPI Processor Aggregator','ACPI Wake Alarm','Direct memory access controller','Intel(R) Platform Monitoring Technology Device','Microsoft Kernel Debug Network Adapter','Numeric Data Processor' | ForEach-Object { Get-PnpDevice -FriendlyName $_ -ErrorAction SilentlyContinue | Disable-PnpDevice -Confirm:$false -ErrorAction SilentlyContinue }"
echo [Nvrx] Done: Device Manager Tweaks
exit /b 0
)NVRXBAT";

static const char* S_sys_unused_drivers =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Disable Unused Drivers
echo [Nvrx] === Disable Unused Drivers ===
reg add "HKLM\SYSTEM\CurrentControlSet\Services\AcpiPmi" /v "Start" /t REG_DWORD /d "4" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\acpitime" /v "Start" /t REG_DWORD /d "4" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\arcsas" /v "Start" /t REG_DWORD /d "4" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\bam" /v "Start" /t REG_DWORD /d "4" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\bowser" /v "Start" /t REG_DWORD /d "4" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\cht4tiscsi" /v "Start" /t REG_DWORD /d "4" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\cht4vbd" /v "Start" /t REG_DWORD /d "4" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\fdc" /v "Start" /t REG_DWORD /d "4" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\flpydisk" /v "Start" /t REG_DWORD /d "4" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\i8042prt" /v "Start" /t REG_DWORD /d "3" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\ItSas35i" /v "Start" /t REG_DWORD /d "4" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\scfilter" /v "Start" /t REG_DWORD /d "4" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\sfloppy" /v "Start" /t REG_DWORD /d "4" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\SpatialGraphFilter" /v "Start" /t REG_DWORD /d "4" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\WacomPen" /v "Start" /t REG_DWORD /d "4" /f
echo [Nvrx] Done: Disable Unused Drivers
exit /b 0
)NVRXBAT";

static const char* S_priv_telemetry =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Disable Windows Telemetry
echo [Nvrx] === Disable Windows Telemetry ===
set "HOSTS_FILE=%WINDIR%\System32\drivers\etc\hosts"
>> "%HOSTS_FILE%" echo 0.0.0.0 oca.telemetry.microsoft.com
>> "%HOSTS_FILE%" echo 0.0.0.0 oca.microsoft.com
>> "%HOSTS_FILE%" echo 0.0.0.0 kmwatsonc.events.data.microsoft.com
>> "%HOSTS_FILE%" echo 0.0.0.0 watson.telemetry.microsoft.com
>> "%HOSTS_FILE%" echo 0.0.0.0 umwatsonc.events.data.microsoft.com
>> "%HOSTS_FILE%" echo 0.0.0.0 ceuswatcab01.blob.core.windows.net
>> "%HOSTS_FILE%" echo 0.0.0.0 ceuswatcab02.blob.core.windows.net
>> "%HOSTS_FILE%" echo 0.0.0.0 eaus2watcab01.blob.core.windows.net
>> "%HOSTS_FILE%" echo 0.0.0.0 eaus2watcab02.blob.core.windows.net
>> "%HOSTS_FILE%" echo 0.0.0.0 weus2watcab01.blob.core.windows.net
>> "%HOSTS_FILE%" echo 0.0.0.0 weus2watcab02.blob.core.windows.net
>> "%HOSTS_FILE%" echo 0.0.0.0 co4.telecommand.telemetry.microsoft.com
>> "%HOSTS_FILE%" echo 0.0.0.0 cs11.wpc.v0cdn.net
>> "%HOSTS_FILE%" echo 0.0.0.0 cs1137.wpc.gammacdn.net
>> "%HOSTS_FILE%" echo 0.0.0.0 modern.watson.data.microsoft.com
>> "%HOSTS_FILE%" echo 0.0.0.0 functional.events.data.microsoft.com
>> "%HOSTS_FILE%" echo 0.0.0.0 browser.events.data.msn.com
>> "%HOSTS_FILE%" echo 0.0.0.0 self.events.data.microsoft.com
>> "%HOSTS_FILE%" echo 0.0.0.0 v10.events.data.microsoft.com
>> "%HOSTS_FILE%" echo 0.0.0.0 v10c.events.data.microsoft.com
>> "%HOSTS_FILE%" echo 0.0.0.0 us-v10c.events.data.microsoft.com
>> "%HOSTS_FILE%" echo 0.0.0.0 eu-v10c.events.data.microsoft.com
>> "%HOSTS_FILE%" echo 0.0.0.0 v10.vortex-win.data.microsoft.com
>> "%HOSTS_FILE%" echo 0.0.0.0 vortex-win.data.microsoft.com
>> "%HOSTS_FILE%" echo 0.0.0.0 telecommand.telemetry.microsoft.com
>> "%HOSTS_FILE%" echo 0.0.0.0 www.telecommandsvc.microsoft.com
>> "%HOSTS_FILE%" echo 0.0.0.0 umwatson.events.data.microsoft.com
>> "%HOSTS_FILE%" echo 0.0.0.0 watsonc.events.data.microsoft.com
>> "%HOSTS_FILE%" echo 0.0.0.0 eu-watsonc.events.data.microsoft.com
>> "%HOSTS_FILE%" echo 0.0.0.0 v20.events.data.microsoft.com
>> "%HOSTS_FILE%" echo 0.0.0.0 settings-win.data.microsoft.com
>> "%HOSTS_FILE%" echo 0.0.0.0 settings.data.microsoft.com
>> "%HOSTS_FILE%" echo 0.0.0.0 inference.location.live.net
>> "%HOSTS_FILE%" echo 0.0.0.0 location-inference-westus.cloudapp.net
>> "%HOSTS_FILE%" echo 0.0.0.0 maps.windows.com
>> "%HOSTS_FILE%" echo 0.0.0.0 dev.virtualearth.net
>> "%HOSTS_FILE%" echo 0.0.0.0 ecn.dev.virtualearth.net
>> "%HOSTS_FILE%" echo 0.0.0.0 ecn-us.dev.virtualearth.net
>> "%HOSTS_FILE%" echo 0.0.0.0 weathermapdata.blob.core.windows.net
>> "%HOSTS_FILE%" echo 0.0.0.0 config.edge.skype.com
>> "%HOSTS_FILE%" echo 0.0.0.0 evoke-windowsservices-tas.msedge.net
>> "%HOSTS_FILE%" echo 0.0.0.0 cdn.onenote.net
>> "%HOSTS_FILE%" echo 0.0.0.0 tile-service.weather.microsoft.com
schtasks /end /tn "\Microsoft\Windows\Customer Experience Improvement Program\Consolidator"
schtasks /change /tn "\Microsoft\Windows\Customer Experience Improvement Program\Consolidator" /disable
schtasks /end /tn "\Microsoft\Windows\Customer Experience Improvement Program\BthSQM"
schtasks /change /tn "\Microsoft\Windows\Customer Experience Improvement Program\BthSQM" /disable
schtasks /end /tn "\Microsoft\Windows\Customer Experience Improvement Program\KernelCeipTask"
schtasks /change /tn "\Microsoft\Windows\Customer Experience Improvement Program\KernelCeipTask" /disable
schtasks /end /tn "\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip"
schtasks /change /tn "\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip" /disable
schtasks /end /tn "\Microsoft\Windows\Customer Experience Improvement Program\Uploader"
schtasks /change /tn "\Microsoft\Windows\Customer Experience Improvement Program\Uploader" /disable
schtasks /end /tn "\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser"
schtasks /change /tn "\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser" /disable
schtasks /end /tn "\Microsoft\Windows\Application Experience\ProgramDataUpdater"
schtasks /change /tn "\Microsoft\Windows\Application Experience\ProgramDataUpdater" /disable
schtasks /end /tn "\Microsoft\Windows\Application Experience\StartupAppTask"
schtasks /change /tn "\Microsoft\Windows\Application Experience\StartupAppTask" /disable
schtasks /end /tn "\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector"
schtasks /change /tn "\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector" /disable
schtasks /end /tn "\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticResolver"
schtasks /change /tn "\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticResolver" /disable
schtasks /end /tn "\Microsoft\Windows\Power Efficiency Diagnostics\AnalyzeSystem"
schtasks /change /tn "\Microsoft\Windows\Power Efficiency Diagnostics\AnalyzeSystem" /disable
schtasks /end /tn "\Microsoft\Windows\Shell\FamilySafetyMonitor"
schtasks /change /tn "\Microsoft\Windows\Shell\FamilySafetyMonitor" /disable
schtasks /end /tn "\Microsoft\Windows\Shell\FamilySafetyRefresh"
schtasks /change /tn "\Microsoft\Windows\Shell\FamilySafetyRefresh" /disable
schtasks /end /tn "\Microsoft\Windows\Shell\FamilySafetyUpload"
schtasks /change /tn "\Microsoft\Windows\Shell\FamilySafetyUpload" /disable
schtasks /end /tn "\Microsoft\Windows\Autochk\Proxy"
schtasks /change /tn "\Microsoft\Windows\Autochk\Proxy" /disable
schtasks /end /tn "\Microsoft\Windows\Maintenance\WinSAT"
schtasks /change /tn "\Microsoft\Windows\Maintenance\WinSAT" /disable
schtasks /end /tn "\Microsoft\Windows\Application Experience\AitAgent"
schtasks /change /tn "\Microsoft\Windows\Application Experience\AitAgent" /disable
schtasks /end /tn "\Microsoft\Windows\Windows Error Reporting\QueueReporting"
schtasks /change /tn "\Microsoft\Windows\Windows Error Reporting\QueueReporting" /disable
schtasks /end /tn "\Microsoft\Windows\CloudExperienceHost\CreateObjectTask"
schtasks /change /tn "\Microsoft\Windows\CloudExperienceHost\CreateObjectTask" /disable
schtasks /end /tn "\Microsoft\Windows\DiskFootprint\Diagnostics"
schtasks /change /tn "\Microsoft\Windows\DiskFootprint\Diagnostics" /disable
schtasks /end /tn "\Microsoft\Windows\FileHistory\File History (maintenance mode)"
schtasks /change /tn "\Microsoft\Windows\FileHistory\File History (maintenance mode)" /disable
schtasks /end /tn "\Microsoft\Windows\PI\Sqm-Tasks"
schtasks /change /tn "\Microsoft\Windows\PI\Sqm-Tasks" /disable
schtasks /end /tn "\Microsoft\Windows\NetTrace\GatherNetworkInfo"
schtasks /change /tn "\Microsoft\Windows\NetTrace\GatherNetworkInfo" /disable
schtasks /end /tn "\Microsoft\Windows\AppID\SmartScreenSpecific"
schtasks /change /tn "\Microsoft\Windows\AppID\SmartScreenSpecific" /disable
schtasks /end /tn "\Microsoft\Office\OfficeTelemetryAgentFallBack2016"
schtasks /change /tn "\Microsoft\Office\OfficeTelemetryAgentFallBack2016" /disable
schtasks /end /tn "\Microsoft\Office\OfficeTelemetryAgentLogOn2016"
schtasks /change /tn "\Microsoft\Office\OfficeTelemetryAgentLogOn2016" /disable
schtasks /end /tn "\Microsoft\Office\OfficeTelemetryAgentLogOn"
schtasks /change /TN "\Microsoft\Office\OfficeTelemetryAgentLogOn" /disable
schtasks /end /tn "\Microsoftd\Office\OfficeTelemetryAgentFallBack"
schtasks /change /TN "\Microsoftd\Office\OfficeTelemetryAgentFallBack" /disable
schtasks /end /tn "\Microsoft\Office\Office 15 Subscription Heartbeat"
schtasks /change /TN "\Microsoft\Windows\ErrorDetails\EnableErrorDetailsUpdate" /Disable
schtasks /change /TN "\Microsoft\Office\Office 15 Subscription Heartbeat" /disable
schtasks /end /tn "\Microsoft\Windows\Time Synchronization\ForceSynchronizeTime"
schtasks /change /TN "\Microsoft\Windows\Time Synchronization\ForceSynchronizeTime" /disable
schtasks /end /tn "\Microsoft\Windows\Time Synchronization\SynchronizeTime"
schtasks /change /TN "\Microsoft\Windows\Time Synchronization\SynchronizeTime" /disable
schtasks /end /tn "\Microsoft\Windows\WindowsUpdate\Automatic App Update"
schtasks /change /TN "\Microsoft\Windows\WindowsUpdate\Automatic App Update" /disable
schtasks /end /tn "\Microsoft\Windows\Device Information\Device"
schtasks /change /TN "\Microsoft\Windows\Device Information\Device" /disable
reg add "HKLM\Software\Policies\Microsoft\Windows\Windows Error Reporting" /v "Disabled" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\Windows Error Reporting" /v "Disabled" /t REG_DWORD /d 1 /f
reg add "HKLM\Software\Microsoft\Windows\Windows Error Reporting\Consent" /v "DefaultConsent" /t REG_DWORD /d 1 /f
reg add "HKLM\Software\Microsoft\Windows\Windows Error Reporting\Consent" /v "DefaultOverrideBehavior" /t REG_DWORD /d 1 /f
reg add "HKLM\Software\Microsoft\Windows\Windows Error Reporting" /v "DontSendAdditionalData" /t REG_DWORD /d 1 /f
reg add "HKLM\Software\Microsoft\Windows\Windows Error Reporting" /v "LoggingDisabled" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection" /v "AllowTelemetry" /t REG_DWORD /d "0" /f
reg add "HKCU\SOFTWARE\Microsoft\InputPersonalization" /v "RestrictImplicitInkCollection" /t REG_DWORD /d "1" /f
reg add "HKCU\SOFTWARE\Microsoft\InputPersonalization" /v "RestrictImplicitTextCollection" /t REG_DWORD /d "1" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v "POWERSHELL_TELEMETRY_OPTOUT" /t REG_SZ /d "1" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Sensor\Permissions\{BFA794E4-F964-4FDB-90F6-51056BFE4B44}" /v "SensorPermissionState" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Sensor\Overrides\{BFA794E4-F964-4FDB-90F6-51056BFE4B44}" /v "SensorPermissionState" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WUDF" /v "LogEnable" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WUDF" /v "LogLevel" /t REG_DWORD /d "0" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack" /v "ShowSharedDiagnosticLogs" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v "DisableDiagnosticDataViewer" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v "AllowTelemetry" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v "DoNotShowFeedbackNotifications" /t REG_DWORD /d "1" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v "AllowCommercialDataPipeline" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v "AllowDeviceNameInTelemetry" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v "LimitEnhancedDiagnosticDataWindowsAnalytics" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v "MicrosoftEdgeDataOptIn" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v "DisableCommercialDataOptIn" /t REG_DWORD /d "1" /f
reg add "HKCU\SOFTWARE\Microsoft\Assistance\Client\1.0\Settings" /v "ImplicitFeedback" /t REG_DWORD /d "0" /f
reg add "HKCU\SOFTWARE\Microsoft\Siuf\Rules" /v "NumberOfSIUFInPeriod" /t REG_DWORD /d "0" /f
reg add "HKCU\SOFTWARE\Microsoft\Siuf\Rules" /v "PeriodInNanoSeconds" /t REG_DWORD /d "0" /f
reg add "HKCU\SOFTWARE\Policies\Microsoft\Assistance\Client\1.0" /v "NoExplicitFeedback" /t REG_DWORD /d "1" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Assistance\Client\1.0" /v "NoActiveHelp" /t REG_DWORD /d "1" /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" /v "GlobalUserDisabled" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsRunInBackground" /t REG_DWORD /d 2 /f
reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsRunInBackground_UserInControlOfTheseApps" /f
)NVRXBAT"
R"NVRXBAT(reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsRunInBackground_ForceAllowTheseApps" /f
reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsRunInBackground_ForceDenyTheseApps" /f
reg add "HKLM\Software\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Application-Experience/Steps-Recorder" /v "Enabled" /t REG_DWORD /d "0" /f
reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM" /v "EnableLogging" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM" /v "EnableUpload" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedApplications" /v "accesssolution" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedApplications" /v "olksolution" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedApplications" /v "onenotesolution" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedApplications" /v "pptsolution" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedApplications" /v "projectsolution" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedApplications" /v "publishersolution" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedApplications" /v "visiosolution" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedApplications" /v "wdsolution" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedApplications" /v "xlsolution" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedSolutionTypes" /v "agave" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedSolutionTypes" /v "appaddins" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedSolutionTypes" /v "comaddins" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedSolutionTypes" /v "documentfiles" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Policies\Microsoft\Office\16.0\OSM\PreventedSolutionTypes" /v "templatefiles" /t REG_DWORD /d 1 /f
reg add "HKLM\SYSTEM\Maps" /v "AutoUpdateEnabled" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\sensors" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\FindMyDevice" /v "AllowFindMyDevice" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Maps" /v "AllowUntriggeredNetworkTrafficOnSettingsPage" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Maps" /v "AutoDownloadAndUpdateMapData" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppCompat" /v "DisableInventory" /t REG_DWORD /d "1" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppCompat" /v "AITEnable" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppCompat" /v "DisableUAR" /t REG_DWORD /d "1" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\TabletPC" /v "PreventHandwritingDataSharing" /t REG_DWORD /d "1" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\TabletPC" /v "DoSvc" /t REG_DWORD /d "3" /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\TextInput" /v "EnablePredictionInsight" /t REG_DWORD /d "0" /f
reg add "HKCU\Software\Microsoft\Input\Settings" /v "InsightsEnabled" /t REG_DWORD /d "0" /f
reg add "HKCU\Software\Microsoft\Input\Settings" /v "InputPersonalizationTips" /t REG_DWORD /d "0" /f
reg add "HKCU\Software\Microsoft\Input\TIPC" /v "Enabled" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\WindowsInkWorkspace" /v "AllowWindowsInkWorkspace" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\PenWorkspace" /v "PenWorkspaceAppSuggestionsEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\DefaultPressure" /v "Disable" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\TextInput" /v "AllowLinguisticDataCollection" /t REG_DWORD /d "0" /f
reg add "HKCU\Software\Microsoft\Personalization\Settings" /v "AcceptedPrivacyPolicy" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors" /v "DisableLocation" /t REG_DWORD /d "1" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors" /v "DisableLocationScripting" /t REG_DWORD /d "1" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors" /v "DisableSensors" /t REG_DWORD /d "1" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors" /v "DisableWindowsLocationProvider" /t REG_DWORD /d "1" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\DeviceHealthAttestationService" /v "DisableSendGenericDriverNotFoundToWER" /t REG_DWORD /d "1" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Settings" /v "DisableSendGenericDriverNotFoundToWER" /t REG_DWORD /d "1" /f
reg add "HKLM\SYSTEM\DriverDatabase\Policies\Settings" /v "DisableSendGenericDriverNotFoundToWER" /t REG_DWORD /d "1" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v "PublishUserActivities" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v "EnableActivityFeed" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v "UploadUserActivities" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Microsoft\WindowsSelfHost\UI\Visibility" /v "DiagnosticErrorText" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Microsoft\WindowsSelfHost\UI\Strings" /v "DiagnosticErrorText" /t REG_SZ /d "" /f
reg add "HKLM\SOFTWARE\Microsoft\WindowsSelfHost\UI\Strings" /v "DiagnosticLinkText" /t REG_SZ /d "" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\SQMClient\Windows" /v "CEIPEnable" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Microsoft\SQMClient\Reliability" /v "CEIPEnable" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Microsoft\SQMClient\Reliability" /v "SqmLoggerRunning" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Microsoft\SQMClient\Windows" /v "CEIPEnable" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Microsoft\SQMClient\Windows" /v "DisableOptinExperience" /t REG_DWORD /d "1" /f
reg add "HKLM\SOFTWARE\Microsoft\SQMClient\Windows" /v "SqmLoggerRunning" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Microsoft\SQMClient\IE" /v "SqmLoggerRunning" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\HandwritingErrorReports" /v "PreventHandwritingErrorReports" /t REG_DWORD /d "1" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\FileHistory" /v "Disabled" /t REG_DWORD /d "1" /f
reg add "HKCU\SOFTWARE\Microsoft\MediaPlayer\Preferences" /v "UsageTracking" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Explorer" /v "NoUseStoreOpenWith" /t REG_DWORD /d "1" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Peernet" /v "Disabled" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Config" /v DODownloadMode /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\WiFi\AllowWiFiHotSpotReporting" /v value /t REG_DWORD /d "0" /f
reg add "HKCU\SOFTWARE\Microsoft\InputPersonalization\TrainedDataStore" /v "HarvestContacts" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\AdvertisingInfo" /v "Enabled" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\MRT" /v "DontOfferThroughWUAU" /t REG_DWORD /d "1" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Biometrics" /v "Enabled" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\dmwappushservice" /v "Start" /t REG_DWORD /d "4" /f
reg add "HKCU\Control Panel\International\User Profile" /v "HttpAcceptLanguageOptOut" /t REG_DWORD /d "1" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\AppModel" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\Cellcore" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\Circular Kernel Context Logger" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\CloudExperienceHostOobe" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DataMarket" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DefenderApiLogger" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DefenderAuditLogger" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DiagLog" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\HolographicDevice" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\iclsClient" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\iclsProxy" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\CimFSUnionFS-Filter" /v "Start" /t REG_DWORD /d 0 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\Diagtrack-Listener" /v "Start" /t REG_DWORD /d 0 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\FaceTel" /v "Start" /t REG_DWORD /d 0 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\RefSLog" /v "Start" /t REG_DWORD /d 0 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\AutoLogger-Diagtrack-Listener" /v "Start" /t REG_DWORD /d 0 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\AutoLogger-SQMLogger" /v "Start" /t REG_DWORD /d 0 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\LwtNetLog" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\Mellanox-Kernel" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\Microsoft-Windows-AssignedAccess-Trace" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\Microsoft-Windows-Setup" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\NBSMBLOGGER" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\PEAuthLog" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\RdrLog" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\ReadyBoot" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\SetupPlatform" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\SetupPlatformTel" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\SocketHeciServer" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\SpoolerLogger" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\SQMLogger" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\TCPIPLOGGER" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\TileStore" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\Tpm" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\TPMProvisioningService" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\UBPM" /v "Start" /t REG_DWORD /d "0" /f
)NVRXBAT"
R"NVRXBAT(reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\WdiContextLog" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\WFP-IPsec Trace" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\WiFiDriverIHVSession" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\WiFiDriverIHVSessionRepro" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\WiFiSession" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\WinPhoneCritical" /v "Start" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent" /v "DisableThirdPartySuggestions" /t REG_DWORD /d "1" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Lsa\Credssp" /v "DebugLogLevel" /t REG_DWORD /d "0" /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\SearchSettings" /v "IsMSACloudSearchEnabled" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\SearchSettings" /v "IsAADCloudSearchEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v "AllowCrossDeviceClipboard" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Messaging" /v "AllowMessageSync" /t REG_DWORD /d 0 /f
sc stop DiagTrack
sc config DiagTrack start= disabled
sc stop dmwappushservice
sc config dmwappushservice start= disabled
sc stop diagnosticshub.standardcollector.service
sc config diagnosticshub.standardcollector.service start= disabled
sc stop "wersvc"
sc config "wersvc" start= disabled
sc stop "wercplsupport"
sc config "wercplsupport" start= disabled
echo [Nvrx] Done: Disable Windows Telemetry
exit /b 0
)NVRXBAT";

static const char* S_priv_windows_privacy =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Windows Privacy Settings
echo [Nvrx] === Windows Privacy Settings ===
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\CloudExperienceHost\Intent\creative" /v "Intent" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\CloudExperienceHost\Intent\entertainment" /v "Intent" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\CloudExperienceHost\Intent\family" /v "Intent" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\CloudExperienceHost\Intent\gaming" /v "Intent" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\CloudExperienceHost\Intent\schoolwork" /v "Intent" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\CloudExperienceHost\Intent\business" /v "Intent" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\CloudExperienceHost\Intent\development" /v "Intent" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Policies\Microsoft\Windows\AdvertisingInfo" /v "DisabledByGroupPolicy" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent" /v "DisableConsumerAccountStateContent" /t REG_DWORD /d 1 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\activity" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\appDiagnostics" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\appointments" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\bluetoothSync" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\broadFileSystemAccess" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\cellularData" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\cellularData\Microsoft.Win32WebViewHost_cw5n1h2txyewy" /v "Value" /t REG_SZ /d "Allow" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\chat" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\contacts" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\documentsLibrary" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\email" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\gazeInput" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location\Microsoft.Win32WebViewHost_cw5n1h2txyewy" /v "Value" /t REG_SZ /d "Prompt" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\microphone" /v "Value" /t REG_SZ /d "Allow" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\microphone\Microsoft.Win32WebViewHost_cw5n1h2txyewy" /v "Value" /t REG_SZ /d "Prompt" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\phoneCall" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\phoneCallHistory" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\picturesLibrary" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\radios" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\userAccountInformation" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\userAccountInformation\Microsoft.AccountsControl_cw5n1h2txyewy" /v "Value" /t REG_SZ /d "Prompt" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\userDataTasks" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\userNotificationListener" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\videosLibrary" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\webcam" /v "Value" /t REG_SZ /d "Allow" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\webcam\Microsoft.Win32WebViewHost_cw5n1h2txyewy" /v "Value" /t REG_SZ /d "Allow" /f
echo [Nvrx] Done: Windows Privacy Settings
exit /b 0
)NVRXBAT";

static const char* S_priv_tailored =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Disable Tailored Experiences
echo [Nvrx] === Disable Tailored Experiences ===
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Privacy" /v "TailoredExperiencesWithDiagnosticDataEnabled" /t REG_DWORD /d "0" /f
echo [Nvrx] Done: Disable Tailored Experiences
exit /b 0
)NVRXBAT";

static const char* S_priv_shared =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Disable Shared Experiences
echo [Nvrx] === Disable Shared Experiences ===
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CDP" /v "CdpSessionUserAuthzPolicy" /t REG_DWORD /d "0" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CDP" /v "NearShareChannelUserAuthzPolicy" /t REG_DWORD /d "0" /f
echo [Nvrx] Done: Disable Shared Experiences
exit /b 0
)NVRXBAT";

static const char* S_priv_sync =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Disable Microsoft Setting Synchronization
echo [Nvrx] === Disable Microsoft Setting Synchronization ===
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\SettingSync" /v "DisableSyncOnPaidNetwork" /t REG_DWORD /d 1 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\settingSync" /v "SyncPolicy" /t REG_DWORD /d 5 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisablesettingSync" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisablesettingSyncUserOverride" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableAppSyncsettingSync" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableAppSyncsettingSyncUserOverride" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableApplicationsettingSync" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableApplicationsettingSyncUserOverride" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableCredentialssettingSync" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableCredentialssettingSyncUserOverride" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableDesktopThemesettingSync" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableDesktopThemesettingSyncUserOverride" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisablePersonalizationsettingSync" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisablePersonalizationsettingSyncUserOverride" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableStartLayoutsettingSync" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableStartLayoutsettingSyncUserOverride" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableWebBrowsersettingSync" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableWebBrowsersettingSyncUserOverride" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableWindowssettingSync" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\settingSync" /v "DisableWindowssettingSyncUserOverride" /t REG_DWORD /d 1 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Accessibility" /v "Enabled" /t REG_DWORD /d "0" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\AppSync" /v "Enabled" /t REG_DWORD /d "0" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\BrowserSettings" /v "Enabled" /t REG_DWORD /d "0" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Credentials" /v "Enabled" /t REG_DWORD /d "0" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\DesktopTheme" /v "Enabled" /t REG_DWORD /d "0" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Language" /v "Enabled" /t REG_DWORD /d "0" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\PackageState" /v "Enabled" /t REG_DWORD /d "0" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Personalization" /v "Enabled" /t REG_DWORD /d "0" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\StartLayout" /v "Enabled" /t REG_DWORD /d "0" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\SettingSync\Groups\Windows" /v "Enabled" /t REG_DWORD /d "0" /f
echo [Nvrx] Done: Disable Microsoft Setting Synchronization
exit /b 0
)NVRXBAT";

static const char* S_priv_insider =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Disable Windows Insider Experiments
echo [Nvrx] === Disable Windows Insider Experiments ===
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\current\device\System" /v "AllowExperimentation" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\System\AllowExperimentation" /v "value" /t REG_DWORD /d "0" /f
echo [Nvrx] Done: Disable Windows Insider Experiments
exit /b 0
)NVRXBAT";

static const char* S_priv_ads =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Disable Ads, Tips And Consumer Content
echo [Nvrx] === Disable Ads, Tips And Consumer Content ===
set "HOSTS_FILE=%WINDIR%\System32\drivers\etc\hosts"
>> "%HOSTS_FILE%" echo 0.0.0.0 arc.msn.com
>> "%HOSTS_FILE%" echo 0.0.0.0 ris.api.iris.microsoft.com
>> "%HOSTS_FILE%" echo 0.0.0.0 api.msn.com
>> "%HOSTS_FILE%" echo 0.0.0.0 assets.msn.com
>> "%HOSTS_FILE%" echo 0.0.0.0 c.msn.com
>> "%HOSTS_FILE%" echo 0.0.0.0 g.msn.com
>> "%HOSTS_FILE%" echo 0.0.0.0 ntp.msn.com
>> "%HOSTS_FILE%" echo 0.0.0.0 srtb.msn.com
>> "%HOSTS_FILE%" echo 0.0.0.0 www.msn.com
>> "%HOSTS_FILE%" echo 0.0.0.0 fd.api.iris.microsoft.com
>> "%HOSTS_FILE%" echo 0.0.0.0 staticview.msn.com
>> "%HOSTS_FILE%" echo 0.0.0.0 mucp.api.account.microsoft.com
>> "%HOSTS_FILE%" echo 0.0.0.0 query.prod.cms.rt.microsoft.com
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\AdvertisingInfo" /v "Enabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AdvertisingInfo" /v "DisabledByGroupPolicy" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338393Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-353694Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-353696Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Policies\Microsoft\Windows\Explorer" /v "DisableSearchBoxSuggestions" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Explorer" /v "DisableSearchBoxSuggestions" /t REG_DWORD /d 1 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Search" /v "DisableSearchBoxSuggestions" /t REG_DWORD /d 1 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Search" /v "BingSearchEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search" /v "DisableWebSearch" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search" /v "ConnectedSearchUseWeb" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search" /v "ConnectedSearchUseWebOverMeteredConnections" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search" /v "EnableDynamicContentInWSB" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\SearchSettings" /v "IsDynamicSearchBoxEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent" /v "DisableSoftLanding" /t REG_DWORD /d 1 /f
reg add "HKLM\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableWindowsSpotlightFeatures" /t REG_DWORD /d 1 /f
reg add "HKLM\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableWindowsConsumerFeatures" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SilentInstalledAppsEnabled" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "PreInstalledAppsEnabled" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "OemPreInstalledAppsEnabled" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SystemPaneSuggestionsEnabled" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "Start_IrisRecommendationEnabled" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "RotatingLockScreenOverlayEnabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\UserProfileEngagement" /v "ScoobeSystemSettingEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent" /v "DisableCloudOptimizedContent" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent" /v "DisableTailoredExperiencesWithDiagnosticData" /t REG_DWORD /d 1 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "ContentDeliveryAllowed" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "FeatureManagementEnabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContentEnabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "PreInstalledAppsEverEnabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SoftLandingEnabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "ShowSyncProviderNotifications" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "RotatingLockScreenEnabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-310093Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-310101Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-310102Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-314559Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-314563Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-314566Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-314567Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338380Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338381Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338382Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338386Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338387Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338388Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338389Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338394Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-353697Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-353698Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-353699Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-353702Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-353703Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-353704Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-353711Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableWindowsSpotlightWindowsWelcomeExperience" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableWindowsSpotlightOnActionCenter" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableWindowsSpotlightOnSettings" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableWindowsSpotlightFeatures" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Policies\Microsoft\Windows\CloudContent" /v "ConfigureWindowsSpotlight" /t REG_DWORD /d 2 /f
reg add "HKLM\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableWindowsSpotlightWindowsWelcomeExperience" /t REG_DWORD /d 1 /f
reg add "HKLM\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableWindowsSpotlightOnActionCenter" /t REG_DWORD /d 1 /f
reg add "HKLM\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableWindowsSpotlightOnSettings" /t REG_DWORD /d 1 /f
reg add "HKLM\Software\Policies\Microsoft\Windows\CloudContent" /v "ConfigureWindowsSpotlight" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\StorageSense" /v "AllowStorageSenseGlobal" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableThirdPartySuggestions" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableSoftLanding" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableCloudOptimizedContent" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Policies\Microsoft\Windows\CloudContent" /v "DisableWebExperience" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "SettingsPageVisibility" /t REG_SZ /d "hide:home" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-280815Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "RemediationRequired" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-202914Enabled" /t REG_DWORD /d 0 /f
echo [Nvrx] Done: Disable Ads, Tips And Consumer Content
exit /b 0
)NVRXBAT";

static const char* S_debloat_apps =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Delete Unnecessary Apps
echo [Nvrx] === Delete Unnecessary Apps ===
if not exist "C:\Nvrx\Geek\" mkdir "C:\Nvrx\Geek\"
echo Get geek.exe
curl -g -L --fail -sS --connect-timeout 20 --retry 2 --remove-on-error -o "C:\Nvrx\Geek\geek.exe" "https://www.dropbox.com/scl/fi/cijd0xgjlj52a2a0ihkr1/geek.exe?rlkey=z43asazchcrqgmz3vk2gh725x&st=s6l1wgmw&dl=1"
if exist "C:\Nvrx\Geek\geek.exe" powershell -Command "Start-Process 'C:\Nvrx\Geek\geek.exe' -Verb RunAs; Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show('Click on View and select Microsoft Store Apps, in there delete ALL apps(with leftover traces removal) that you don''t need AND PLEASE BE CAREFUL.', 'Nvrx PC Tweaking Utility - TODO', 'OK', 'Information')"
echo [Nvrx] Done: Delete Unnecessary Apps
exit /b 0
)NVRXBAT";

static const char* S_debloat_onedrive =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Delete OneDrive
echo [Nvrx] === Delete OneDrive ===
taskkill /F /IM "OneDriveStandaloneUpdater.exe" /IM "OneDriveSetup.exe" /IM "OneDrive.exe" /IM "FileCoAuth.exe" /IM "Microsoft.SharePoint.exe"
if exist "%SystemRoot%\System32\OneDriveSetup.exe" (
    start "" /wait "%SystemRoot%\System32\OneDriveSetup.exe" /uninstall
)
if exist "%SystemRoot%\SysWOW64\OneDriveSetup.exe" (
    start "" /wait "%SystemRoot%\SysWOW64\OneDriveSetup.exe" /uninstall
)
powershell -NoProfile -Command "Get-AppxPackage -AllUsers *OneDrive* | Remove-AppxPackage -AllUsers; Get-ScheduledTask -TaskPath '\' -TaskName 'OneDrive*' -ErrorAction SilentlyContinue | Unregister-ScheduledTask -Confirm:$false -ErrorAction SilentlyContinue"
sc delete OneSyncSvc
for /f "tokens=*" %%s in ('sc query ^| findstr /i "OneSyncSvc_"') do (
    for /f "tokens=2" %%a in ("%%s") do sc delete "%%a"
)
schtasks /Delete /TN "\Microsoft\Windows\OneDrive\OneDrive Standalone Update Task" /F
if exist "%~dp0oned.bat" call "%~dp0oned.bat"
del /f /q "%windir%\System32\OneDriveSetup.exe"
del /f /q "%windir%\SysWOW64\OneDriveSetup.exe"
del /f /q "%windir%\SysWOW64\OneDriveSettingSyncProvider.dll"
reg delete "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "OneDrive" /f
reg delete "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "OneDriveSetup" /f
reg delete "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" /v "{0DDD015D-B06C-45D5-8C4C-F59713854639}" /f
reg delete "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" /v "{35286A68-3C57-41A1-BBB1-0EAE73D76C95}" /f
reg delete "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" /v "{A0C69A99-21C8-4671-8703-7934162FCF1D}" /f
reg delete "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" /v "{F42EE2D3-909F-4907-8871-4C22FC0BF756}" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" /v "Desktop" /t REG_SZ /d "%%USERPROFILE%%\Desktop" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" /v "My Music" /t REG_SZ /d "%%USERPROFILE%%\Music" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" /v "My Pictures" /t REG_SZ /d "%%USERPROFILE%%\Pictures" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" /v "My Video" /t REG_SZ /d "%%USERPROFILE%%\Videos" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" /v "Personal" /t REG_SZ /d "%%USERPROFILE%%\Documents" /f
reg delete "HKCR\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}" /f
reg delete "HKCU\SOFTWARE\Microsoft\OneDrive" /f
for /f "usebackq delims=" %%a in (`dir /b /a:d "%SystemDrive%\Users"`) do (
    rmdir /q /s "%SystemDrive%\Users\%%a\AppData\Local\Microsoft\OneDrive"
    del /q /f "%SystemDrive%\Users\%%a\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\OneDrive.lnk"
    if not exist "%SystemDrive%\Users\%%a\Desktop" mkdir "%SystemDrive%\Users\%%a\Desktop"
    if not exist "%SystemDrive%\Users\%%a\Documents" mkdir "%SystemDrive%\Users\%%a\Documents"
    if not exist "%SystemDrive%\Users\%%a\Pictures" mkdir "%SystemDrive%\Users\%%a\Pictures"
    if not exist "%SystemDrive%\Users\%%a\Videos" mkdir "%SystemDrive%\Users\%%a\Videos"
    if not exist "%SystemDrive%\Users\%%a\Music" mkdir "%SystemDrive%\Users\%%a\Music"
    if exist "%SystemDrive%\Users\%%a\OneDrive\Desktop" (for /f "usebackq delims=" %%b in (`dir /b /a:-s "%SystemDrive%\Users\%%a\OneDrive\Desktop"`) do (echo No|move /-Y "%SystemDrive%\Users\%%a\OneDrive\Desktop\%%b" "%SystemDrive%\Users\%%a\Desktop"))
    if exist "%SystemDrive%\Users\%%a\OneDrive\Documents" (for /f "usebackq delims=" %%b in (`dir /b /a:-s "%SystemDrive%\Users\%%a\OneDrive\Documents"`) do (echo No|move /-Y "%SystemDrive%\Users\%%a\OneDrive\Documents\%%b" "%SystemDrive%\Users\%%a\Documents"))
    if exist "%SystemDrive%\Users\%%a\OneDrive\Pictures" (for /f "usebackq delims=" %%b in (`dir /b /a:-s "%SystemDrive%\Users\%%a\OneDrive\Pictures"`) do (echo No|move /-Y "%SystemDrive%\Users\%%a\OneDrive\Pictures\%%b" "%SystemDrive%\Users\%%a\Pictures"))
    if exist "%SystemDrive%\Users\%%a\OneDrive\Videos" (for /f "usebackq delims=" %%b in (`dir /b /a:-s "%SystemDrive%\Users\%%a\OneDrive\Videos"`) do (echo No|move /-Y "%SystemDrive%\Users\%%a\OneDrive\Videos\%%b" "%SystemDrive%\Users\%%a\Videos"))
    if exist "%SystemDrive%\Users\%%a\OneDrive\Music" (for /f "usebackq delims=" %%b in (`dir /b /a:-s "%SystemDrive%\Users\%%a\OneDrive\Music"`) do (echo No|move /-Y "%SystemDrive%\Users\%%a\OneDrive\Music\%%b" "%SystemDrive%\Users\%%a\Music"))
    if exist "%SystemDrive%\Users\%%a\OneDrive\Desktop" dir /b /a:-s "%SystemDrive%\Users\%%a\OneDrive\Desktop" | findstr /R /c:"." || rmdir /q /s "%SystemDrive%\Users\%%a\OneDrive\Desktop"

if exist "%SystemDrive%\Users\%%a\OneDrive\Documents" dir /b /a:-s "%SystemDrive%\Users\%%a\OneDrive\Documents" | findstr /R /c:"." || rmdir /q /s "%SystemDrive%\Users\%%a\OneDrive\Documents"
    if exist "%SystemDrive%\Users\%%a\OneDrive\Pictures" dir /b /a:-s "%SystemDrive%\Users\%%a\OneDrive\Pictures" | findstr /R /c:"." || rmdir /q /s "%SystemDrive%\Users\%%a\OneDrive\Pictures"
    if exist "%SystemDrive%\Users\%%a\OneDrive\Videos" dir /b /a:-s "%SystemDrive%\Users\%%a\OneDrive\Videos" | findstr /R /c:"." || rmdir /q /s "%SystemDrive%\Users\%%a\OneDrive\Videos"
    if exist "%SystemDrive%\Users\%%a\OneDrive\Music" dir /b /a:-s "%SystemDrive%\Users\%%a\OneDrive\Music" | findstr /R /c:"." || rmdir /q /s "%SystemDrive%\Users\%%a\OneDrive\Music"
    del /q /f "%SystemDrive%\Users\%%a\OneDrive\Personal Vault.lnk"
    for /f "usebackq delims=" %%b in (`dir /b /a:-s "%SystemDrive%\Users\%%a\OneDrive" ^| findstr /V /X /c:"Desktop" /c:"Documents" /c:"Pictures" /c:"Videos" /c:"Music"`) do (
        if not exist "%SystemDrive%\Users\%%a\Desktop\OneDriveFiles" mkdir "%SystemDrive%\Users\%%a\Desktop\OneDriveFiles"
        echo No|move /-Y "%SystemDrive%\Users\%%a\OneDrive\%%b" "%SystemDrive%\Users\%%a\Desktop\OneDriveFiles"
    )
    dir /b /a:-s "%SystemDrive%\Users\%%a\OneDrive" | findstr /R /c:"." || rmdir /q /s "%SystemDrive%\Users\%%a\OneDrive"
)
robocopy "%USERPROFILE%\OneDrive" "%USERPROFILE%" /mov /e /xj /ndl /nfl /njh /njs /nc /ns /np
rd /s /q "%USERPROFILE%\OneDrive"
rd /s /q "%LOCALAPPDATA%\OneDrive"
rd /s /q "%LOCALAPPDATA%\Microsoft\OneDrive"
rd /s /q "%ProgramData%\Microsoft OneDrive"
rd /s /q "%SystemDrive%\OneDriveTemp"
del /f /q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\OneDrive.lnk"
for /f "usebackq delims=" %%e in (`reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\SyncRootManager" ^| findstr /i /c:"OneDrive"`) do reg delete "%%e" /f
reg add "HKU\.DEFAULT\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce" /v "HideOneDriveExplorer" /t REG_SZ /d "reg add HKCU\Software\Classes\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6} /v System.IsPinnedToNameSpaceTree /t REG_DWORD /d 0 /f" /f
reg add "HKU\.DEFAULT\Software\Classes\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}" /v "System.IsPinnedToNameSpaceTree" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\OneDrive" /v "DisableFileSyncNGSC" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\OneDrive" /v "KFMBlockOptIn" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\OneDrive" /v "DisableFileSync" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\OneDrive" /v "DisableFileSyncNGSC" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\OneDrive" /v "DisablePersonalSync" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\OneDrive" /v "DisableLibrariesDefaultSaveToOneDrive" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\OneDrive" /v "PreventOneDriveInstalls" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\OneDrive" /v "DisableNetworkFileSync" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\OneDrive" /v "DisableMeteredNetworkFileSync" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\OneDrive" /v "PreventNetworkTrafficPreUserSignIn" /t REG_DWORD /d 1 /f
for /f "delims=" %%K in ('reg query "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Desktop\NameSpace" 2^>nul') do reg query "%%K" /ve 2>nul | findstr /i /c:"OneDrive" >nul && reg delete "%%K" /f
reg add "HKCU\Software\Classes\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}" /v "System.IsPinnedToNameSpaceTree" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Classes\Wow6432Node\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}" /v "System.IsPinnedToNameSpaceTree" /t REG_DWORD /d 0 /f
del /f /q "%USERPROFILE%\Links\OneDrive.lnk"
del /f /q "%SystemRoot%\ServiceProfiles\LocalService\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\OneDrive.lnk"
del /f /q "%SystemRoot%\ServiceProfiles\NetworkService\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\OneDrive.lnk"
reg delete "HKCU\Environment" /v "OneDrive" /f
reg load HKU\Default "C:\Users\Default\NTUSER.DAT"
reg delete "HKU\Default\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v OneDriveSetup /f
reg unload HKU\Default
rd /s /q "%ProgramFiles%\Microsoft OneDrive"
rd /s /q "%ProgramFiles(x86)%\Microsoft OneDrive"
echo [Nvrx] Done: Delete OneDrive
exit /b 0
)NVRXBAT";

static const char* S_debloat_outlook =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Delete New Outlook For Windows
echo [Nvrx] === Delete New Outlook For Windows ===
powershell -NoProfile -Command "Get-AppxPackage -AllUsers 'Microsoft.OutlookForWindows' | Remove-AppxPackage -AllUsers"
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Appx\AppxAllUserStore\Deprovisioned\Microsoft.OutlookForWindows_8wekyb3d8bbwe" /f
reg add "HKCU\Software\Microsoft\Office\16.0\Outlook\Options\General" /v "DoNewOutlookAutoMigration" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Policies\Microsoft\office\16.0\outlook\preferences" /v "NewOutlookMigrationUserSetting" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Office\16.0\Outlook\Preferences" /v "UseNewOutlook" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Office\16.0\Outlook\Options\General" /v "HideNewOutlookToggle" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Policies\Microsoft\Office\16.0\Outlook\Options" /v "HideNewOutlookToggle" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Microsoft\Office\16.0\Outlook\Options\General" /v "DisablePreviewPlace" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Microsoft\Office\16.0\Outlook\Preferences" /v "EnablePreviewPlace" /t REG_DWORD /d 0 /f
reg delete "HKLM\SOFTWARE\Microsoft\WindowsUpdate\Orchestrator\UScheduler_Oobe\OutlookUpdate" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Orchestrator\UScheduler\OutlookUpdate" /v "workCompleted" /t REG_DWORD /d 1 /f
powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand JABSAD0AWwBNAGkAYwByAG8AcwBvAGYAdAAuAFcAaQBuADMAMgAuAFIAZQBnAGkAcwB0AHIAeQBdADsAIABmAHUAbgBjAHQAaQBvAG4AIABTADIAKAAkAHIALAAkAHAALAAkAG4ALAAkAHYAKQB7ACAAJAB4AD0AJABuAHUAbABsADsAIAB0AHIAeQB7ACAAJAB4AD0AJAByAC4ATwBwAGUAbgBTAHUAYgBLAGUAeQAoACQAcAAsACQAdAByAHUAZQApACAAfQBjAGEAdABjAGgAewB9ADsAIABpAGYAKAAhACQAeAApAHsAIAB0AHIAeQB7ACAAJAB4AD0AJAByAC4AQwByAGUAYQB0AGUAUwB1AGIASwBlAHkAKAAkAHAAKQAgAH0AYwBhAHQAYwBoAHsAfQAgAH0AOwAgAGkAZgAoACQAeAApAHsAIAB0AHIAeQB7ACAAJAB4AC4AUwBlAHQAVgBhAGwAdQBlACgAJABuACwAJAB2ACwAJwBTAHQAcgBpAG4AZwAnACkAIAB9AGMAYQB0AGMAaAB7AH0AOwAgACQAeAAuAEMAbABvAHMAZQAoACkAIAB9ACAAfQA7ACAAUwAyACAAJABSADoAOgBMAG8AYwBhAGwATQBhAGMAaABpAG4AZQAgACcAUwBPAEYAVABXAEEAUgBFAFwATQBpAGMAcgBvAHMAbwBmAHQAXABXAGkAbgBkAG8AdwBzAFUAcABkAGEAdABlAFwATwByAGMAaABlAHMAdAByAGEAdABvAHIAXABVAFMAYwBoAGUAZAB1AGwAZQByAF8ATwBvAGIAZQAnACAAJwBCAGwAbwBjAGsAZQBkAE8AbwBiAGUAVQBwAGQAYQB0AGUAcgBzACcAIAAnAFsAIgBNAFMAXwBPAHUAdABsAG8AbwBrACIAXQAnAA==
echo [Nvrx] Done: Delete New Outlook For Windows
exit /b 0
)NVRXBAT";

static const char* S_debloat_ai =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Remove Windows AI
echo [Nvrx] === Remove Windows AI ===
set "HOSTS_FILE=%WINDIR%\System32\drivers\etc\hosts"
>> "%HOSTS_FILE%" echo 0.0.0.0 business.bing.com
>> "%HOSTS_FILE%" echo 0.0.0.0 c.bing.com
>> "%HOSTS_FILE%" echo 0.0.0.0 th.bing.com
>> "%HOSTS_FILE%" echo 0.0.0.0 edgeassetservice.azureedge.net
>> "%HOSTS_FILE%" echo 0.0.0.0 c-ring.msedge.net
>> "%HOSTS_FILE%" echo 0.0.0.0 fp.msedge.net
>> "%HOSTS_FILE%" echo 0.0.0.0 l-ring.msedge.net
>> "%HOSTS_FILE%" echo 0.0.0.0 s-ring.msedge.net
>> "%HOSTS_FILE%" echo 0.0.0.0 dual-s-ring.msedge.net
>> "%HOSTS_FILE%" echo 0.0.0.0 creativecdn.com
>> "%HOSTS_FILE%" echo 0.0.0.0 a-ring-fallback.msedge.net
>> "%HOSTS_FILE%" echo 0.0.0.0 fp-afd-nocache-ccp.azureedge.net
>> "%HOSTS_FILE%" echo 0.0.0.0 prod-azurecdn-akamai-iris.azureedge.net
>> "%HOSTS_FILE%" echo 0.0.0.0 widgetcdn.azureedge.net
>> "%HOSTS_FILE%" echo 0.0.0.0 widgetservice.azurefd.net
>> "%HOSTS_FILE%" echo 0.0.0.0 fp-vs.azureedge.net
>> "%HOSTS_FILE%" echo 0.0.0.0 ln-ring.msedge.net
>> "%HOSTS_FILE%" echo 0.0.0.0 t-ring.msedge.net
>> "%HOSTS_FILE%" echo 0.0.0.0 t-ring-fdv2.msedge.net
>> "%HOSTS_FILE%" echo 0.0.0.0 tse1.mm.bing.net
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "AllowRecallEnablement" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "DisableAIDataAnalysis" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "DisableClickToDo" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Paint" /v "DisableCocreator" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Paint" /v "DisableGenerativeFill" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Paint" /v "DisableImageCreator" /t REG_DWORD /d 1 /f
taskkill /F /IM "ai.exe" /IM "Copilot.exe" /IM "aihost.exe" /IM "aicontext.exe" /IM "ClickToDo.exe" /IM "aixhost.exe" /IM "WorkloadsSessionHost.exe"
sc stop WSAIFabricSvc
sc config WSAIFabricSvc start= disabled
dism /Online /Disable-Feature /NoRestart /FeatureName:Recall /Quiet
powershell -NoProfile -ExecutionPolicy Bypass -Command "$packages = @('Microsoft.549981C3F5F10', 'Microsoft.Windows.Ai.Copilot.Provider', 'Microsoft.Copilot', 'Microsoft.WindowsAiFoundation', 'Microsoft.Windows.Recall', 'MicrosoftWindows.Client.AIX', 'Microsoft.Windows.Copilot', 'Client.CoPilot', 'Ai.Copilot', 'Client.CoreAI'); foreach ($pkg in $packages) { Get-AppxPackage -Name \"*$pkg*\" -AllUsers | Remove-AppxPackage -AllUsers -ErrorAction SilentlyContinue; Get-AppxProvisionedPackage -Online | Where-Object {$_.DisplayName -like \"*$pkg*\"} | Remove-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue; }; $recallTasks = @('\Microsoft\Windows\WindowsAI\*', '\Microsoft\Windows\Recall\*'); foreach ($taskPath in $recallTasks) { Get-ScheduledTask -TaskPath $taskPath -ErrorAction SilentlyContinue | Unregister-ScheduledTask -Confirm:$false -ErrorAction SilentlyContinue; }"
schtasks /delete /tn "\Microsoft\Windows\WindowsAI\Recall" /f
schtasks /delete /tn "\Microsoft\Windows\WindowsAI\Settings" /f
schtasks /delete /tn "\Microsoft\Windows\WindowsAI" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot" /v "TurnOffWindowsCopilot" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "TurnOffSavingSnapshots" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "DisableSettingsAgent" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "DisableAgentConnectors" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "AllowModelSharing" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "DisableRemoteAgentConnectors" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "DisableAgentWorkspaces" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\Shell\Copilot\BingChat" /v "IsUserEligible" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\Shell\Copilot" /v "IsCopilotAvailable" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\Shell\Copilot" /v "CopilotDisabledReason" /t REG_SZ /d "FeatureIsDisabled" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked" /v "{CB3B0003-8088-4EDE-8769-8B354AB2FF8C}" /t REG_SZ /d " " /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search" /v "CortanaConsent" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v CopilotPageAction /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "EdgeEntraCopilotPageContext" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "Microsoft365CopilotChatIconEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "EdgeHistoryAISearchEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "ComposeInlineEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v "GenAILocalFoundationalModelSettings" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Paint" /v "DisableGenerativeErase" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Paint" /v "DisableRemoveBackground" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\WindowsNotepad" /v "DisableAIFeatures" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\WindowsNotepad" /v "DisableWritingTools" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsAccessGenerativeAI" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsAccessSystemAIModels" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsAccessAI" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsAccessTextAndImageGeneration" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsAccessGazeInput" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsAccessHumanPresence" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsAccessSpatialPerception" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy" /v "LetAppsSyncWithDevices" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\systemAIModels" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\systemAIModels" /v "RecordUsageData" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\generativeAI" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\gazeInput" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\humanPresence" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\spatialPerception" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\backgroundSpatialPerception" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKCU\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot" /v "TurnOffWindowsCopilot" /t REG_DWORD /d 1 /f
reg add "HKCU\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "DisableAIDataAnalysis" /t REG_DWORD /d 1 /f
reg add "HKCU\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "AllowRecallEnablement" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "DisableClickToDo" /t REG_DWORD /d 1 /f
reg add "HKCU\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "TurnOffSavingSnapshots" /t REG_DWORD /d 1 /f
reg add "HKCU\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "DisableSettingsAgent" /t REG_DWORD /d 1 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\Shell\Copilot\BingChat" /v "IsUserEligible" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\Shell\Copilot" /v "IsCopilotAvailable" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\Shell\Copilot" /v "CopilotDisabledReason" /t REG_SZ /d "FeatureIsDisabled" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "ShowCopilotButton" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Notifications\Settings" /v "AutoOpenCopilotLargeScreens" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsCopilot" /v "AllowCopilotRuntime" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Notepad" /v "ShowRewriteButton" /t REG_DWORD /d 0 /f
reg add "HKU\.DEFAULT\Software\Policies\Microsoft\Windows\WindowsAI" /v "DisableClickToDo" /t REG_DWORD /d 1 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\systemAIModels" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\generativeAI" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\humanPresence" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\spatialPerception" /v "Value" /t REG_SZ /d "Deny" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\backgroundSpatialPerception" /v "Value" /t REG_SZ /d "Deny" /f
reg delete "HKCR\ms-office-ai" /f
reg delete "HKCR\ms-copilot" /f
reg delete "HKCR\ms-clicktodo" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsAI" /v "RemoveMicrosoftCopilotApp" /t REG_DWORD /d 1 /f
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Recall" /f
echo [Nvrx] Done: Remove Windows AI
exit /b 0
)NVRXBAT";

static const char* S_debloat_startup =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Disable Startup Apps
echo [Nvrx] === Disable Startup Apps ===
if not exist "C:\Nvrx\Autoruns\" mkdir "C:\Nvrx\Autoruns\"
echo [Nvrx] Get Autoruns.exe
curl -g -L --fail -sS --connect-timeout 20 --retry 2 --remove-on-error -o "C:\Nvrx\Autoruns\Autoruns.exe" "https://www.dropbox.com/scl/fi/x4xwackwfn191pv2lc6xf/Autoruns.exe?rlkey=ettzx61n86in4e3tbe63rmtal&st=xzycli9q&dl=1"
if exist "C:\Nvrx\Autoruns\Autoruns.exe" powershell -Command "Start-Process 'C:\Nvrx\Autoruns\Autoruns.exe' -Verb RunAs; Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show('In there disable all unwanted stuff except: antivirus, cmd.exe, and the n/a services.', 'Nvrx PC Tweaking Utility - TODO', 'OK', 'Information')"
echo [Nvrx] Done: Disable Startup Apps
exit /b 0
)NVRXBAT";

static const char* S_debloat_services =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Disable Unneeded Services
echo [Nvrx] === Disable Unneeded Services ===
reg add "HKLM\SYSTEM\CurrentControlSet\Control" /v SvcHostSplitThresholdInKB /t REG_DWORD /d 4294967295 /f
sc config "AppMgmt" start= disabled
sc config "Backupper Service" start= disabled
sc config "BDESVC" start= disabled
sc config "Browser" start= disabled
sc config "CloudBackupRestoreSvc" start= disabled
sc config "CloudIdSvc" start= disabled
sc config "DataUsageSvc" start= disabled
sc config "DialogBlockingService" start= disabled
sc config "dLauncherLoopback" start= disabled
sc config "DmEnrollmentSvc" start= disabled
sc config "DsSvc" start= disabled
sc config "edgeupdate" start= disabled
sc config "edgeupdatem" start= disabled
sc config "embeddedmode" start= disabled
sc config "EventSystem" start= demand
sc config "Fax" start= disabled
sc config "lfsvc" start= disabled
sc config "MapsBroker" start= disabled
sc config "MessagingService_5f1ad" start= disabled
sc config "MicrosoftEdgeElevationService" start= disabled
sc config "MicrosoftEdgeUpdateService" start= disabled
sc config "MicrosoftEdgeUpdateServicem" start= disabled
sc config "MixedRealityOpenXRSvc" start= disabled
sc config "MsKeyboardFilter" start= disabled
sc config "NPSMSvc" start= disabled
sc config "OneSyncSvc" start= disabled
sc config "OneSyncSvc_5f1ad" start= disabled
sc config "perceptionsimulation" start= disabled
sc config "PhoneSvc" start= disabled
sc config "PimIndexMaintenanceSvc_5f1ad" start= disabled
sc config "pla" start= disabled
sc config "RetailDemo" start= disabled
sc config "SCardSvr" start= disabled
sc config "ScDeviceEnum" start= disabled
sc config "scfilter" start= disabled
sc config "SCPolicySvc" start= disabled
sc config "SEMgrSvc" start= disabled
sc config "SensorDataService" start= disabled
sc config "SensorMonitoringService" start= disabled
sc config "SensorService" start= disabled
sc config "SensrSvc" start= disabled
sc config "SharedRealitySvc" start= disabled
sc config "shpamsvc" start= disabled
sc config "SNMPTRAP" start= disabled
sc config "SysMain" start= disabled
sc config "TabletInputService" start= disabled
sc config "TapiSrv" start= disabled
sc config "TroubleshootingSvc" start= disabled
sc config "UevAgentService" start= disabled
sc config "WalletService" start= disabled
sc config "WbioSrvc" start= disabled
sc config "WdiServiceHost" start= disabled
sc config "WdiSystemHost" start= disabled
sc config "WebClient" start= disabled
sc config "Wecsvc" start= disabled
sc config "wisvc" start= disabled
sc config "wlidsvc" start= disabled
sc config "WManSvc" start= disabled
sc config "wmiApSrv" start= disabled
sc config "WMPNetworkSvc" start= disabled
sc config "WpcMonSvc" start= disabled
sc config "WPDBusEnum" start= disabled
schtasks /Change /TN "Microsoft\Windows\Device Information\Device User" /Disable
schtasks /Change /TN "Microsoft\Windows\Diagnosis\RecommendedTroubleshootingScanner" /Disable
schtasks /Change /TN "Microsoft\Windows\Diagnosis\Scheduled" /Disable
schtasks /Change /TN "Microsoft\Windows\EnterpriseMgmt\MDMMaintenenceTask" /Disable
schtasks /Change /TN "Microsoft\Windows\Feedback\Siuf\DmClient" /Disable
schtasks /Change /TN "Microsoft\Windows\Feedback\Siuf\DmClientOnScenarioDownload" /Disable
schtasks /Change /TN "Microsoft\Windows\Flighting\FeatureConfig\UsageDataFlushing" /Disable
schtasks /Change /TN "Microsoft\Windows\Flighting\FeatureConfig\UsageDataReporting" /Disable
schtasks /Change /TN "Microsoft\Windows\Flighting\OneSettings\RefreshCache" /Disable
schtasks /Change /TN "Microsoft\Windows\Input\LocalUserSyncDataAvailable" /Disable
schtasks /Change /TN "Microsoft\Windows\Input\MouseSyncDataAvailable" /Disable
schtasks /Change /TN "Microsoft\Windows\Input\PenSyncDataAvailable" /Disable
schtasks /Change /TN "Microsoft\Windows\Input\TouchpadSyncDataAvailable" /Disable
schtasks /Change /TN "Microsoft\Windows\Management\Provisioning\Cellular" /Disable
schtasks /Change /TN "Microsoft\Windows\Management\Provisioning\Logon" /Disable
schtasks /Change /TN "Microsoft\Windows\Maps\MapsToastTask" /Disable
schtasks /Change /TN "Microsoft\Windows\Maps\MapsUpdateTask" /Disable
schtasks /Change /TN "Microsoft\Windows\RemoteAssistance\RemoteAssistanceTask" /Disable
schtasks /Change /TN "Microsoft\Windows\RetailDemo\CleanupOfflineContent" /Disable
schtasks /Change /TN "Microsoft\Windows\Speech\SpeechModelDownloadTask" /Disable
schtasks /Change /TN "Microsoft\Windows\Sysmain\ResPriStaticDbSync" /Disable
schtasks /Change /TN "Microsoft\Windows\Sysmain\WsSwapAssessmentTask" /Disable
schtasks /Change /TN "Microsoft\Windows\Task Manager\Interactive" /Disable
schtasks /Change /TN "Microsoft\Windows\User Profile Service\HiveUploadTask" /Disable
schtasks /Change /TN "Microsoft\Windows\Work Folders\Work Folders Logon Synchronization" /Disable
schtasks /Change /TN "Microsoft\Windows\Work Folders\Work Folders Maintenance Work" /Disable
schtasks /Change /TN "Microsoft\Windows\Workplace Join\Automatic-Device-Join" /Disable
echo [Nvrx] Done: Disable Unneeded Services
exit /b 0
)NVRXBAT";

static const char* S_app_chrome =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Debloat Google Chrome
echo [Nvrx] === Debloat Google Chrome ===
taskkill /F /IM chrome.exe
set "HOSTS_FILE=%WINDIR%\System32\drivers\etc\hosts"
>> "%HOSTS_FILE%" echo 0.0.0.0 adservice.google.com
>> "%HOSTS_FILE%" echo 0.0.0.0 adservice.google.pl
>> "%HOSTS_FILE%" echo 0.0.0.0 pagead2.googlesyndication.com
>> "%HOSTS_FILE%" echo 0.0.0.0 ssl.google-analytics.com
>> "%HOSTS_FILE%" echo 0.0.0.0 stats.g.doubleclick.net
>> "%HOSTS_FILE%" echo 0.0.0.0 www.google-analytics.com
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v MetricsReportingEnabled /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v DeviceMetricsReportingEnabled /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v UserFeedbackAllowed /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v BackgroundModeEnabled /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v PromotionalTabsEnabled /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v ShowRecommendationsEnabled /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v NetworkPredictionOptions /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v ChromeCleanupEnabled /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v ChromeCleanupReportingEnabled /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v SafeBrowsingProtectionLevel /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v EnableMediaRouter /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v ShowCastIconInToolbar /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v SafeBrowsingExtendedReportingEnabled /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v DefaultPopupsSetting /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v DefaultSensorsSetting /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v DefaultSerialGuardSetting /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v DefaultWebBluetoothGuardSetting /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Google\Chrome" /v DefaultWebUsbGuardSetting /t REG_DWORD /d 2 /f
set "CHROME_USER=%LOCALAPPDATA%\Google\Chrome\User Data"
if exist "%CHROME_USER%" (
    for /d %%P in ("%CHROME_USER%\*") do (
        if exist "%%P\Cache" rd /s /q "%%P\Cache"
        if exist "%%P\Code Cache" rd /s /q "%%P\Code Cache"
        if exist "%%P\GPUCache" rd /s /q "%%P\GPUCache"
    )
)
echo [Nvrx] Done: Debloat Google Chrome
exit /b 0
)NVRXBAT";

static const char* S_app_brave =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Debloat Brave
echo [Nvrx] === Debloat Brave ===
taskkill /F /IM brave.exe
set "HOSTS_FILE=%WINDIR%\System32\drivers\etc\hosts"
>> "%HOSTS_FILE%" echo 0.0.0.0 p2a-json.brave.com
>> "%HOSTS_FILE%" echo 0.0.0.0 p2a.brave.com
>> "%HOSTS_FILE%" echo 0.0.0.0 p3a-json.brave.com
>> "%HOSTS_FILE%" echo 0.0.0.0 p3a.brave.com
>> "%HOSTS_FILE%" echo 0.0.0.0 star-randsrv.bsg.brave.com
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BraveVPNDisabled" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BraveWalletDisabled" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BraveAIChatEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BraveRewardsDisabled" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BraveTalkDisabled" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BraveNewsDisabled" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BraveLabsEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "BraveSidebarEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "MetricsReportingEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "SafeBrowsingExtendedReportingEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\Software\Policies\BraveSoftware\Brave" /v "NewTabPageShowBackgroundImage" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\BraveSoftware\Brave" /v "NewTabPageShowSponsoredImages" /t REG_DWORD /d 0 /f
set "BRAVE_USER=%LOCALAPPDATA%\BraveSoftware\Brave-Browser\User Data"
if exist "%BRAVE_USER%" (
    for /d %%P in ("%BRAVE_USER%\*") do (
        if exist "%%P\Cache" rd /s /q "%%P\Cache"
        if exist "%%P\Code Cache" rd /s /q "%%P\Code Cache"
        if exist "%%P\GPUCache" rd /s /q "%%P\GPUCache"
    )
)
echo [Nvrx] Done: Debloat Brave
exit /b 0
)NVRXBAT";

static const char* S_app_edge =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Debloat Microsoft Edge
echo [Nvrx] === Debloat Microsoft Edge ===
taskkill /F /IM msedge.exe
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v EdgeEnhanceImagesEnabled /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v PersonalizationReportingEnabled /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v MetricsReportingEnabled /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v DiagnosticData /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v HubsSidebarEnabled /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v EdgeShoppingAssistantEnabled /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v SearchSuggestEnabled /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v WebWidgetAllowed /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v SyncDisabled /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v BrowserSignin /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v SendSiteInfoToImproveServices /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v AlternateErrorPagesEnabled /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v HideFirstRunExperience /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v BackgroundModeEnabled /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v ShowRecommendationsEnabled /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v SpotlightExperiencesAndRecommendationsEnabled /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v PromotionalTabsEnabled /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v NewTabPageHideDefaultTopSites /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v ShowMicrosoftRewards /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v MicrosoftEdgeInsiderPromotionEnabled /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v StartupBoostEnabled /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v EdgeAssetDeliveryServiceEnabled /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v UserFeedbackAllowed /t REG_DWORD /d 0 /f
set "EDGE_USER=%LOCALAPPDATA%\Microsoft\Edge\User Data"
if exist "%EDGE_USER%" (
    for /d %%P in ("%EDGE_USER%\*") do (
        if exist "%%P\Cache" rd /s /q "%%P\Cache"
        if exist "%%P\Code Cache" rd /s /q "%%P\Code Cache"
        if exist "%%P\GPUCache" rd /s /q "%%P\GPUCache"
    )
)
echo [Nvrx] Done: Debloat Microsoft Edge
exit /b 0
)NVRXBAT";

static const char* S_app_firefox =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Debloat Mozilla Firefox
echo [Nvrx] === Debloat Mozilla Firefox ===
set "HOSTS_FILE=%WINDIR%\System32\drivers\etc\hosts"
>> "%HOSTS_FILE%" echo 0.0.0.0 incoming.telemetry.mozilla.org
>> "%HOSTS_FILE%" echo 0.0.0.0 telemetry.mozilla.org
del /f /s /q "%APPDATA%\Mozilla\Firefox\Profiles\*.default\cache2\*.*"
reg add "HKLM\SOFTWARE\Policies\Mozilla\Firefox" /v "DisableTelemetry" /t REG_DWORD /d "1" /f
reg add "HKLM\SOFTWARE\Policies\Mozilla\Firefox" /v "DisableFirefoxStudies" /t REG_DWORD /d "1" /f
reg add "HKLM\SOFTWARE\Policies\Mozilla\Firefox" /v "PocketEnabled" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Policies\Mozilla\Firefox" /v "DisableDefaultBrowserAgent" /t REG_DWORD /d "1" /f
del "C:\Program Files\Mozilla Firefox\minidump-analyzer.exe" /f /q
del "C:\Program Files\Mozilla Firefox\pingsender.exe" /f /q
cd /d "C:\Program Files\Mozilla Firefox"
del /f install.log
del /f minidump*.*
echo [Nvrx] Done: Debloat Mozilla Firefox
exit /b 0
)NVRXBAT";

static const char* S_app_discord =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Debloat Discord
echo [Nvrx] === Debloat Discord ===
taskkill /IM Discord.exe /F
taskkill /IM DiscordPTB.exe /F
taskkill /IM DiscordCanary.exe /F
taskkill /IM DiscordOverlayHost.exe /F
taskkill /IM DiscordGameDetector.exe /F
taskkill /IM Update.exe /F
set "DISC_APPDATA=%APPDATA%\discord"
set "DISC_LOCAL=%LOCALAPPDATA%\Discord"
for %%D in (
    Cache
    GPUCache
    DawnCache
    Code Cache
    logs
    Crashpad
    blob_storage
    Temp
    Service Worker
) do (
    if exist "%DISC_APPDATA%\%%D" rmdir /s /q "%DISC_APPDATA%\%%D"
    if exist "%DISC_LOCAL%\%%D" rmdir /s /q "%DISC_LOCAL%\%%D"
)
del /f /q "%DISC_APPDATA%\*.log"
del /f /q "%DISC_LOCAL%\*.log"
if exist "%LOCALAPPDATA%\SquirrelTemp" rmdir /s /q "%LOCALAPPDATA%\SquirrelTemp"
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v Discord /f
reg add "HKCU\Software\Discord" /v "TelemetryEnabled" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Discord" /v "EnableTelemetry" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Discord" /v "CrashReportingEnabled" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Discord" /v "EnableAnimations" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Discord" /v "EnableRichPresence" /t REG_DWORD /d 0 /f
if exist "%APPDATA%\discord\settings.json" (
    powershell -NoProfile -Command "$p='%APPDATA%\discord\settings.json'; $j=Get-Content -LiteralPath $p -Raw | ConvertFrom-Json; if(-not $j.PSObject.Properties['settings']){$j | Add-Member -NotePropertyName settings -NotePropertyValue ([pscustomobject]@{})}; if(-not $j.settings.PSObject.Properties['overlay']){$j.settings | Add-Member -NotePropertyName overlay -NotePropertyValue ([pscustomobject]@{})}; $j.settings.overlay | Add-Member -NotePropertyName enabled -NotePropertyValue $false -Force; $j | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $p -Encoding UTF8"
)
echo [Nvrx] Done: Debloat Discord
exit /b 0
)NVRXBAT";

static const char* S_app_tiktok =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Debloat Tiktok LIVE Studio
echo [Nvrx] === Debloat Tiktok LIVE Studio ===
taskkill /IM "TikTok LIVE Studio.exe" /F
rmdir /s /q "%APPDATA%\TikTok LIVE Studio\Cache"
rmdir /s /q "%APPDATA%\TikTok LIVE Studio\GPUCache"
rmdir /s /q "%APPDATA%\TikTok LIVE Studio\Code Cache"
rmdir /s /q "%LOCALAPPDATA%\TikTok LIVE Studio\Cache"
rmdir /s /q "%LOCALAPPDATA%\TikTok LIVE Studio\Temp"
reg add "HKCU\Software\TikTok LIVE Studio" /v TelemetryEnabled /t REG_DWORD /d 0 /f
reg add "HKCU\Software\TikTok LIVE Studio" /v CrashHandlerEnabled /t REG_DWORD /d 0 /f
reg add "HKCU\Software\TikTok LIVE Studio" /v SendUsageStats /t REG_DWORD /d 0 /f
reg add "HKCU\Software\TikTok LIVE Studio" /v AutoUpdate /t REG_DWORD /d 0 /f
echo [Nvrx] Done: Debloat Tiktok LIVE Studio
exit /b 0
)NVRXBAT";

static const char* S_sec_hardening =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Make Your System more Secure
echo [Nvrx] === Make Your System more Secure ===
powershell -NoProfile -ExecutionPolicy Bypass -Command "Disable-WindowsOptionalFeature -Online -FeatureName MicrosoftWindowsPowerShellV2,MicrosoftWindowsPowerShellV2Root,WCF-TCP-PortSharing45,SmbDirect,TFTP -NoRestart; Get-WindowsCapability -Online -Name 'RasCMAK.Client*','RIP.Listener*','SNMP.Client*','WMI-SNMP-Provider.Client*' | Remove-WindowsCapability -Online; Disable-WindowsOptionalFeature -Online -FeatureName SMB1Protocol -NoRestart -EA SilentlyContinue"
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager" /v "DisableWpbtExecution" /t REG_DWORD /d 1 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\BitLocker" /v "PreventDeviceEncryption" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "NoDriveTypeAutoRun" /t REG_DWORD /d 255 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "NoAutorun" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Explorer" /v "NoAutoplayfornonVolume" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WinRM\Client" /v "AllowBasic" /t REG_DWORD /d 0 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Lsa" /v "restrictanonymoussam" /t REG_DWORD /d 1 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\LanManServer\Parameters" /v "restrictnullsessaccess" /t REG_DWORD /d 1 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\LSA" /v "restrictanonymous" /t REG_DWORD /d 1 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Remote Assistance" /v "fAllowToGetHelp" /t REG_DWORD /d 0 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Remote Assistance" /v "fAllowFullControl" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" /v "AllowBasic" /t REG_DWORD /d 0 /f
reg add "HKLM\System\CurrentControlSet\Services\LanManServer\Parameters" /v "DisableCompression" /t REG_DWORD /d "1" /f
powershell -NoProfile -Command "Set-SmbClientConfiguration -EnableInsecureGuestLogons:$false -Force"
set "S=HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL"
set "BUILD=0"
for /f "tokens=3" %%i in ('reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v CurrentBuildNumber 2^>nul ^| find "CurrentBuildNumber"') do set "BUILD=%%i"
reg add "%S%\KeyExchangeAlgorithms\Diffie-Hellman" /v "ServerMinKeyBitLength" /t REG_DWORD /d 2048 /f
reg add "%S%\KeyExchangeAlgorithms\Diffie-Hellman" /v "ClientMinKeyBitLength" /t REG_DWORD /d 2048 /f
reg add "%S%" /v "AllowInsecureRenegoClients" /t REG_DWORD /d 0 /f
reg add "%S%" /v "AllowInsecureRenegoServers" /t REG_DWORD /d 0 /f
reg add "%S%" /v "DisableRenegoOnServer" /t REG_DWORD /d 0 /f
reg add "%S%" /v "DisableRenegoOnClient" /t REG_DWORD /d 0 /f
reg add "%S%" /v "UseScsvForTls" /t REG_DWORD /d 1 /f
reg add "%S%\Ciphers\RC2 40/128" /v "Enabled" /t REG_DWORD /d 0 /f
reg add "%S%\Ciphers\RC2 56/128" /v "Enabled" /t REG_DWORD /d 0 /f
reg add "%S%\Ciphers\RC2 128/128" /v "Enabled" /t REG_DWORD /d 0 /f
reg add "%S%\Ciphers\RC4 128/128" /v "Enabled" /t REG_DWORD /d 0 /f
reg add "%S%\Ciphers\RC4 64/128" /v "Enabled" /t REG_DWORD /d 0 /f
reg add "%S%\Ciphers\RC4 56/128" /v "Enabled" /t REG_DWORD /d 0 /f
reg add "%S%\Ciphers\RC4 40/128" /v "Enabled" /t REG_DWORD /d 0 /f
reg add "%S%\Ciphers\DES 56/56" /v "Enabled" /t REG_DWORD /d 0 /f
reg add "%S%\Ciphers\NULL" /v "Enabled" /t REG_DWORD /d 0 /f
reg delete "%S%\Ciphers\Triple DES 168" /v "Enabled" /f
reg delete "%S%\Ciphers\Triple DES 168/168" /v "Enabled" /f
reg add "%S%\Protocols\SSL 2.0\Server" /v "Enabled" /t REG_DWORD /d 0 /f
reg add "%S%\Protocols\SSL 2.0\Server" /v "DisabledByDefault" /t REG_DWORD /d 1 /f
reg add "%S%\Protocols\SSL 2.0\Client" /v "Enabled" /t REG_DWORD /d 0 /f
reg add "%S%\Protocols\SSL 2.0\Client" /v "DisabledByDefault" /t REG_DWORD /d 1 /f
reg add "%S%\Protocols\SSL 3.0\Server" /v "Enabled" /t REG_DWORD /d 0 /f
reg add "%S%\Protocols\SSL 3.0\Server" /v "DisabledByDefault" /t REG_DWORD /d 1 /f
reg add "%S%\Protocols\SSL 3.0\Client" /v "Enabled" /t REG_DWORD /d 0 /f
reg add "%S%\Protocols\SSL 3.0\Client" /v "DisabledByDefault" /t REG_DWORD /d 1 /f
reg add "%S%\Protocols\DTLS 1.0\Server" /v "Enabled" /t REG_DWORD /d 0 /f
reg add "%S%\Protocols\DTLS 1.0\Server" /v "DisabledByDefault" /t REG_DWORD /d 1 /f
reg add "%S%\Protocols\DTLS 1.0\Client" /v "Enabled" /t REG_DWORD /d 0 /f
reg add "%S%\Protocols\DTLS 1.0\Client" /v "DisabledByDefault" /t REG_DWORD /d 1 /f
reg add "%S%\Protocols\DTLS 1.2\Server" /v "Enabled" /t REG_DWORD /d 1 /f
reg add "%S%\Protocols\DTLS 1.2\Server" /v "DisabledByDefault" /t REG_DWORD /d 0 /f
reg add "%S%\Protocols\DTLS 1.2\Client" /v "Enabled" /t REG_DWORD /d 1 /f
reg add "%S%\Protocols\DTLS 1.2\Client" /v "DisabledByDefault" /t REG_DWORD /d 0 /f
if %BUILD% GEQ 20348 goto tls13_on
echo Build %BUILD% has no official TLS 1.3 support - keeping TLS 1.3 disabled
for %%R in (Server Client) do (
    reg add "%S%\Protocols\TLS 1.3\%%R" /v "Enabled" /t REG_DWORD /d 0 /f
    reg add "%S%\Protocols\TLS 1.3\%%R" /v "DisabledByDefault" /t REG_DWORD /d 1 /f
)
goto net_settings

:tls13_on
for %%R in (Server Client) do (
    reg add "%S%\Protocols\TLS 1.3\%%R" /v "Enabled" /t REG_DWORD /d 1 /f
    reg add "%S%\Protocols\TLS 1.3\%%R" /v "DisabledByDefault" /t REG_DWORD /d 0 /f
)

:net_settings
reg add "HKLM\SOFTWARE\Microsoft\.NETFramework\v2.0.50727" /v "SchUseStrongCrypto" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\WOW6432Node\Microsoft\.NETFramework\v2.0.50727" /v "SchUseStrongCrypto" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\.NETFramework\v4.0.30319" /v "SchUseStrongCrypto" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\WOW6432Node\Microsoft\.NETFramework\v4.0.30319" /v "SchUseStrongCrypto" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\.NETFramework\v2.0.50727" /v "SystemDefaultTlsVersions" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\WOW6432Node\Microsoft\.NETFramework\v2.0.50727" /v "SystemDefaultTlsVersions" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\.NETFramework\v4.0.30319" /v "SystemDefaultTlsVersions" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\WOW6432Node\Microsoft\.NETFramework\v4.0.30319" /v "SystemDefaultTlsVersions" /t REG_DWORD /d 1 /f
echo [Nvrx] Done: Make Your System more Secure
exit /b 0
)NVRXBAT";

static const char* S_sec_updates =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Configure Windows Updates
echo [Nvrx] === Configure Windows Updates ===
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\current\device\Update" /v "ExcludeWUDriversInQualityUpdate" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Update" /v "ExcludeWUDriversInQualityUpdate" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v "ExcludeWUDriversInQualityUpdate" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v "ExcludeWUDriversInQualityUpdate" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Update\ExcludeWUDriversInQualityUpdate" /v "value" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Device Metadata" /v "PreventDeviceMetadataFromNetwork" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching" /v "SearchOrderConfig" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching" /v "DontSearchWindowsUpdate" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v "PauseFeatureUpdatesStartTime" /t REG_SZ /d "2023-08-17T12:47:51Z" /f
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v "PauseFeatureUpdatesEndTime" /t REG_SZ /d "2038-01-19T03:14:07Z" /f
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v "PauseQualityUpdatesStartTime" /t REG_SZ /d "2023-08-17T12:47:51Z" /f
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v "PauseQualityUpdatesEndTime" /t REG_SZ /d "2038-01-19T03:14:07Z" /f
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v "PauseUpdatesStartTime" /t REG_SZ /d "2023-08-17T12:47:51Z" /f
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v "PauseUpdatesExpiryTime" /t REG_SZ /d "2038-01-19T03:14:07Z" /f
reg add "HKLM\SYSTEM\Setup\UpgradeNotification" /v "UpgradeAvailable" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Settings" /v "DownloadMode" /t REG_SZ /d "0" /f
reg delete "HKLM\SOFTWARE\Microsoft\WindowsUpdate\Orchestrator\UScheduler_Oobe\DevHomeUpdate" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Orchestrator\UScheduler\DevHomeUpdate" /v "workCompleted" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\Orchestrator\UScheduler_Oobe" /v "BlockedOobeUpdaters" /t REG_SZ /d "[\"MS_Outlook\"]" /f
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v "HideMCTLink" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v "RestartNotificationsAllowed2" /t REG_DWORD /d 0 /f
reg add "HKLM\Software\Policies\Microsoft\Windows\WindowsUpdate" /v "DoNotConnectToWindowsUpdateInternetLocations" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v "SetDisableUXWUAccess" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\WindowsStore" /v "DisableOSUpgrade" /t REG_DWORD /d 1 /f
reg add "HKLM\Software\Policies\Microsoft\Windows\WindowsUpdate\AU" /v "AutomaticMaintenanceEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" /v "NoAutoUpdate" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" /v "NoAutoRebootWithLoggedOnUsers" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v "AUPowerManagement" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization" /v "DODownloadMode" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\WindowsStore" /v "AutoDownload" /t REG_DWORD /d 2 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\PreviewBuilds" /v "AllowBuildPreview" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\PreviewBuilds" /v "EnableConfigFlighting" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\PreviewBuilds" /v "EnableExperimentation" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v "ManagePreviewBuilds" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v "ManagePreviewBuildsPolicyValue" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v "InsiderProgramEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Microsoft\DriverSearching" /v "SearchOrderConfig" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Microsoft\DriverSearching" /v "DontSearchWindowsUpdate" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\DriverSearching" /v "DriverUpdateWizardWuSearchEnabled" /t REG_DWORD /d 0 /f
echo [Nvrx] Done: Configure Windows Updates
exit /b 0
)NVRXBAT";

static const char* S_sec_mitigations =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Disable Mitigations
echo [Nvrx] === Disable Mitigations ===
bcdedit /set hypervisorlaunchtype off
bcdedit /set vsmlaunchtype off
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard" /v "EnableVirtualizationBasedSecurity" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard" /v "HyperVVirtualizationBasedSecurityOptout" /t REG_DWORD /d 1 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard" /v "RequirePlatformSecurityFeatures" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\CredentialGuard" /v "Enabled" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\SystemGuard" /v "Enabled" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Lsa" /v "LsaCfgFlags" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard" /v "EnableVirtualizationBasedSecurity" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity" /v "Enabled" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard\Scenarios\CredentialGuard" /v "Enabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard" /v "HVCIMATRequired" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard" /v "HVCITelemetryPolicy" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v "FeatureSettings" /t REG_DWORD /d 1 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v "FeatureSettingsOverride" /t REG_DWORD /d 3 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v "FeatureSettingsOverrideMask" /t REG_DWORD /d 3 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v "MoveImages" /t REG_DWORD /d 0 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v "EnableCfg" /t REG_DWORD /d 0 /f
powershell -Command "ForEach($v in (Get-Command -Name 'Set-ProcessMitigation').Parameters['Disable'].Attributes.ValidValues){Set-ProcessMitigation -System -Disable $v.ToString() -ErrorAction SilentlyContinue}"
powershell -Command "Remove-Item -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\*' -Recurse -ErrorAction SilentlyContinue"
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" /v "DisableExceptionChainValidation" /t REG_DWORD /d 1 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" /v "DisableControlFlowGuardXfg" /t REG_DWORD /d 1 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" /v "DisableControlFlowGuardExportSuppression" /t REG_DWORD /d 1 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" /v "SerializeTimerExpiration" /t REG_DWORD /d 1 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" /v "DriveRemappingMitigation" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\KernelShadowStacks" /v "Enabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" /v "KernelSEHOPEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" /v "KernelShadowStacks" /t REG_DWORD /d 0 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" /v "MitigationOptions" /t REG_BINARY /d "222222222222222222222222222222222222222222222222" /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SCMConfig" /v "EnableSvchostMitigationsPolicy" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\WindowsMitigation" /v "UserPreference" /t REG_DWORD /d 1 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\Configuration Manager" /v "VirtualizationEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager" /v "ProtectionMode" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Internet Explorer\Main" /v "DEPOff" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\FVE" /v "DisableExternalDMAUnderLock" /t REG_DWORD /d 0 /f
echo [Nvrx] Done: Disable Mitigations
exit /b 0
)NVRXBAT";

static const char* S_sec_uac =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Disable UAC
echo [Nvrx] === Disable UAC ===
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v "EnableLUA" /t REG_DWORD /d 1 /f
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v "ConsentPromptBehaviorAdmin" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v "PromptOnSecureDesktop" /t REG_DWORD /d 0 /f
echo [Nvrx] Done: Disable UAC
exit /b 0
)NVRXBAT";

static const char* S_cust_win11 =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Customize your Windows 11
echo [Nvrx] === Customize your Windows 11 ===
del /f /q "%AppData%\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar*"
for /f "tokens=1" %%a in ('reg query "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" ^| findstr /i "MicrosoftEdgeAutoLaunch"') do (
  reg delete "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "%%a" /f
)
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Explorer" /v "HideRecommendedSection" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "Start_AccountNotifications" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "Start_TrackProgs" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\FlyoutMenuSettings" /v "ShowLockOption" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\FlyoutMenuSettings" /v "ShowSleepOption" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "TaskbarChat" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Chat" /v "ChatIcon" /t REG_DWORD /d 3 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "HidePeopleBar" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\People" /v "PeopleBand" /t REG_DWORD /d "0" /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "DisallowShaking" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "NoWorkingOnIt" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "SharingWizardOn" /t REG_DWORD /d 0 /f
reg delete "HKCR\*\shellex\ContextMenuHandlers\ModernSharing" /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Start\Companions\Microsoft.YourPhone_8wekyb3d8bbwe" /v "IsEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Appx" /v "AllowAutomaticAppArchiving" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\CrossDeviceResume\Configuration" /v "IsResumeAllowed" /t REG_DWORD /d 0 /f
reg add "HKLM\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "HideSCAHealth" /t REG_DWORD /d "1" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "ExtendedUIHoverTime" /t REG_DWORD /d "196608" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "DontPrettyPath" /t REG_DWORD /d "1" /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "NoLowDiskSpaceChecks" /t REG_DWORD /d "1" /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "NoInternetOpenWith" /t REG_DWORD /d "1" /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "NoInstrumentation" /t REG_DWORD /d "1" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "EnableBalloonTips" /t REG_DWORD /d "0" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "HideSCAMeetNow" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Feeds" /v "ShellFeedsTaskbarViewMode" /t REG_DWORD /d 2 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "ShowSyncProviderNotifications" /t REG_DWORD /d "0" /f
reg add "HKCU\Control Panel\Desktop" /v "JPEGImportQuality" /t REG_DWORD /d "100" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search" /v "AllowCloudSearch" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search" /v "AllowSearchToUseLocation" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\SearchSettings" /v "IsCloudContentEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search" /v "EnableSemanticIndexing" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Explorer" /v "DisableAIActions" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\SearchSettings" /v "SafeSearchMode" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\SearchSettings" /v "LanguageFeatures" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\SearchSettings" /v "HashesReported" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\SearchSettings" /v "CloudSearchControl" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" /v "ShowFrequent" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" /v "ShowRecent" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" /v "TelemetrySalt" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "Start_Layout" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "LaunchTo" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "HideFileExt" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "Hidden" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Start" /v "ShowRecentList" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "Start_TrackDocs" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "EnableSnapAssistFlyout" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "Start_TrackPrograms" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\TaskbarFlashing" /v "SystemSettings_DesktopTaskbar_Flashing" /t REG_SZ /d "0" /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "ShowBatteryPercentage" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "TaskbarAl" /t REG_DWORD /d 1 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "NoRecentDocsHistory" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\TaskbarDa" /v "SystemSettings_DesktopTaskbar_Da" /t REG_SZ /d "0" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "NoStartMenuMorePrograms" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "DisablePreviewWindow" /t REG_DWORD /d 1 /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "HideSCAMeetNow" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "TaskbarMn" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "TaskbarDa" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "Start_IrisRecommendations" /t REG_DWORD /d 0 /f
reg add "HKCU\SOFTWARE\Policies\Microsoft\Windows\Windows Feeds" /v "EnableFeeds" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\NewsAndInterests" /v "AllowNewsAndInterests" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Dsh" /v "AllowNewsAndInterests" /t REG_DWORD /d 0 /f
reg add "HKCU\Control Panel\Accessibility" /v "DynamicScrollbars" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "AllowOnlineTips" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Settings\AllowOnlineTips" /v "value" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "IconsOnly" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Personalization" /v "NoLockScreen" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v "DisableLogonBackgroundImage" /t REG_DWORD /d 0 /f
reg add "HKCU\Control Panel\Desktop" /v "AutoEndTasks" /t REG_SZ /d 1 /f
reg add "HKCU\Control Panel\Desktop" /v "HungAppTimeout" /t REG_SZ /d 1500 /f
reg add "HKCU\Control Panel\Desktop" /v "WaitToKillTimeout" /t REG_SZ /d 2500 /f
reg add "HKCU\Control Panel\Desktop" /v "WaitToKillAppTimeout" /t REG_SZ /d "2000" /f
reg add "HKCU\Control Panel\Desktop" /v "MenuShowDelay" /t REG_SZ /d "0" /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Device Metadata" /v "PreventDeviceMetadataFromNetwork" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Personalization" /v "NoLockScreenCamera" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Microsoft Edge" /v "NoRemove" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v "DisableAutomaticRestartSignOn" /t REG_DWORD /d "1" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Serialize" /v "StartupDelayInMSec" /t REG_DWORD /d "0" /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control\FileSystem" /v "LongPathsEnabled" /t REG_DWORD /d "1" /f
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\current\device\Education" /v "IsEducationEnvironment" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance" /v "MaintenanceDisabled" /t REG_DWORD /d 1 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Control" /v "WaitToKillServiceTimeout" /t REG_SZ /d 2500 /f
reg add "HKLM\System\CurrentControlSet\Control\CrashControl" /v "DisplayParameters" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v "VerboseStatus" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}" /ve /d "" /f
reg add "HKCU\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32" /ve /d "" /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\SmartActionPlatform" /v "SmartActionsEnabled" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\TaskbarDeveloperSettings" /v "TaskbarEndTask" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Classes\CLSID\{f874310e-b6b7-47dc-bc84-b9e6b38f5903}" /v "System.IsPinnedToNameSpaceTree" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Classes\CLSID\{e88865ea-0e1c-4e20-9aa6-edcd0212c87c}" /v "System.IsPinnedToNameSpaceTree" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Classes\CLSID\{d3162b92-9365-467a-956b-92703aca08af}" /v "System.IsPinnedToNameSpaceTree" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Classes\CLSID\{3dfdf296-dbec-4fb4-81d1-6a3438bcf4de}" /v "System.IsPinnedToNameSpaceTree" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Classes\CLSID\{0DB7E03F-FC29-4DC6-9020-FF41B59E513A}" /v "System.IsPinnedToNameSpaceTree" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Classes\CLSID\{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}" /v "System.IsPinnedToNameSpaceTree" /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v "AppsUseLightTheme" /t REG_DWORD /d "0" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v "AppsUseLightTheme" /t REG_DWORD /d "0" /f
reg add "HKCU\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\microsoft.microsoftedge_8wekyb3d8bbwe\MicrosoftEdge\Main" /v "Theme" /t REG_DWORD /d "1" /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v "EnableTransparency" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v "SystemUsesLightTheme" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" /v "VisualFXSetting" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Microsoft\Windows\DWM" /v "EnableBlurBehind" /t REG_DWORD /d 1 /f
)NVRXBAT"
R"NVRXBAT(reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v "TaskbarAnimations" /t REG_DWORD /d 1 /f
reg add "HKCU\Control Panel\Desktop\WindowMetrics" /v "MinAnimate" /t REG_SZ /d "1" /f
reg add "HKCU\Control Panel\Desktop" /v "DragFullWindows" /t REG_SZ /d "1" /f
reg add "HKCU\Control Panel\Desktop" /v "FontSmoothing" /t REG_SZ /d "2" /f
reg add "HKCU\Control Panel\Desktop" /v "FontSmoothingType" /t REG_DWORD /d 2 /f
reg add "HKCU\Control Panel\Desktop" /v "UserPreferencesMask" /t REG_BINARY /d 9e3e078012000000 /f
if not exist "C:\Nvrx\Cursor\" mkdir "C:\Nvrx\Cursor\"
if exist "C:\Nvrx\Cursor\Cursor\Install.inf" goto nvrx_cursor
echo Get Cursor Pack
powershell -NoProfile -ExecutionPolicy Bypass -Command "if(-not (Test-NetConnection -ComputerName www.dropbox.com -Port 443 -InformationLevel Quiet)){ exit 1 }"
if errorlevel 1 (
    echo Network connection check failed.
    exit /b 1
)
curl -g -L --fail -sS --connect-timeout 20 --retry 2 --remove-on-error -o "C:\Nvrx\Cursor\Cursor.zip" "https://www.dropbox.com/scl/fi/cqs3boexfp2l25rktey6n/Cursor.zip?rlkey=65xyyeuompxhg6nx6w7ur2zee&st=vlexkddo&dl=1"
if not exist "C:\Nvrx\Cursor\Cursor.zip" (
    echo Cursor download failed.
    exit /b 1
)
echo Unpack Cursor Pack
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force -Path 'C:\Nvrx\Cursor\Cursor.zip' -DestinationPath 'C:\Nvrx\Cursor'"
if not exist "C:\Nvrx\Cursor\Cursor\Install.inf" (
    echo Cursor unpack failed.
    exit /b 1
)
:nvrx_cursor
del /f /q "C:\Nvrx\Cursor\Cursor.zip" >nul 2>&1
echo Install Cursor Pack
robocopy "C:\Nvrx\Cursor\Cursor" "C:\Windows\Cursors\W11 Cursor Dark Free" *.cur *.ani /njh /njs /ndl /nc /ns /np >nul
if errorlevel 8 (
    echo Cursor copy failed.
    exit /b 1
)
reg add "HKCU\Control Panel\Cursors\Schemes" /v "W11 Cursor Dark Free by Jepri Creations" /t REG_SZ /d "C:\WINDOWS\Cursors\W11 Cursor Dark Free\arrow.cur,C:\WINDOWS\Cursors\W11 Cursor Dark Free\help.cur,C:\WINDOWS\Cursors\W11 Cursor Dark Free\appstarting.ani,C:\WINDOWS\Cursors\W11 Cursor Dark Free\wait.ani,C:\WINDOWS\Cursors\W11 Cursor Dark Free\crosshair.cur,C:\WINDOWS\Cursors\W11 Cursor Dark Free\ibeam.cur,C:\WINDOWS\Cursors\W11 Cursor Dark Free\nwpen.cur,C:\WINDOWS\Cursors\W11 Cursor Dark Free\no.cur,C:\WINDOWS\Cursors\W11 Cursor Dark Free\sizens.cur,C:\WINDOWS\Cursors\W11 Cursor Dark Free\sizewe.cur,C:\WINDOWS\Cursors\W11 Cursor Dark Free\sizenwse.cur,C:\WINDOWS\Cursors\W11 Cursor Dark Free\sizenesw.cur,C:\WINDOWS\Cursors\W11 Cursor Dark Free\sizeall.cur,C:\WINDOWS\Cursors\W11 Cursor Dark Free\uparrow.cur,C:\WINDOWS\Cursors\W11 Cursor Dark Free\hand.cur,C:\WINDOWS\Cursors\W11 Cursor Dark Free\person.cur,C:\WINDOWS\Cursors\W11 Cursor Dark Free\pin.cur" /f
reg add "HKCU\Control Panel\Cursors" /ve /t REG_EXPAND_SZ /d "W11 Cursor Dark Free by Jepri Creations" /f
reg add "HKCU\Control Panel\Cursors" /v "AppStarting" /t REG_EXPAND_SZ /d "C:\WINDOWS\Cursors\W11 Cursor Dark Free\appstarting.ani" /f
reg add "HKCU\Control Panel\Cursors" /v "Arrow" /t REG_EXPAND_SZ /d "C:\WINDOWS\Cursors\W11 Cursor Dark Free\arrow.cur" /f
reg add "HKCU\Control Panel\Cursors" /v "Crosshair" /t REG_EXPAND_SZ /d "C:\WINDOWS\Cursors\W11 Cursor Dark Free\crosshair.cur" /f
reg add "HKCU\Control Panel\Cursors" /v "Hand" /t REG_EXPAND_SZ /d "C:\WINDOWS\Cursors\W11 Cursor Dark Free\hand.cur" /f
reg add "HKCU\Control Panel\Cursors" /v "Help" /t REG_EXPAND_SZ /d "C:\WINDOWS\Cursors\W11 Cursor Dark Free\help.cur" /f
reg add "HKCU\Control Panel\Cursors" /v "IBeam" /t REG_EXPAND_SZ /d "C:\WINDOWS\Cursors\W11 Cursor Dark Free\ibeam.cur" /f
reg add "HKCU\Control Panel\Cursors" /v "No" /t REG_EXPAND_SZ /d "C:\WINDOWS\Cursors\W11 Cursor Dark Free\no.cur" /f
reg add "HKCU\Control Panel\Cursors" /v "NWPen" /t REG_EXPAND_SZ /d "C:\WINDOWS\Cursors\W11 Cursor Dark Free\nwpen.cur" /f
reg add "HKCU\Control Panel\Cursors" /v "SizeAll" /t REG_EXPAND_SZ /d "C:\WINDOWS\Cursors\W11 Cursor Dark Free\sizeall.cur" /f
reg add "HKCU\Control Panel\Cursors" /v "SizeNESW" /t REG_EXPAND_SZ /d "C:\WINDOWS\Cursors\W11 Cursor Dark Free\sizenesw.cur" /f
reg add "HKCU\Control Panel\Cursors" /v "SizeNS" /t REG_EXPAND_SZ /d "C:\WINDOWS\Cursors\W11 Cursor Dark Free\sizens.cur" /f
reg add "HKCU\Control Panel\Cursors" /v "SizeNWSE" /t REG_EXPAND_SZ /d "C:\WINDOWS\Cursors\W11 Cursor Dark Free\sizenwse.cur" /f
reg add "HKCU\Control Panel\Cursors" /v "SizeWE" /t REG_EXPAND_SZ /d "C:\WINDOWS\Cursors\W11 Cursor Dark Free\sizewe.cur" /f
reg add "HKCU\Control Panel\Cursors" /v "UpArrow" /t REG_EXPAND_SZ /d "C:\WINDOWS\Cursors\W11 Cursor Dark Free\uparrow.cur" /f
reg add "HKCU\Control Panel\Cursors" /v "Wait" /t REG_EXPAND_SZ /d "C:\WINDOWS\Cursors\W11 Cursor Dark Free\wait.ani" /f
reg add "HKCU\Control Panel\Cursors" /v "Person" /t REG_EXPAND_SZ /d "C:\WINDOWS\Cursors\W11 Cursor Dark Free\person.cur" /f
reg add "HKCU\Control Panel\Cursors" /v "Pin" /t REG_EXPAND_SZ /d "C:\WINDOWS\Cursors\W11 Cursor Dark Free\pin.cur" /f
powershell -NoProfile -ExecutionPolicy Bypass -Command "Add-Type -Namespace W -Name U32 -MemberDefinition '[DllImport(\"user32.dll\")] public static extern bool SystemParametersInfo(uint a, uint b, IntPtr c, uint d);'; [W.U32]::SystemParametersInfo(0x57,0,[IntPtr]::Zero,0)" >nul
reg delete "HKLM\SOFTWARE\Classes\SystemFileAssociations\.bmp\Shell\3D Edit" /f
reg delete "HKLM\SOFTWARE\Classes\SystemFileAssociations\.jpeg\Shell\3D Edit" /f
reg delete "HKLM\SOFTWARE\Classes\SystemFileAssociations\.jpe\Shell\3D Edit" /f
reg delete "HKLM\SOFTWARE\Classes\SystemFileAssociations\.jpg\Shell\3D Edit" /f
reg delete "HKLM\SOFTWARE\Classes\SystemFileAssociations\.png\Shell\3D Edit" /f
reg delete "HKLM\SOFTWARE\Classes\SystemFileAssociations\.gif\Shell\3D Edit" /f
reg delete "HKLM\SOFTWARE\Classes\SystemFileAssociations\.tif\Shell\3D Edit" /f
reg delete "HKLM\SOFTWARE\Classes\SystemFileAssociations\.tiff\Shell\3D Edit" /f
echo [Nvrx] Done: Customize your Windows 11
exit /b 0
)NVRXBAT";

static const char* S_cust_notifications =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Disable Notifications
echo [Nvrx] === Disable Notifications ===
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\PushNotifications" /v "ToastEnabled" /t REG_DWORD /d "0" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Notifications\Settings" /v "NOC_GLOBAL_SETTING_ALLOW_NOTIFICATION_SOUND" /t REG_DWORD /d "0" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Notifications\Settings" /v "NOC_GLOBAL_SETTING_ALLOW_CRITICAL_TOASTS_ABOVE_LOCK" /t REG_DWORD /d "0" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Notifications\Settings\QuietHours" /v "Enabled" /t REG_DWORD /d "0" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Notifications\Settings\windows.immersivecontrolpanel_cw5n1h2txyewy!microsoft.windows.immersivecontrolpanel" /v "Enabled" /t REG_DWORD /d "0" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Notifications\Settings\Windows.SystemToast.AutoPlay" /v "Enabled" /t REG_DWORD /d "0" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Notifications\Settings\Windows.SystemToast.LowDisk" /v "Enabled" /t REG_DWORD /d "0" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Notifications\Settings\Windows.SystemToast.Print.Notification" /v "Enabled" /t REG_DWORD /d "0" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Notifications\Settings\Windows.SystemToast.SecurityAndMaintenance" /v "Enabled" /t REG_DWORD /d "0" /f
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Notifications\Settings\Windows.SystemToast.WiFiNetworkManager" /v "Enabled" /t REG_DWORD /d "0" /f
echo [Nvrx] Done: Disable Notifications
exit /b 0
)NVRXBAT";

static const char* S_cust_branding =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Apply Nvrx Branding
echo [Nvrx] === Apply Nvrx Branding ===
if not exist "C:\Nvrx\Wallpaper" mkdir "C:\Nvrx\Wallpaper"
set "WALLPAPER_URL=https://www.dropbox.com/scl/fi/br3306y069ju6g24mmy2k/Nvrx-Tweaking.png?rlkey=tvtibet34olp9t0iayb4dlj8h&st=dqxaehrc&dl=1"
set "WALLPAPER_PATH=C:\Nvrx\Wallpaper\Nvrx Wallpaper.png"
echo [Nvrx] Get Nvrx Wallpaper.png
curl -g -L --fail -sS --connect-timeout 20 --retry 2 --remove-on-error "%WALLPAPER_URL%" -o "%WALLPAPER_PATH%"
if exist "%WALLPAPER_PATH%" (
powershell -Command "$code = '[DllImport(\"user32.dll\")] public static extern bool SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);'; Add-Type -MemberDefinition $code -Name Win32 -Namespace Native; [Native.Win32]::SystemParametersInfo(20, 0, 'C:\Nvrx\Wallpaper\Nvrx Wallpaper.png', 3)"
reg add "HKCU\Control Panel\Desktop" /v "WallpaperStyle" /t REG_SZ /d "10" /f
reg add "HKCU\Control Panel\Desktop" /v "TileWallpaper" /t REG_SZ /d "0" /f
)
sc create "Nvrx Tweaking" binPath= "C:\Windows\System32\cmd.exe" start= disabled DisplayName= "Nvrx Tweaking"
sc description "Nvrx Tweaking" "Official branding service for Nvrx Tweaking."
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v EditionSubVersion /t REG_SZ /d "Nvrx Tweaking" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v RegisteredOrganization /t REG_SZ /d "Nvrx Tweaking" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v RegisteredOwner /t REG_SZ /d "Nvrx Tweaking" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v DisplayVersion /t REG_SZ /d "Nvrx Tweaking" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation" /v Manufacturer /t REG_SZ /d "Nvrx Tweaking" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation" /v Model /t REG_SZ /d "Nvrx Tweaking" /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation" /v SupportURL /t REG_SZ /d "https://discord.gg/zCkcdZar5w" /f
echo [Nvrx] Done: Apply Nvrx Branding
exit /b 0
)NVRXBAT";

static const char* S_cust_ti_menu =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Enable Run As TrustedInstaller Context Menu
echo [Nvrx] === Enable Run As TrustedInstaller Context Menu ===
reg add "HKCR\batfile\shell\setdesktopwallpaper" /v "MUIVerb" /t REG_SZ /d "Run as TrustedInstaller" /f
reg add "HKCR\batfile\shell\setdesktopwallpaper" /v "HasLUAShield" /t REG_SZ /d "" /f
reg add "HKCR\batfile\shell\setdesktopwallpaper" /v "Icon" /t REG_SZ /d "powershell.exe,0" /f
reg add "HKCR\RunAsTI" /f
takeown /f "HKCR\batfile\shell\setdesktopwallpaper" /a
icacls "HKCR\batfile\shell\setdesktopwallpaper" /grant *S-1-5-32-544:F /t /c /q
takeown /f "HKCR\cmdfile\shell\setdesktopwallpaper" /a
icacls "HKCR\cmdfile\shell\setdesktopwallpaper" /grant *S-1-5-32-544:F /t /c /q
takeown /f "HKCR\exefile\shell\setdesktopwallpaper" /a
icacls "HKCR\exefile\shell\setdesktopwallpaper" /grant *S-1-5-32-544:F /t /c /q
takeown /f "HKCR\mscfile\shell\setdesktopwallpaper" /a
icacls "HKCR\mscfile\shell\setdesktopwallpaper" /grant *S-1-5-32-544:F /t /c /q
takeown /f "HKCR\regfile\shell\setdesktopwallpaper" /a
icacls "HKCR\regfile\shell\setdesktopwallpaper" /grant *S-1-5-32-544:F /t /c /q
takeown /f "HKCR\Folder\shell" /a
icacls "HKCR\Folder\shell" /grant *S-1-5-32-544:F /t /c /q
takeown /f "HKCR\Folder\shell\setdesktopwallpaper" /a
icacls "HKCR\Folder\shell\setdesktopwallpaper" /grant *S-1-5-32-544:F /t /c /q
powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand JABSAD0AWwBNAGkAYwByAG8AcwBvAGYAdAAuAFcAaQBuADMAMgAuAFIAZQBnAGkAcwB0AHIAeQBdADsAIABmAHUAbgBjAHQAaQBvAG4AIABTADIAKAAkAHIALAAkAHAALAAkAG4ALAAkAHYAKQB7ACAAJAB4AD0AJABuAHUAbABsADsAIAB0AHIAeQB7ACAAJAB4AD0AJAByAC4ATwBwAGUAbgBTAHUAYgBLAGUAeQAoACQAcAAsACQAdAByAHUAZQApACAAfQBjAGEAdABjAGgAewB9ADsAIABpAGYAKAAhACQAeAApAHsAIAB0AHIAeQB7ACAAJAB4AD0AJAByAC4AQwByAGUAYQB0AGUAUwB1AGIASwBlAHkAKAAkAHAAKQAgAH0AYwBhAHQAYwBoAHsAfQAgAH0AOwAgAGkAZgAoACQAeAApAHsAIAB0AHIAeQB7ACAAJAB4AC4AUwBlAHQAVgBhAGwAdQBlACgAJABuACwAJAB2ACwAJwBTAHQAcgBpAG4AZwAnACkAIAB9AGMAYQB0AGMAaAB7AH0AOwAgACQAeAAuAEMAbABvAHMAZQAoACkAIAB9ACAAfQA7ACAAUwAyACAAJABSADoAOgBDAGwAYQBzAHMAZQBzAFIAbwBvAHQAIAAnAGIAYQB0AGYAaQBsAGUAXABzAGgAZQBsAGwAXABzAGUAdABkAGUAcwBrAHQAbwBwAHcAYQBsAGwAcABhAHAAZQByAFwAYwBvAG0AbQBhAG4AZAAnACAAJwAnACAAJwBDADoAXABXAGkAbgBkAG8AdwBzAFwAUwB5AHMAdABlAG0AMwAyAFwAVwBpAG4AZABvAHcAcwBQAG8AdwBlAHIAUwBoAGUAbABsAFwAdgAxAC4AMABcAHAAbwB3AGUAcgBzAGgAZQBsAGwALgBlAHgAZQAgAC0AdwBpAG4AIAAxACAALQBuAG8AcAAgAC0AYwAgAGkAZQB4ACgAKAAxADAALgAuADQAMAB8ACUAJQB7ACgAZwBwACAAJwAnAFIAZQBnAGkAcwB0AHIAeQA6ADoASABLAEMAUgBcAFIAdQBuAEEAcwBUAEkAJwAnACAAJABfACAALQBlAGEAIAAwACkALgAkAF8AfQApAC0AagBvAGkAbgBbAGMAaABhAHIAXQAxADAAKQA7ACAAIwAgAC0ALQAlACUAIAAiACUATAAiACcAOwAgAFMAMgAgACQAUgA6ADoAQwBsAGEAcwBzAGUAcwBSAG8AbwB0ACAAJwBjAG0AZABmAGkAbABlAFwAcwBoAGUAbABsAFwAcwBlAHQAZABlAHMAawB0AG8AcAB3AGEAbABsAHAAYQBwAGUAcgBcAGMAbwBtAG0AYQBuAGQAJwAgACcAJwAgACcAQwA6AFwAVwBpAG4AZABvAHcAcwBcAFMAeQBzAHQAZQBtADMAMgBcAFcAaQBuAGQAbwB3AHMAUABvAHcAZQByAFMAaABlAGwAbABcAHYAMQAuADAAXABwAG8AdwBlAHIAcwBoAGUAbABsAC4AZQB4AGUAIAAtAHcAaQBuACAAMQAgAC0AbgBvAHAAIAAtAGMAIABpAGUAeAAoACgAMQAwAC4ALgA0ADAAfAAlACUAewAoAGcAcAAgACcAJwBSAGUAZwBpAHMAdAByAHkAOgA6AEgASwBDAFIAXABSAHUAbgBBAHMAVABJACcAJwAgACQAXwAgAC0AZQBhACAAMAApAC4AJABfAH0AKQAtAGoAbwBpAG4AWwBjAGgAYQByAF0AMQAwACkAOwAgACMAIAAtAC0AJQAlACAAIgAlAEwAIgAnADsAIABTADIAIAAkAFIAOgA6AEMAbABhAHMAcwBlAHMAUgBvAG8AdAAgACcAZQB4AGUAZgBpAGwAZQBcAHMAaABlAGwAbABcAHMAZQB0AGQAZQBzAGsAdABvAHAAdwBhAGwAbABwAGEAcABlAHIAXABjAG8AbQBtAGEAbgBkACcAIAAnACcAIAAnAEMAOgBcAFcAaQBuAGQAbwB3AHMAXABTAHkAcwB0AGUAbQAzADIAXABXAGkAbgBkAG8AdwBzAFAAbwB3AGUAcgBTAGgAZQBsAGwAXAB2ADEALgAwAFwAcABvAHcAZQByAHMAaABlAGwAbAAuAGUAeABlACAALQB3AGkAbgAgADEAIAAtAG4AbwBwACAALQBjACAAaQBlAHgAKAAoADEAMAAuAC4ANAAwAHwAJQAlAHsAKABnAHAAIAAnACcAUgBlAGcAaQBzAHQAcgB5ADoAOgBIAEsAQwBSAFwAUgB1AG4AQQBzAFQASQAnACcAIAAkAF8AIAAtAGUAYQAgADAAKQAuACQAXwB9ACkALQBqAG8AaQBuAFsAYwBoAGEAcgBdADEAMAApADsAIAAjACAALQAtACUAJQAgACIAJQBMACIAJwA7ACAAUwAyACAAJABSADoAOgBDAGwAYQBzAHMAZQBzAFIAbwBvAHQAIAAnAG0AcwBjAGYAaQBsAGUAXABzAGgAZQBsAGwAXABzAGUAdABkAGUAcwBrAHQAbwBwAHcAYQBsAGwAcABhAHAAZQByAFwAYwBvAG0AbQBhAG4AZAAnACAAJwAnACAAJwBDADoAXABXAGkAbgBkAG8AdwBzAFwAUwB5AHMAdABlAG0AMwAyAFwAVwBpAG4AZABvAHcAcwBQAG8AdwBlAHIAUwBoAGUAbABsAFwAdgAxAC4AMABcAHAAbwB3AGUAcgBzAGgAZQBsAGwALgBlAHgAZQAgAC0AdwBpAG4AIAAxACAALQBuAG8AcAAgAC0AYwAgAGkAZQB4ACgAKAAxADAALgAuADQAMAB8ACUAJQB7ACgAZwBwACAAJwAnAFIAZQBnAGkAcwB0AHIAeQA6ADoASABLAEMAUgBcAFIAdQBuAEEAcwBUAEkAJwAnACAAJABfACAALQBlAGEAIAAwACkALgAkAF8AfQApAC0AagBvAGkAbgBbAGMAaABhAHIAXQAxADAAKQA7ACAAIwAgAC0ALQAlACUAIAAiACUATAAiACcAOwAgAFMAMgAgACQAUgA6ADoAQwBsAGEAcwBzAGUAcwBSAG8AbwB0ACAAJwByAGUAZwBmAGkAbABlAFwAcwBoAGUAbABsAFwAcwBlAHQAZABlAHMAawB0AG8AcAB3AGEAbABsAHAAYQBwAGUAcgBcAGMAbwBtAG0AYQBuAGQAJwAgACcAJwAgACcAQwA6AFwAVwBpAG4AZABvAHcAcwBcAFMAeQBzAHQAZQBtADMAMgBcAFcAaQBuAGQAbwB3AHMAUABvAHcAZQByAFMAaABlAGwAbABcAHYAMQAuADAAXABwAG8AdwBlAHIAcwBoAGUAbABsAC4AZQB4AGUAIAAtAHcAaQBuACAAMQAgAC0AbgBvAHAAIAAtAGMAIABpAGUAeAAoACgAMQAwAC4ALgA0ADAAfAAlACUAewAoAGcAcAAgACcAJwBSAGUAZwBpAHMAdAByAHkAOgA6AEgASwBDAFIAXABSAHUAbgBBAHMAVABJACcAJwAgACQAXwAgAC0AZQBhACAAMAApAC4AJABfAH0AKQAtAGoAbwBpAG4AWwBjAGgAYQByAF0AMQAwACkAOwAgACMAIAAtAC0AJQAlACAAcgBlAGcAZQBkAGkAdAAgAC8AcwAgACIAJQBMACIAJwA7ACAAUwAyACAAJABSADoAOgBDAGwAYQBzAHMAZQBzAFIAbwBvAHQAIAAnAEYAbwBsAGQAZQByAFwAcwBoAGUAbABsAFwAcwBlAHQAZABlAHMAawB0AG8AcAB3AGEAbABsAHAAYQBwAGUAcgAnACAAJwBBAHAAcABsAGkAZQBzAFQAbwAnACAAJwBOAE8AVAAgAFMAeQBzAHQAZQBtAC4AUABhAHIAcwBpAG4AZwBOAGEAbQBlADoAPQAiADoAOgB7ADYANAA1AEYARgAwADQAMAAtADUAMAA4ADEALQAxADAAMQBCAC0AOQBGADAAOAAtADAAMABBAEEAMAAwADIARgA5ADUANABFAH0AIgAnADsAIABTADIAIAAkAFIAOgA6AEMAbABhAHMAcwBlAHMAUgBvAG8AdAAgACcARgBvAGwAZABlAHIAXABzAGgAZQBsAGwAXABzAGUAdABkAGUAcwBrAHQAbwBwAHcAYQBsAGwAcABhAHAAZQByAFwAYwBvAG0AbQBhAG4AZAAnACAAJwAnACAAJwBDADoAXABXAGkAbgBkAG8AdwBzAFwAUwB5AHMAdABlAG0AMwAyAFwAVwBpAG4AZABvAHcAcwBQAG8AdwBlAHIAUwBoAGUAbABsAFwAdgAxAC4AMABcAHAAbwB3AGUAcgBzAGgAZQBsAGwALgBlAHgAZQAgAC0AdwBpAG4AIAAxACAALQBuAG8AcAAgAC0AYwAgAGkAZQB4ACgAKAAxADAALgAuADQAMAB8ACUAJQB7ACgAZwBwACAAJwAnAFIAZQBnAGkAcwB0AHIAeQA6ADoASABLAEMAUgBcAFIAdQBuAEEAcwBUAEkAJwAnACAAJABfACAALQBlAGEAIAAwACkALgAkAF8AfQApAC0AagBvAGkAbgBbAGMAaABhAHIAXQAxADAAKQA7ACAAIwAgAC0ALQAlACUAIAAiACUATAAiACcAOwAgAFMAMgAgACQAUgA6ADoAQwBsAGEAcwBzAGUAcwBSAG8AbwB0ACAAJwBSAHUAbgBBAHMAVABJACcAIAAnADEAMAAnACAAJwBmAHUAbgBjAHQAaQBvAG4AIABSAHUAbgBBAHMAVABJACAAKAAkAGMAbQBkACwAJABhAHIAZwApACAAewAgACQAaQBkAD0AJwAnAFIAdQBuAEEAcwBUAEkAJwAnADsAIAAkAGsAZQB5AD0AIgBSAGUAZwBpAHMAdAByAHkAOgA6AEgASwBVAFwAJAAoACgAKAB3AGgAbwBhAG0AaQAgAC8AdQBzAGUAcgApAC0AcwBwAGwAaQB0ACcAJwAgACcAJwApAFsALQAxAF0AKQBcAFYAbwBsAGEAdABpAGwAZQAgAEUAbgB2AGkAcgBvAG4AbQBlAG4AdAAiADsAIAAkAGMAbwBkAGUAPQBAACcAJwAnADsAIABTADIAIAAkAFIAOgA6AEMAbABhAHMAcwBlAHMAUgBvAG8AdAAgACcAUgB1AG4AQQBzAFQASQAnACAAJwAxADEAJwAgACcAIAAkAEkAPQBbAGkAbgB0ADMAMgBdADsAIAAkAE0APQAkAEkALgBtAG8AZAB1AGwAZQAuAGcAZQB0AHQAeQBwAGUAKAAiAFMAeQBzAHQAZQBtAC4AUgB1AG4AdABpAG0AZQAuAEkAbgB0AGUAcgBvAHAAYABTAGUAcgB2AGkAYwBlAHMALgBNAGEAcgBgAHMAaABhAGwAIgApADsAIAAkAFAAPQAkAEkALgBtAG8AZAB1AGwAZQAuAGcAZQB0AHQAeQBwAGUAKAAiAFMAeQBzAHQAZQBtAC4ASQBuAHQAYABQAHQAcgAiACkAOwAgACQAUwA9AFsAcwB0AHIAaQBuAGcAXQAnADsAIABTADIAIAAkAFIAOgA6AEMAbABhAHMAcwBlAHMAUgBvAG8AdAAgACcAUgB1AG4AQQBzAFQASQAnACAAJwAxADIAJwAgACcAIAAkAEQAPQBAACgAKQA7ACAAJABUAD0AQAAoACkAOwAgACQARABNAD0AWwBBAHAAcABEAG8AbQBhAGkAbgBdADoAOgBDAHUAcgByAGUAbgB0AEQAbwBtAGEAaQBuAC4AIgBEAGUAZgBpAG4AZQBEAHkAbgBhAG0AaQBgAGMAQQBzAHMAZQBtAGIAbAB5ACIAKAAxACwAMQApAC4AIgBEAGUAZgBpAG4AZQBEAHkAbgBhAG0AaQBgAGMATQBvAGQAdQBsAGUAIgAoADEAKQA7ACAAJABaAD0AWwB1AGkAbgB0AHAAdAByAF0AOgA6AHMAaQB6AGUAIAAnAA==
)NVRXBAT"
R"NVRXBAT(powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand JABSAD0AWwBNAGkAYwByAG8AcwBvAGYAdAAuAFcAaQBuADMAMgAuAFIAZQBnAGkAcwB0AHIAeQBdADsAIABmAHUAbgBjAHQAaQBvAG4AIABTADIAKAAkAHIALAAkAHAALAAkAG4ALAAkAHYAKQB7ACAAJAB4AD0AJABuAHUAbABsADsAIAB0AHIAeQB7ACAAJAB4AD0AJAByAC4ATwBwAGUAbgBTAHUAYgBLAGUAeQAoACQAcAAsACQAdAByAHUAZQApACAAfQBjAGEAdABjAGgAewB9ADsAIABpAGYAKAAhACQAeAApAHsAIAB0AHIAeQB7ACAAJAB4AD0AJAByAC4AQwByAGUAYQB0AGUAUwB1AGIASwBlAHkAKAAkAHAAKQAgAH0AYwBhAHQAYwBoAHsAfQAgAH0AOwAgAGkAZgAoACQAeAApAHsAIAB0AHIAeQB7ACAAJAB4AC4AUwBlAHQAVgBhAGwAdQBlACgAJABuACwAJAB2ACwAJwBTAHQAcgBpAG4AZwAnACkAIAB9AGMAYQB0AGMAaAB7AH0AOwAgACQAeAAuAEMAbABvAHMAZQAoACkAIAB9ACAAfQA7ACAAUwAyACAAJABSADoAOgBDAGwAYQBzAHMAZQBzAFIAbwBvAHQAIAAnAFIAdQBuAEEAcwBUAEkAJwAgACcAMQAzACcAIAAnACAAMAAuAC4ANQB8ACUAIAB7ACQARAAgACsAPQAgACQARABNAC4AIgBEAGUAZgBpAG4AYABlAFQAeQBwAGUAIgAoACIAQQB2AGUAWQBvAF8AJABfACIALAAxADEANwA5ADkAMQAzACwAWwBWAGEAbAB1AGUAVAB5AHAAZQBdACkAfQA7ACAAJABEACAAKwA9ACAAWwB1AGkAbgB0AHAAdAByAF0AOwAgADQALgAuADYAfAAlACAAewAkAEQAIAArAD0AIAAkAEQAWwAkAF8AXQAuACIATQBhAGsAZQBCAHkAUgBgAGUAZgBUAHkAcABlACIAKAApAH0AJwA7ACAAUwAyACAAJABSADoAOgBDAGwAYQBzAHMAZQBzAFIAbwBvAHQAIAAnAFIAdQBuAEEAcwBUAEkAJwAgACcAMQA1ACcAIAAnACAAMAAuAC4AMgB8ACUAIAB7ACQAOQA9ACQARABbADAAXQAuACIARABlAGYAaQBuAGUAUABJAG4AdgBvAGsAYABlAE0AZQB0AGgAbwBkACIAKAAoACcAJwBDAHIAZQBhAHQAZQBQAHIAbwBjAGUAcwBzACcAJwAsACcAJwBSAGUAZwBPAHAAZQBuAEsAZQB5AEUAeAAnACcALAAnACcAUgBlAGcAUwBlAHQAVgBhAGwAdQBlAEUAeAAnACcAKQBbACQAXwBdACwAJABGAFsAJABfAF0AKwAnACcAMwAyACcAJwAsADgAMgAxADQALAAxACwAJABTACwAJABGAFsAJABfACsAMwBdACwAMQAsADQAKQB9ACcAOwAgAFMAMgAgACQAUgA6ADoAQwBsAGEAcwBzAGUAcwBSAG8AbwB0ACAAJwBSAHUAbgBBAHMAVABJACcAIAAnADEANwAnACAAJwAgADEALgAuADUAfAAlACAAewAkAGsAPQAkAF8AOwAgACQAbgA9ADEAOwAgACQARABGAFsAJABfAC0AMQBdAHwAJQAgAHsAJAA5AD0AJABEAFsAJABrAF0ALgAiAEQAZQBmAGkAbgBgAGUARgBpAGUAbABkACIAKAAnACcAZgAnACcAIAArACAAJABuACsAKwAsACAAJABfACwAIAA2ACkAfQB9ADsAIAAwAC4ALgA1AHwAJQAgAHsAJABUACAAKwA9ACAAJABEAFsAJABfAF0ALgAiAEMAcgBlAGEAdABgAGUAVAB5AHAAZQAiACgAKQB9ACcAOwAgAFMAMgAgACQAUgA6ADoAQwBsAGEAcwBzAGUAcwBSAG8AbwB0ACAAJwBSAHUAbgBBAHMAVABJACcAIAAnADEAOAAnACAAJwAgADAALgAuADUAfAAlACAAewBuAHYAIAAiAEEAJABfACIAIAAoAFsAQQBjAHQAaQB2AGEAdABvAHIAXQA6ADoAQwByAGUAYQB0AGUASQBuAHMAdABhAG4AYwBlACgAJABUAFsAJABfAF0AKQApACAALQBmAG8AfQA7ACAAZgB1AG4AYwB0AGkAbwBuACAARgAgACgAJAAxACwAJAAyACkAIAB7ACQAVABbADAAXQAuACIARwBgAGUAdABNAGUAdABoAG8AZAAiACgAJAAxACkALgBpAG4AdgBvAGsAZQAoADAALAAkADIAKQB9ACcAOwAgAFMAMgAgACQAUgA6ADoAQwBsAGEAcwBzAGUAcwBSAG8AbwB0ACAAJwBSAHUAbgBBAHMAVABJACcAIAAnADIAMQAnACAAJwAgAGYAdQBuAGMAdABpAG8AbgAgAE0AIAAoACQAMQAsACQAMgAsACQAMwApACAAewAkAE0ALgAiAEcAYABlAHQATQBlAHQAaABvAGQAIgAoACQAMQAsAFsAdAB5AHAAZQBbAF0AXQAkADIAKQAuAGkAbgB2AG8AawBlACgAMAAsACQAMwApAH0AOwAgACQASAA9AEAAKAApADsAIAAkAFoALAAoADQAKgAkAFoAKwAxADYAKQB8ACUAIAB7ACQASAAgACsAPQAgAE0AIAAiAEEAbABsAG8AYwBIAEcAYABsAG8AYgBhAGwAIgAgACQASQAgACQAXwB9ACcAOwAgAFMAMgAgACQAUgA6ADoAQwBsAGEAcwBzAGUAcwBSAG8AbwB0ACAAJwBSAHUAbgBBAHMAVABJACcAIAAnADIAMgAnACAAJwAgAE0AIAAiAFcAcgBpAHQAZQBJAG4AdABgAFAAdAByACIAIAAoACQAUAAsACQAUAApACAAKAAkAEgAWwAwAF0ALAAkAEEAcwAuAEgAYQBuAGQAbABlACkAOwAgACQAQQAxAC4AZgAxAD0AMQAzADEAMAA3ADIAOwAgACQAQQAxAC4AZgAyAD0AJABaADsAIAAkAEEAMQAuAGYAMwA9ACQASABbADAAXQA7ACAAJABBADIALgBmADEAPQAxADsAIAAkAEEAMgAuAGYAMgA9ADEAOwAgACQAQQAyAC4AZgAzAD0AMQA7ACAAJABBADIALgBmADQAPQAxACcAOwAgAFMAMgAgACQAUgA6ADoAQwBsAGEAcwBzAGUAcwBSAG8AbwB0ACAAJwBSAHUAbgBBAHMAVABJACcAIAAnADIAMwAnACAAJwAgACQAQQAyAC4AZgA2AD0AJABBADEAOwAgACQAQQAzAC4AZgAxAD0AMQAwACoAJABaACsAMwAyADsAIAAkAEEANAAuAGYAMQA9ACQAQQAzADsAIAAkAEEANAAuAGYAMgA9ACQASABbADEAXQA7ACAATQAgACIAUwB0AHIAdQBjAHQAdQByAGUAVABvAGAAUAB0AHIAIgAgACgAJABEAFsAMgBdACwAJABQACwAWwBiAG8AbwBsAGUAYQBuAF0AKQAgACgAKAAkAEEAMgAgAC0AYQBzACAAJABEAFsAMgBdACkALAAkAEEANAAuAGYAMgAsACQAZgBhAGwAcwBlACkAJwA7ACAAUwAyACAAJABSADoAOgBDAGwAYQBzAHMAZQBzAFIAbwBvAHQAIAAnAFIAdQBuAEEAcwBUAEkAJwAgACcAMgA0ACcAIAAnACAAJABSAHUAbgA9AEAAKAAkAG4AdQBsAGwALAAgACIAcABvAHcAZQByAHMAaABlAGwAbAAgAC0AdwBpAG4AIAAxACAALQBuAG8AcAAgAC0AYwAgAGkAZQB4ACAAYAAkAGUAbgB2ADoAUgA7ACAAIwAgACQAaQBkACIALAAgADAALAAgADAALAAgADAALAAgADAAeAAwAEUAMAA4ADAANgAwADAALAAgADAALAAgACQAbgB1AGwAbAAsACAAKAAkAEEANAAgAC0AYQBzACAAJABUAFsANABdACkALAAgACgAJABBADUAIAAtAGEAcwAgACQAVABbADUAXQApACkAJwA7ACAAUwAyACAAJABSADoAOgBDAGwAYQBzAHMAZQBzAFIAbwBvAHQAIAAnAFIAdQBuAEEAcwBUAEkAJwAgACcAMgA1ACcAIAAnACAARgAgACcAJwBDAHIAZQBhAHQAZQBQAHIAbwBjAGUAcwBzACcAJwAgACQAUgB1AG4AOwAgAHIAZQB0AHUAcgBuAH0AOwAgACQAZQBuAHYAOgBSAD0AJwAnACcAJwA7ACAAcgBwACAAJABrAGUAeQAgACQAaQBkACAALQBmAG8AcgBjAGUAOwAgACQAcAByAGkAdgA9AFsAZABpAGEAZwBuAG8AcwB0AGkAYwBzAC4AcAByAG8AYwBlAHMAcwBdAC4AIgBHAGUAdABNAGAAZQBtAGIAZQByACIAKAAnACcAUwBlAHQAUAByAGkAdgBpAGwAZQBnAGUAJwAnACwANAAyACkAWwAwAF0AJwA7ACAAUwAyACAAJABSADoAOgBDAGwAYQBzAHMAZQBzAFIAbwBvAHQAIAAnAFIAdQBuAEEAcwBUAEkAJwAgACcAMgA2ACcAIAAnACAAJwAnAFMAZQBTAGUAYwB1AHIAaQB0AHkAUAByAGkAdgBpAGwAZQBnAGUAJwAnACwAJwAnAFMAZQBUAGEAawBlAE8AdwBuAGUAcgBzAGgAaQBwAFAAcgBpAHYAaQBsAGUAZwBlACcAJwAsACcAJwBTAGUAQgBhAGMAawB1AHAAUAByAGkAdgBpAGwAZQBnAGUAJwAnACwAJwAnAFMAZQBSAGUAcwB0AG8AcgBlAFAAcgBpAHYAaQBsAGUAZwBlACcAJwAgAHwAJQAgAHsAJABwAHIAaQB2AC4ASQBuAHYAbwBrAGUAKAAkAG4AdQBsAGwALAAgAEAAKAAiACQAXwAiACwAMgApACkAfQAnADsAIABTADIAIAAkAFIAOgA6AEMAbABhAHMAcwBlAHMAUgBvAG8AdAAgACcAUgB1AG4AQQBzAFQASQAnACAAJwAyADkAJwAgACcAIAAgACQAYgA9AFsAVABlAHgAdAAuAEUAbgBjAG8AZABpAG4AZwBdADoAOgBVAG4AaQBjAG8AZABlAC4ARwBlAHQAQgB5AHQAZQBzACgAIgBcAFIAZQBnAGkAcwB0AHIAeQBcAFUAcwBlAHIAXAAkADEAIgApADsAIABGACAAJwAnAFIAZQBnAFMAZQB0AFYAYQBsAHUAZQBFAHgAJwAnACAAQAAoACQAMgAsACcAJwBTAHkAbQBiAG8AbABpAGMATABpAG4AawBWAGEAbAB1AGUAJwAnACwAMAAsADYALABbAGIAeQB0AGUAWwBdAF0AJABiACwAJABiAC4ATABlAG4AZwB0AGgAKQB9ACcAOwAgAFMAMgAgACQAUgA6ADoAQwBsAGEAcwBzAGUAcwBSAG8AbwB0ACAAJwBSAHUAbgBBAHMAVABJACcAIAAnADMAMAAnACAAJwAgAGYAdQBuAGMAdABpAG8AbgAgAFEAIAB7AFsAaQBuAHQAXQAoAGcAdwBtAGkAIAB3AGkAbgAzADIAXwBwAHIAbwBjAGUAcwBzACAALQBmAGkAbAB0AGUAcgAgACcAJwBuAGEAbQBlAD0AIgBlAHgAcABsAG8AcgBlAHIALgBlAHgAZQAiACcAJwB8AD8AewAkAF8ALgBnAGUAdABvAHcAbgBlAHIAcwBpAGQAKAApAC4AcwBpAGQALQBlAHEAJABOAFQAfQB8AHMAZQBsAGUAYwB0ACAALQBsAGEAcwB0ACAAMQApAC4AUAByAG8AYwBlAHMAcwBJAGQAfQAnADsAIABTADIAIAAkAFIAOgA6AEMAbABhAHMAcwBlAHMAUgBvAG8AdAAgACcAUgB1AG4AQQBzAFQASQAnACAAJwAzADEAJwAgACcAIAAkAGUAbgB2ADoAdwB0AD0AJwAnAHAAbwB3AGUAcgBzAGgAZQBsAGwAJwAnADsAIABkAGkAcgAgACIAJABlAG4AdgA6AFAAcgBvAGcAcgBhAG0ARgBpAGwAZQBzAFwAVwBpAG4AZABvAHcAcwBBAHAAcABzAFwATQBpAGMAcgBvAHMAbwBmAHQALgBXAGkAbgBkAG8AdwBzAFQAZQByAG0AaQBuAGEAbAAqAFwAdwB0AC4AZQB4AGUAIgAgAC0AcgBlAGMAfAAlACAAewAkAGUAbgB2ADoAdwB0AD0AJwAnACIAJwAnACsAJABfAC4ARgB1AGwAbABOAGEAbQBlACsAJwAnACIAIAAiAC0AZAAgAC4AIgAnACcAfQAnAA==
powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand JABSAD0AWwBNAGkAYwByAG8AcwBvAGYAdAAuAFcAaQBuADMAMgAuAFIAZQBnAGkAcwB0AHIAeQBdADsAIABmAHUAbgBjAHQAaQBvAG4AIABTADIAKAAkAHIALAAkAHAALAAkAG4ALAAkAHYAKQB7ACAAJAB4AD0AJABuAHUAbABsADsAIAB0AHIAeQB7ACAAJAB4AD0AJAByAC4ATwBwAGUAbgBTAHUAYgBLAGUAeQAoACQAcAAsACQAdAByAHUAZQApACAAfQBjAGEAdABjAGgAewB9ADsAIABpAGYAKAAhACQAeAApAHsAIAB0AHIAeQB7ACAAJAB4AD0AJAByAC4AQwByAGUAYQB0AGUAUwB1AGIASwBlAHkAKAAkAHAAKQAgAH0AYwBhAHQAYwBoAHsAfQAgAH0AOwAgAGkAZgAoACQAeAApAHsAIAB0AHIAeQB7ACAAJAB4AC4AUwBlAHQAVgBhAGwAdQBlACgAJABuACwAJAB2ACwAJwBTAHQAcgBpAG4AZwAnACkAIAB9AGMAYQB0AGMAaAB7AH0AOwAgACQAeAAuAEMAbABvAHMAZQAoACkAIAB9ACAAfQA7ACAAUwAyACAAJABSADoAOgBDAGwAYQBzAHMAZQBzAFIAbwBvAHQAIAAnAFIAdQBuAEEAcwBUAEkAJwAgACcAMwAzACcAIAAnACAAaQBmACAAKAAkADEAMQBiAHUAZwApACAAewAnACcAUwB5AHMAdABlAG0ALgBXAGkAbgBkAG8AdwBzAC4ARgBvAHIAbQBzACcAJwAsACcAJwBNAGkAYwByAG8AcwBvAGYAdAAuAFYAaQBzAHUAYQBsAEIAYQBzAGkAYwAnACcAIAB8ACUAIAB7ACQAOQA9AFsAUgBlAGYAbABlAGMAdABpAG8AbgAuAEEAcwBzAGUAbQBiAGwAeQBdADoAOgBMAG8AYQBkAFcAaQB0AGgAUABhAHIAdABpAGEAbABOAGEAbQBlACgAIgAnACcAJABfACIAKQB9AH0AJwA7ACAAUwAyACAAJABSADoAOgBDAGwAYQBzAHMAZQBzAFIAbwBvAHQAIAAnAFIAdQBuAEEAcwBUAEkAJwAgACcAMwA4ACcAIAAnACcAJwBAADsAIAAkAFYAPQAnACcAJwAnADsAJwAnAGMAbQBkACcAJwAsACcAJwBhAHIAZwAnACcALAAnACcAaQBkACcAJwAsACcAJwBrAGUAeQAnACcAfAAlAHsAJABWACsAPQAiAGAAbgBgACQAJABfAD0AJwAnACQAKAAkACgAZwB2ACAAJABfACAALQB2AGEAbAApAC0AcgBlAHAAbABhAGMAZQAiACcAJwAiACwAIgAnACcAJwAnACIAKQAnACcAOwAiAH0AOwAgAHMAcAAgACQAawBlAHkAIAAkAGkAZAAgACQAKAAkAFYALAAkAGMAbwBkAGUAKQAgAC0AdAB5AHAAZQAgADcAIAAtAGYAbwByAGMAZQAgAC0AZQBhACAAMAAnADsAIABTADIAIAAkAFIAOgA6AEMAbABhAHMAcwBlAHMAUgBvAG8AdAAgACcAUgB1AG4AQQBzAFQASQAnACAAJwAzADkAJwAgACcAIABzAHQAYQByAHQAIABwAG8AdwBlAHIAcwBoAGUAbABsACAALQBhAHIAZwBzACAAIgAtAHcAaQBuACAAMQAgAC0AbgBvAHAAIAAtAGMAIABgAG4AJABWACAAYAAkAGUAbgB2ADoAUgA9ACgAZwBpACAAYAAkAGsAZQB5ACAALQBlAGEAIAAwACkALgBnAGUAdAB2AGEAbAB1AGUAKABgACQAaQBkACkALQBqAG8AaQBuACcAJwAnACcAOwAgAGkAZQB4ACAAYAAkAGUAbgB2ADoAUgAiACAALQB2AGUAcgBiACAAcgB1AG4AYQBzACcAOwAgAFMAMgAgACQAUgA6ADoAQwBsAGEAcwBzAGUAcwBSAG8AbwB0ACAAJwBSAHUAbgBBAHMAVABJACcAIAAnADQAMAAnACAAJwB9ADsAIAAkAEEAPQAoAFsAZQBuAHYAaQByAG8AbgBtAGUAbgB0AF0AOgA6AGMAbwBtAG0AYQBuAGQAbABpAG4AZQAtAHMAcABsAGkAdAAnACcALQBbAC0AXQAlACsAIAA/ACcAJwAsADIAKQBbADEAXQAtAHMAcABsAGkAdAAnACcAIgAoAFsAXgAiAF0AKwApACIAfAAoAFsAXgAgAF0AKwApACcAJwAsADIAfAAlAHsAJABfAC4AVAByAGkAbQAoACcAJwAgACIAJwAnACkAfQA7ACAAUgB1AG4AQQBzAFQASQAgACQAQQBbADEAXQAgACQAQQBbADIAXQAnAA==
reg add "HKCR\cmdfile\shell\setdesktopwallpaper" /v "MUIVerb" /t REG_SZ /d "Run as TrustedInstaller" /f
reg add "HKCR\cmdfile\shell\setdesktopwallpaper" /v "HasLUAShield" /t REG_SZ /d "" /f
reg add "HKCR\cmdfile\shell\setdesktopwallpaper" /v "Icon" /t REG_SZ /d "powershell.exe,0" /f
reg add "HKCR\exefile\shell\setdesktopwallpaper" /v "MUIVerb" /t REG_SZ /d "Run as TrustedInstaller" /f
reg add "HKCR\exefile\shell\setdesktopwallpaper" /v "HasLUAShield" /t REG_SZ /d "" /f
reg add "HKCR\exefile\shell\setdesktopwallpaper" /v "Icon" /t REG_SZ /d "powershell.exe,0" /f
reg add "HKCR\mscfile\shell\setdesktopwallpaper" /v "MUIVerb" /t REG_SZ /d "Run as TrustedInstaller" /f
reg add "HKCR\mscfile\shell\setdesktopwallpaper" /v "HasLUAShield" /t REG_SZ /d "" /f
reg add "HKCR\mscfile\shell\setdesktopwallpaper" /v "Icon" /t REG_SZ /d "powershell.exe,0" /f
reg add "HKCR\Microsoft.PowerShellScript.1\shell\setdesktopwallpaper" /v "MUIVerb" /t REG_SZ /d "Run as TrustedInstaller" /f
reg add "HKCR\Microsoft.PowerShellScript.1\shell\setdesktopwallpaper" /v "HasLUAShield" /t REG_SZ /d "" /f
reg add "HKCR\Microsoft.PowerShellScript.1\shell\setdesktopwallpaper" /v "Icon" /t REG_SZ /d "powershell.exe,0" /f
reg add "HKCR\Microsoft.PowerShellScript.1\shell\setdesktopwallpaper\command" /v "" /t REG_SZ /d "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe -win 1 -nop -c iex((10..40|%%%%{(gp 'Registry::HKCR\RunAsTI' $_ -ea 0).$_})-join[char]10); # --%%%% powershell -nop -c iex((gc -lit '%%L')-join[char]10)" /f
reg add "HKCR\regfile\shell\setdesktopwallpaper" /v "MUIVerb" /t REG_SZ /d "Import as TrustedInstaller" /f
reg add "HKCR\regfile\shell\setdesktopwallpaper" /v "HasLUAShield" /t REG_SZ /d "" /f
reg add "HKCR\regfile\shell\setdesktopwallpaper" /v "Icon" /t REG_SZ /d "powershell.exe,0" /f
reg add "HKCR\Folder\shell\setdesktopwallpaper" /v "MuiVerb" /t REG_SZ /d "Open as TrustedInstaller" /f
reg add "HKCR\Folder\shell\setdesktopwallpaper" /v "HasLUAShield" /t REG_SZ /d "" /f
reg add "HKCR\Folder\shell\setdesktopwallpaper" /v "Icon" /t REG_SZ /d "powershell.exe,0" /f
reg add "HKCR\RunAsTI" /v "14" /t REG_SZ /d " $F='kernel','advapi','advapi', ($S,$S,$I,$I,$I,$I,$I,$S,$D[7],$D[8]), ([uintptr],$S,$I,$I,$D[9]),([uintptr],$S,$I,$I,[byte[]],$I)" /f
reg add "HKCR\RunAsTI" /v "16" /t REG_SZ /d " $DF=($P,$I,$P),($I,$I,$I,$I,$P,$D[1]),($I,$S,$S,$S,$I,$I,$I,$I,$I,$I,$I,$I,[int16],[int16],$P,$P,$P,$P),($D[3],$P),($P,$P,$I,$I)" /f
reg add "HKCR\RunAsTI" /v "19" /t REG_SZ /d " $TI=(whoami /groups)-like'*1-16-16384*'; $As=0; if(!$cmd) {$cmd='control';$arg='admintools'}; if ($cmd-eq'This PC'){$cmd='file:'}" /f
reg add "HKCR\RunAsTI" /v "20" /t REG_SZ /d " if (!$TI) {'TrustedInstaller','lsass','winlogon'|%% {if (!$As) {$9=sc.exe start $_; $As=@(get-process -name $_ -ea 0|%% {$_})[0]}}" /f
reg add "HKCR\RunAsTI" /v "27" /t REG_SZ /d " $HKU=[uintptr][uint32]2147483651; $NT='S-1-5-18'; $reg=($HKU,$NT,8,2,($HKU -as $D[9])); F 'RegOpenKeyEx' $reg; $LNK=$reg[4]" /f
)NVRXBAT"
R"NVRXBAT(reg add "HKCR\RunAsTI" /v "28" /t REG_SZ /d " function L ($1,$2,$3) {sp 'Registry::HKCR\AppID\{CDCBCFCA-3CDC-436f-A4E2-0E02075250C2}' 'RunAs' $3 -force -ea 0" /f
reg add "HKCR\RunAsTI" /v "32" /t REG_SZ /d " $11bug=($((gwmi Win32_OperatingSystem).BuildNumber)-eq'22000')-AND(($cmd-eq'file:')-OR(test-path -lit $cmd -PathType Container))" /f
reg add "HKCR\RunAsTI" /v "34" /t REG_SZ /d " if ($11bug) {$path='^(l)'+$($cmd -replace '([\+\^\%\~\(\)\[\]])','{$1}')+'{ENTER}'; $cmd='control.exe'; $arg='admintools'}" /f
reg add "HKCR\RunAsTI" /v "35" /t REG_SZ /d " L ($key-split'\\')[1] $LNK ''; $R=[diagnostics.process]::start($cmd,$arg); if ($R) {$R.PriorityClass='High'; $R.WaitForExit()}" /f
reg add "HKCR\RunAsTI" /v "36" /t REG_SZ /d " if ($11bug) {$w=0; do {if($w-gt40){break}; sleep -mi 250;$w++} until (Q); [Microsoft.VisualBasic.Interaction]::AppActivate($(Q))}" /f
reg add "HKCR\RunAsTI" /v "37" /t REG_SZ /d " if ($11bug) {[Windows.Forms.SendKeys]::SendWait($path)}; do {sleep 7} while(Q); L '.Default' $LNK 'Interactive User'" /f
echo [Nvrx] Done: Enable Run As TrustedInstaller Context Menu
exit /b 0
)NVRXBAT";

static const char* S_debloat_edge =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Delete Microsoft Edge
echo [Nvrx] === Delete Microsoft Edge ===
set "SELF=%~f0"
cd /d "%SystemDrive%\"
for %%P in (msedge MicrosoftEdge MicrosoftEdgeCP MicrosoftEdgeSH msedge_proxy) do taskkill /f /im "%%P.exe" >nul 2>&1
for %%H in (HKCU HKLM) do for %%W in (SOFTWARE SOFTWARE\Wow6432Node) do (
    reg delete "%%H\%%W\Microsoft\Windows\CurrentVersion\Uninstall\Microsoft Edge" /v NoRemove /f >nul 2>&1
    reg add "%%H\%%W\Microsoft\EdgeUpdateDev" /v AllowUninstall /t REG_DWORD /d 1 /f >nul 2>&1
)
powershell -nop -ep bypass -c "$L=[IO.File]::ReadAllLines($env:SELF); $a=[Array]::IndexOf($L,'#BEGIN:APPX')+1; $b=[Array]::IndexOf($L,'#END:APPX'); iex (($L[$a..($b-1)]) -join [Environment]::NewLine)"
for %%B in ("%LocalAppData%" "%ProgramFiles(x86)%" "%ProgramFiles%") do call :uninstall "%%~B"
powershell -nop -c "$t=0; while ((Get-Process -Name setup -ErrorAction SilentlyContinue | Where-Object { $_.Path -match '\\Microsoft\\Edge(Core)?\\' }) -and $t++ -lt 60) { Start-Sleep 3 }"
for /f "tokens=8 delims=\" %%i in ('reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\Packages" 2^>nul ^| findstr /i /c:"Microsoft-Windows-Internet-Browser-Package" /c:"Microsoft-Windows-MicrosoftEdgeDevToolsClient-Package" ^| findstr /c:"~~"') do call :cbs "%%i"
winget list --id Microsoft.Edge --exact --accept-source-agreements >nul 2>&1 && winget uninstall --id Microsoft.Edge --exact --silent --accept-source-agreements
del /f /q "%AppData%\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar\Tombstones\Microsoft Edge.lnk" >nul 2>&1
del /f /q "%AppData%\Microsoft\Internet Explorer\Quick Launch\Microsoft Edge.lnk" >nul 2>&1
for %%P in ("HKLM\SOFTWARE\Policies" "HKLM\SOFTWARE" "HKLM\SOFTWARE\WOW6432Node") do (
    reg add "%%~P\Microsoft\EdgeUpdate" /v InstallDefault /t REG_DWORD /d 0 /f >nul 2>&1
    reg add "%%~P\Microsoft\EdgeUpdate" /v "Install{56EB18F8-B008-4CBD-B6D2-8C97FE7E9062}" /t REG_DWORD /d 0 /f >nul 2>&1
    reg add "%%~P\Microsoft\EdgeUpdate" /v "Install{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" /t REG_DWORD /d 1 /f >nul 2>&1
    reg add "%%~P\Microsoft\EdgeUpdate" /v DoNotUpdateToEdgeWithChromium /t REG_DWORD /d 1 /f >nul 2>&1
)
for %%R in ("HKLM\SOFTWARE" "HKLM\SOFTWARE\Wow6432Node") do for %%C in (on-os-upgrade on-logon on-logon-autolaunch on-logon-startup-boost) do reg add "%%~R\Microsoft\EdgeUpdate\Clients\{56EB18F8-B008-4CBD-B6D2-8C97FE7E9062}\Commands\%%C" /v CommandLine /t REG_SZ /d "systray.exe" /f >nul 2>&1

:uninstall
for /d %%D in ("%~1\Microsoft\Edge*") do for /f "delims=" %%F in ('dir /s /b "%%~D\setup.exe" 2^>nul ^| findstr /v /i /c:"EdgeWebView" /c:"EdgeUpdate"') do (
    echo     "%%F"
    start "" /wait "%%F" --uninstall --msedge --system-level --verbose-logging --force-uninstall
)
exit /b

:cbs
set "K=HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\Packages\%~1"
reg add "%K%" /v Visibility /t REG_DWORD /d 1 /f >nul 2>&1
reg delete "%K%\Owners" /va /f >nul 2>&1
dism /online /Remove-Package /PackageName:%~1 /NoRestart >nul 2>&1
exit /b

#BEGIN:APPX
$ErrorActionPreference = 'SilentlyContinue'
## enable the privileges needed to write to the protected AppxAllUserStore keys
$D1=[uri].module.gettype('System.Diagnostics.Process')."GetM`ethods"(42) |where {$_.Name -eq 'SetPrivilege'} #`:no-ev-warn
'SeSecurityPrivilege','SeTakeOwnershipPrivilege','SeBackupPrivilege','SeRestorePrivilege' |foreach {$D1.Invoke($null, @("$_",2))}

$store = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Appx\AppxAllUserStore'
$users = @('S-1-5-18')
if (Test-Path $store) { $users += (Get-ChildItem $store | Where-Object { $_.Name -like '*S-1-5-21*' }).PSChildName }
function Ensure-Key($p) { if (-not (Test-Path $p)) { New-Item $p -Force | Out-Null } }
function Unblock($pfn, $pkg) {
  if ($pfn) {
    Ensure-Key "$store\Deprovisioned\$pfn"
    dism /online /set-nonremovableapppolicy /packagefamily:$pfn /nonremovable:0 | Out-Null
  }
  foreach ($sid in $users) { Ensure-Key "$store\EndOfLife\$sid\$pkg" }
}

$all = Get-AppxPackage -AllUsers
foreach ($p in (Get-AppxProvisionedPackage -Online | Where-Object { $_.PackageName -like '*MicrosoftEdge*' })) {
  Write-Host "    $($p.PackageName)"
  $pfn = ($all | Where-Object { $_.Name -eq $p.DisplayName } | Select-Object -First 1).PackageFamilyName
  Unblock $pfn $p.PackageName
  Remove-AppxProvisionedPackage -PackageName $p.PackageName -Online -AllUsers | Out-Null
}
foreach ($p in ($all | Where-Object { $_.PackageFullName -like '*MicrosoftEdge*' })) {
  Write-Host "    $($p.PackageFullName)"
  Unblock $p.PackageFamilyName $p.PackageFullName
  Remove-AppxPackage -Package $p.PackageFullName -AllUsers | Out-Null
}

$eolroot = "$store\EndOfLife"
if (Test-Path $eolroot) {
  foreach ($sidKey in (Get-ChildItem $eolroot)) {
    foreach ($k in (Get-ChildItem $sidKey.PSPath | Where-Object { $_.PSChildName -like '*MicrosoftEdge*' })) {
      Remove-Item $k.PSPath -Recurse -Force
    }
  }
}
#END:APPX
echo [Nvrx] Done: Delete Microsoft Edge
exit /b 0
)NVRXBAT";

static const char* S_sec_defender_delete =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Delete Microsoft Defender
echo [Nvrx] === Delete Microsoft Defender ===
taskkill /f /im smartscreen.exe >nul 2>&1
taskkill /f /im SecHealthUI.exe >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand JAByAGUAbQBvAHYAZQBfAGEAcABwAHgAIAA9ACAAQAAoACIAUwBlAGMASABlAGEAbAB0AGgAVQBJACIAKQA7ACAAJABwAHIAbwB2AGkAcwBpAG8AbgBlAGQAIAA9ACAAZwBlAHQALQBhAHAAcAB4AHAAcgBvAHYAaQBzAGkAbwBuAGUAZABwAGEAYwBrAGEAZwBlACAALQBvAG4AbABpAG4AZQA7ACAAJABhAHAAcAB4AHAAYQBjAGsAYQBnAGUAIAA9ACAAZwBlAHQALQBhAHAAcAB4AHAAYQBjAGsAYQBnAGUAIAAtAGEAbABsAHUAcwBlAHIAcwA7ACAAJABlAG8AbAAgAD0AIABAACgAKQAKACQAcwB0AG8AcgBlACAAPQAgACcASABLAEwATQA6AFwAUwBPAEYAVABXAEEAUgBFAFwATQBpAGMAcgBvAHMAbwBmAHQAXABXAGkAbgBkAG8AdwBzAFwAQwB1AHIAcgBlAG4AdABWAGUAcgBzAGkAbwBuAFwAQQBwAHAAeABcAEEAcABwAHgAQQBsAGwAVQBzAGUAcgBTAHQAbwByAGUAJwAKACQAdQBzAGUAcgBzACAAPQAgAEAAKAAnAFMALQAxAC0ANQAtADEAOAAnACkAOwAgAGkAZgAgACgAdABlAHMAdAAtAHAAYQB0AGgAIAAkAHMAdABvAHIAZQApACAAewAkAHUAcwBlAHIAcwAgACsAPQAgACQAKAAoAGQAaQByACAAJABzAHQAbwByAGUAIAAtAGUAYQAgADAAIAB8AHcAaABlAHIAZQAgAHsAJABfACAALQBsAGkAawBlACAAJwAqAFMALQAxAC0ANQAtADIAMQAqACcAfQApAC4AUABTAEMAaABpAGwAZABOAGEAbQBlACkAfQAKAGYAbwByAGUAYQBjAGgAIAAoACQAYwBoAG8AaQBjAGUAIABpAG4AIAAkAHIAZQBtAG8AdgBlAF8AYQBwAHAAeAApACAAewAgAGkAZgAgACgAJwAnACAALQBlAHEAIAAkAGMAaABvAGkAYwBlAC4AVAByAGkAbQAoACkAKQAgAHsAYwBvAG4AdABpAG4AdQBlAH0ACgAgACAAZgBvAHIAZQBhAGMAaAAgACgAJABhAHAAcAB4ACAAaQBuACAAJAAoACQAcAByAG8AdgBpAHMAaQBvAG4AZQBkACAAfAB3AGgAZQByAGUAIAB7ACQAXwAuAFAAYQBjAGsAYQBnAGUATgBhAG0AZQAgAC0AbABpAGsAZQAgACIAKgAkAGMAaABvAGkAYwBlACoAIgB9ACkAKQAgAHsACgAgACAAIAAgACQAbgBlAHgAdAAgAD0AIAAkAGYAYQBsAHMAZQA7ACAAZgBvAHIAZQBhAGMAaAAgACgAJABuAG8AIABpAG4AIAAkAHMAawBpAHAAKQAgAHsAaQBmACAAKAAkAGEAcABwAHgALgBQAGEAYwBrAGEAZwBlAE4AYQBtAGUAIAAtAGwAaQBrAGUAIAAiACoAJABuAG8AKgAiACkAIAB7ACQAbgBlAHgAdAAgAD0AIAAkAHQAcgB1AGUAfQB9ACAAOwAgAGkAZgAgACgAJABuAGUAeAB0ACkAIAB7AGMAbwBuAHQAaQBuAHUAZQB9AAoAIAAgACAAIAAkAFAAYQBjAGsAYQBnAGUATgBhAG0AZQAgAD0AIAAkAGEAcABwAHgALgBQAGEAYwBrAGEAZwBlAE4AYQBtAGUAOwAgACQAUABhAGMAawBhAGcAZQBGAGEAbQBpAGwAeQBOAGEAbQBlACAAPQAgACgAJABhAHAAcAB4AHAAYQBjAGsAYQBnAGUAIAB8AHcAaABlAHIAZQAgAHsAJABfAC4ATgBhAG0AZQAgAC0AZQBxACAAJABhAHAAcAB4AC4ARABpAHMAcABsAGEAeQBOAGEAbQBlAH0AKQAuAFAAYQBjAGsAYQBnAGUARgBhAG0AaQBsAHkATgBhAG0AZQAKACAAIAAgACAAbgBpACAAIgAkAHMAdABvAHIAZQBcAEQAZQBwAHIAbwB2AGkAcwBpAG8AbgBlAGQAXAAkAFAAYQBjAGsAYQBnAGUARgBhAG0AaQBsAHkATgBhAG0AZQAiACAALQBmAG8AcgBjAGUAIAB8ACAATwB1AHQALQBOAHUAbABsADsAIAAkAFAAYQBjAGsAYQBnAGUARgBhAG0AaQBsAHkATgBhAG0AZQAKACAAIAAgACAAZgBvAHIAZQBhAGMAaAAgACgAJABzAGkAZAAgAGkAbgAgACQAdQBzAGUAcgBzACkAIAB7AG4AaQAgACIAJABzAHQAbwByAGUAXABFAG4AZABPAGYATABpAGYAZQBcACQAcwBpAGQAXAAkAFAAYQBjAGsAYQBnAGUATgBhAG0AZQAiACAALQBmAG8AcgBjAGUAIAB8ACAATwB1AHQALQBOAHUAbABsAH0AIAA7ACAAJABlAG8AbAAgACsAPQAgACQAUABhAGMAawBhAGcAZQBOAGEAbQBlAAoAIAAgACAAIABkAGkAcwBtACAALwBvAG4AbABpAG4AZQAgAC8AcwBlAHQALQBuAG8AbgByAGUAbQBvAHYAYQBiAGwAZQBhAHAAcABwAG8AbABpAGMAeQAgAC8AcABhAGMAawBhAGcAZQBmAGEAbQBpAGwAeQA6ACQAUABhAGMAawBhAGcAZQBGAGEAbQBpAGwAeQBOAGEAbQBlACAALwBuAG8AbgByAGUAbQBvAHYAYQBiAGwAZQA6ADAAIAB8ACAATwB1AHQALQBOAHUAbABsAAoAIAAgACAAIAByAGUAbQBvAHYAZQAtAGEAcABwAHgAcAByAG8AdgBpAHMAaQBvAG4AZQBkAHAAYQBjAGsAYQBnAGUAIAAtAHAAYQBjAGsAYQBnAGUAbgBhAG0AZQAgACQAUABhAGMAawBhAGcAZQBOAGEAbQBlACAALQBvAG4AbABpAG4AZQAgAC0AYQBsAGwAdQBzAGUAcgBzACAAfAAgAE8AdQB0AC0ATgB1AGwAbAAKACAAIAB9AAoAIAAgAGYAbwByAGUAYQBjAGgAIAAoACQAYQBwAHAAeAAgAGkAbgAgACQAKAAkAGEAcABwAHgAcABhAGMAawBhAGcAZQAgAHwAdwBoAGUAcgBlACAAewAkAF8ALgBQAGEAYwBrAGEAZwBlAEYAdQBsAGwATgBhAG0AZQAgAC0AbABpAGsAZQAgACIAKgAkAGMAaABvAGkAYwBlACoAIgB9ACkAKQAgAHsACgAgACAAIAAgACQAbgBlAHgAdAAgAD0AIAAkAGYAYQBsAHMAZQA7ACAAZgBvAHIAZQBhAGMAaAAgACgAJABuAG8AIABpAG4AIAAkAHMAawBpAHAAKQAgAHsAaQBmACAAKAAkAGEAcABwAHgALgBQAGEAYwBrAGEAZwBlAEYAdQBsAGwATgBhAG0AZQAgAC0AbABpAGsAZQAgACIAKgAkAG4AbwAqACIAKQAgAHsAJABuAGUAeAB0ACAAPQAgACQAdAByAHUAZQB9AH0AIAA7ACAAaQBmACAAKAAkAG4AZQB4AHQAKQAgAHsAYwBvAG4AdABpAG4AdQBlAH0ACgAgACAAIAAgACQAUABhAGMAawBhAGcAZQBGAHUAbABsAE4AYQBtAGUAIAA9ACAAJABhAHAAcAB4AC4AUABhAGMAawBhAGcAZQBGAHUAbABsAE4AYQBtAGUACgAgACAAIAAgAG4AaQAgACIAJABzAHQAbwByAGUAXABEAGUAcAByAG8AdgBpAHMAaQBvAG4AZQBkAFwAJABhAHAAcAB4AC4AUABhAGMAawBhAGcAZQBGAGEAbQBpAGwAeQBOAGEAbQBlACIAIAAtAGYAbwByAGMAZQAgAHwAIABPAHUAdAAtAE4AdQBsAGwAOwAgACQAUABhAGMAawBhAGcAZQBGAHUAbABsAE4AYQBtAGUACgAgACAAIAAgAGYAbwByAGUAYQBjAGgAIAAoACQAcwBpAGQAIABpAG4AIAAkAHUAcwBlAHIAcwApACAAewBuAGkAIAAiACQAcwB0AG8AcgBlAFwARQBuAGQATwBmAEwAaQBmAGUAXAAkAHMAaQBkAFwAJABQAGEAYwBrAGEAZwBlAEYAdQBsAGwATgBhAG0AZQAiACAALQBmAG8AcgBjAGUAIAB8ACAATwB1AHQALQBOAHUAbABsAH0AIAA7ACAAJABlAG8AbAAgACsAPQAgACQAUABhAGMAawBhAGcAZQBGAHUAbABsAE4AYQBtAGUACgAgACAAIAAgAGQAaQBzAG0AIAAvAG8AbgBsAGkAbgBlACAALwBzAGUAdAAtAG4AbwBuAHIAZQBtAG8AdgBhAGIAbABlAGEAcABwAHAAbwBsAGkAYwB5ACAALwBwAGEAYwBrAGEAZwBlAGYAYQBtAGkAbAB5ADoAJABQAGEAYwBrAGEAZwBlAEYAYQBtAGkAbAB5AE4AYQBtAGUAIAAvAG4AbwBuAHIAZQBtAG8AdgBhAGIAbABlADoAMAAgAHwAIABPAHUAdAAtAE4AdQBsAGwACgAgACAAIAAgAHIAZQBtAG8AdgBlAC0AYQBwAHAAeABwAGEAYwBrAGEAZwBlACAALQBwAGEAYwBrAGEAZwBlACAAJABQAGEAYwBrAGEAZwBlAEYAdQBsAGwATgBhAG0AZQAgAC0AYQBsAGwAdQBzAGUAcgBzACAAfAAgAE8AdQB0AC0ATgB1AGwAbAAKACAAIAB9AAoAfQA=
reg add "HKLM\SOFTWARE\Microsoft\WindowsMitigation" /v "UserPreference" /t REG_DWORD /d 2 /f >nul
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" /v "MitigationAuditOptions" /t REG_BINARY /d 000000000000202200000000000000200000000000000000 /f >nul
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" /v "MitigationOptions" /t REG_BINARY /d 002222202220222220000000002000200000000000000000 /f >nul
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" /v "KernelSEHOPEnabled" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SYSTEM\CurrentControlSet\Control\SCMConfig" /v "EnableSvchostMitigationPolicy" /t REG_QWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Features" /v "MpPlatformKillbitsFromEngine" /t REG_BINARY /d 0000000000000000 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Features" /v "TamperProtectionSource" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Features" /v "MpCapability" /t REG_BINARY /d 0000000000000000 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Features" /v "TamperProtection" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v "RunAsPPL" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Lsa" /v "LsaConfigFlags" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Lsa" /v "RunAsPPL" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Lsa" /v "RunAsPPLBoot" /t REG_DWORD /d 0 /f >nul
reg delete "HKLM\SYSTEM\CurrentControlSet\Control\Lsa" /v "LmCompatibilityLevel" /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Control\CI\Config" /v "VulnerableDriverBlocklistEnable" /t REG_DWORD /d 0 /f >nul
reg add "HKCU\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\microsoft.microsoftedge_8wekyb3d8bbwe\MicrosoftEdge\PhishingFilter" /v "EnabledV9" /t REG_DWORD /d 0 /f >nul
reg add "HKCU\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\microsoft.microsoftedge_8wekyb3d8bbwe\MicrosoftEdge\PhishingFilter" /v "PreventOverride" /t REG_DWORD /d 0 /f >nul
reg add "HKCU\Software\Microsoft\Edge" /v "SmartScreenEnabled" /t REG_DWORD /d 0 /f >nul
reg add "HKCU\Software\Microsoft\Edge\SmartScreenEnabled" /ve /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" /v "SmartScreenEnabled" /t REG_SZ /d "off" /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v "EnableSmartScreen" /t REG_DWORD /d 0 /f >nul
reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v "ShellSmartScreenLevel" /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Browser\AllowSmartScreen" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\SmartScreen\EnableSmartScreenInShell" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\SmartScreen\EnableAppInstallControl" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\SmartScreen\PreventOverrideForFilesInShell" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\AppHost" /v "EnableWebContentEvaluation" /t REG_DWORD /d 0 /f >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\AppHost" /v "PreventOverride" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\SmartScreen" /v "ConfigureAppInstallControlEnabled" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\SmartScreen" /v "ConfigureAppInstallControl" /t REG_SZ /d "Anywhere" /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /v "DisableRoutinelyTakingAction" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /v "ServiceKeepAlive" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /v "AllowFastServiceStartup" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /v "DisableLocalAdminMerge" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v "LocalSettingOverrideDisableOnAccessProtection" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v "LocalSettingOverrideRealtimeScanDirection" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v "LocalSettingOverrideDisableIOAVProtection" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v "LocalSettingOverrideDisableBehaviorMonitoring" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v "LocalSettingOverrideDisableIntrusionPreventionSystem" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v "LocalSettingOverrideDisableRealtimeMonitoring" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v "DisableIOAVProtection" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v "DisableRealtimeMonitoring" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v "DisableBehaviorMonitoring" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v "DisableOnAccessProtection" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v "DisableScanOnRealtimeEnable" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v "RealtimeScanDirection" /t REG_DWORD /d 2 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v "DisableInformationProtectionControl" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v "DisableIntrusionPreventionSystem" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v "DisableRawWriteNotification" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\AllowBehaviorMonitoring" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\WOW6432Node\Policies\Microsoft\Windows Defender" /v "DisableRoutinelyTakingAction" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Spynet" /v "DisableBlockAtFirstSeen" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Spynet" /v "LocalSettingOverrideSpynetReporting" /t REG_DWORD /d 0 /f >nul
)NVRXBAT"
R"NVRXBAT(reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Spynet" /v "SpynetReporting" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Spynet" /v "SubmitSamplesConsent" /t REG_DWORD /d 2 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Microsoft Antimalware\SpyNet" /v "SpyNetReporting" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Microsoft Antimalware\SpyNet" /v "LocalSettingOverrideSpyNetReporting" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\RemovalTools\MpGears" /v "HeartbeatTrackingIndex" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\RemovalTools\MpGears" /v "SpyNetReportingLocation" /t REG_SZ /d "0" /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /v "PUAProtection" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /v "DisableAntiSpyware" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /v "RandomizeScheduleTaskTimes" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\AllowIOAVProtection" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\AllowArchiveScanning" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\AllowCloudProtection" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\AllowEmailScanning" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\AllowFullScanOnMappedNetworkDrives" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\AllowFullScanRemovableDriveScanning" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\AllowIntrusionPreventionSystem" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\AllowOnAccessProtection" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\AllowRealtimeMonitoring" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\AllowScanningNetworkFiles" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\AllowScriptScanning" /v "value" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\AllowUserUIAccess" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\AvgCPULoadFactor" /v "value" /t REG_DWORD /d 50 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\CheckForSignaturesBeforeRunningScan" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\CloudBlockLevel" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\CloudExtendedTimeout" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\DaysToRetainCleanedMalware" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\DisableCatchupFullScan" /v "value" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\DisableCatchupQuickScan" /v "value" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\EnableControlledFolderAccess" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\EnableLowCPUPriority" /v "value" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\EnableNetworkProtection" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\PUAProtection" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\RealTimeScanDirection" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\ScanParameter" /v "value" /t REG_DWORD /d 2 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\ScheduleScanDay" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\ScheduleScanTime" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\SignatureUpdateInterval" /v "value" /t REG_DWORD /d 24 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Defender\SubmitSamplesConsent" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions" /v "DisableAutoExclusions" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\MpEngine" /v "MpEnablePus" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\MpEngine" /v "MpCloudBlockLevel" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\MpEngine" /v "MpBafsExtendedTimeout" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\MpEngine" /v "EnableFileHashComputation" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\NIS\Consumers\IPS" /v "ThrottleDetectionEventsRate" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\NIS\Consumers\IPS" /v "DisableSignatureRetirement" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\NIS\Consumers\IPS" /v "DisableProtocolRecognition" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Policy Manager" /v "DisableScanningNetworkFiles" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v "IOAVMaxSize" /t REG_DWORD /d 512 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Scan" /v "LowCpuPriority" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Scan" /v "DisableRestorePoint" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Scan" /v "DisableArchiveScanning" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Scan" /v "DisableScanningNetworkFiles" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Scan" /v "DisableCatchupFullScan" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Scan" /v "DisableCatchupQuickScan" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Scan" /v "DisableEmailScanning" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Scan" /v "DisableHeuristics" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Scan" /v "DisableReparsePointScanning" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Signature Updates" /v "SignatureDisableNotification" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Signature Updates" /v "RealtimeSignatureDelivery" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Signature Updates" /v "ForceUpdateFromMU" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Signature Updates" /v "DisableScheduledSignatureUpdateOnBattery" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Signature Updates" /v "UpdateOnStartUp" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Signature Updates" /v "SignatureUpdateCatchupInterval" /t REG_DWORD /d 2 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Signature Updates" /v "DisableUpdateOnStartupWithoutEngine" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Signature Updates" /v "ScheduleTime" /t REG_DWORD /d 1440 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Signature Updates" /v "DisableScanOnUpdate" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\UX Configuration" /v "SuppressRebootNotification" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Windows Defender Exploit Guard\Controlled Folder Access" /v "EnableControlledFolderAccess" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Windows Defender Exploit Guard\Network Protection" /v "EnableNetworkProtection" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Reporting" /v "DisableEnhancedNotifications" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Reporting" /v "DisableGenericRePorts" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Reporting" /v "WppTracingLevel" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Reporting" /v "WppTracingComponents" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Microsoft Antimalware" /v "ServiceKeepAlive" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Microsoft Antimalware" /v "AllowFastServiceStartup" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Microsoft Antimalware" /v "DisableRoutinelyTakingAction" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Microsoft Antimalware" /v "DisableAntiSpyware" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Microsoft Antimalware" /v "DisableAntiVirus" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SYSTEM\CurrentControlSet\Control\CI\Policy" /v "VerifiedAndReputablePolicyState" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\WindowsDefenderSecurityCenter\DisableEnhancedNotifications" /v "value" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\WindowsDefenderSecurityCenter\DisableNotifications" /v "value" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\WindowsDefenderSecurityCenter\HideWindowsSecurityNotificationAreaControl" /v "value" /t REG_DWORD /d 1 /f >nul
reg delete "HKLM\SOFTWARE\Microsoft\Security Center" /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Security Center" /v "FirstRunDisabled" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\Security Center" /v "AntiVirusOverride" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\Security Center" /v "FirewallOverride" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications" /v "DisableEnhancedNotifications" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications" /v "DisableNotifications" /t REG_DWORD /d 1 /f >nul
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Notifications\Settings\Windows.SystemToast.SecurityAndMaintenance" /v "Enabled" /t REG_DWORD /d 0 /f >nul
reg delete "HKLM\Software\Classes\WOW6432Node\CLSID\{2781761E-28E0-4109-99FE-B9D127C57AFE}" /f >nul 2>&1
reg delete "HKLM\Software\Classes\WOW6432Node\CLSID\{2781761E-28E2-4109-99FE-B9D127C57AFE}" /f >nul 2>&1
reg delete "HKLM\Software\Classes\WOW6432Node\CLSID\{195B4D07-3DE2-4744-BBF2-D90121AE785B}" /f >nul 2>&1
reg delete "HKLM\Software\Classes\WOW6432Node\CLSID\{361290c0-cb1b-49ae-9f3e-ba1cbe5dab35}" /f >nul 2>&1
reg delete "HKLM\Software\Classes\WOW6432Node\CLSID\{45F2C32F-ED16-4C94-8493-D72EF93A051B}" /f >nul 2>&1
reg delete "HKLM\Software\Classes\WOW6432Node\CLSID\{6CED0DAA-4CDE-49C9-BA3A-AE163DC3D7AF}" /f >nul 2>&1
reg delete "HKLM\Software\Classes\WOW6432Node\CLSID\{8a696d12-576b-422e-9712-01b9dd84b446}" /f >nul 2>&1
)NVRXBAT"
R"NVRXBAT(reg delete "HKLM\Software\Classes\WOW6432Node\CLSID\{8C9C0DB7-2CBA-40F1-AFE0-C55740DD91A0}" /f >nul 2>&1
reg delete "HKLM\Software\Classes\WOW6432Node\CLSID\{A2D75874-6750-4931-94C1-C99D3BC9D0C7}" /f >nul 2>&1
reg delete "HKLM\Software\Classes\WOW6432Node\CLSID\{A7C452EF-8E9F-42EB-9F2B-245613CA0DC9}" /f >nul 2>&1
reg delete "HKLM\Software\Classes\WOW6432Node\CLSID\{DACA056E-216A-4FD1-84A6-C306A017ECEC}" /f >nul 2>&1
reg delete "HKLM\Software\Classes\WOW6432Node\CLSID\{E3C9166D-1D39-4D4E-A45D-BC7BE9B00578}" /f >nul 2>&1
reg delete "HKLM\Software\Classes\WOW6432Node\CLSID\{F6976CF5-68A8-436C-975A-40BE53616D59}" /f >nul 2>&1
reg delete "HKLM\Software\Classes\CLSID\{2781761E-28E0-4109-99FE-B9D127C57AFE}" /f >nul 2>&1
reg delete "HKLM\Software\Classes\CLSID\{2781761E-28E2-4109-99FE-B9D127C57AFE}" /f >nul 2>&1
reg delete "HKLM\Software\Classes\CLSID\{195B4D07-3DE2-4744-BBF2-D90121AE785B}" /f >nul 2>&1
reg delete "HKLM\Software\Classes\CLSID\{361290c0-cb1b-49ae-9f3e-ba1cbe5dab35}" /f >nul 2>&1
reg delete "HKLM\Software\Classes\CLSID\{45F2C32F-ED16-4C94-8493-D72EF93A051B}" /f >nul 2>&1
reg delete "HKLM\Software\Classes\CLSID\{6CED0DAA-4CDE-49C9-BA3A-AE163DC3D7AF}" /f >nul 2>&1
reg delete "HKLM\Software\Classes\CLSID\{8a696d12-576b-422e-9712-01b9dd84b446}" /f >nul 2>&1
reg delete "HKLM\Software\Classes\CLSID\{8C9C0DB7-2CBA-40F1-AFE0-C55740DD91A0}" /f >nul 2>&1
reg delete "HKLM\Software\Classes\CLSID\{A2D75874-6750-4931-94C1-C99D3BC9D0C7}" /f >nul 2>&1
reg delete "HKLM\Software\Classes\CLSID\{A7C452EF-8E9F-42EB-9F2B-245613CA0DC9}" /f >nul 2>&1
reg delete "HKLM\Software\Classes\CLSID\{DACA056E-216A-4FD1-84A6-C306A017ECEC}" /f >nul 2>&1
reg delete "HKLM\Software\Classes\CLSID\{E3C9166D-1D39-4D4E-A45D-BC7BE9B00578}" /f >nul 2>&1
reg delete "HKLM\Software\Classes\CLSID\{F6976CF5-68A8-436C-975A-40BE53616D59}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\WOW6432Node\CLSID\{2781761E-28E0-4109-99FE-B9D127C57AFE}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\WOW6432Node\CLSID\{2781761E-28E2-4109-99FE-B9D127C57AFE}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\WOW6432Node\CLSID\{195B4D07-3DE2-4744-BBF2-D90121AE785B}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\WOW6432Node\CLSID\{361290c0-cb1b-49ae-9f3e-ba1cbe5dab35}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\WOW6432Node\CLSID\{45F2C32F-ED16-4C94-8493-D72EF93A051B}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\WOW6432Node\CLSID\{6CED0DAA-4CDE-49C9-BA3A-AE163DC3D7AF}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\WOW6432Node\CLSID\{8a696d12-576b-422e-9712-01b9dd84b446}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\WOW6432Node\CLSID\{8C9C0DB7-2CBA-40F1-AFE0-C55740DD91A0}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\WOW6432Node\CLSID\{A2D75874-6750-4931-94C1-C99D3BC9D0C7}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\WOW6432Node\CLSID\{A7C452EF-8E9F-42EB-9F2B-245613CA0DC9}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\WOW6432Node\CLSID\{DACA056E-216A-4FD1-84A6-C306A017ECEC}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\WOW6432Node\CLSID\{E3C9166D-1D39-4D4E-A45D-BC7BE9B00578}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\WOW6432Node\CLSID\{F6976CF5-68A8-436C-975A-40BE53616D59}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\CLSID\{2781761E-28E0-4109-99FE-B9D127C57AFE}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\CLSID\{2781761E-28E2-4109-99FE-B9D127C57AFE}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\CLSID\{195B4D07-3DE2-4744-BBF2-D90121AE785B}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\CLSID\{361290c0-cb1b-49ae-9f3e-ba1cbe5dab35}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\CLSID\{45F2C32F-ED16-4C94-8493-D72EF93A051B}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\CLSID\{6CED0DAA-4CDE-49C9-BA3A-AE163DC3D7AF}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\CLSID\{8a696d12-576b-422e-9712-01b9dd84b446}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\CLSID\{8C9C0DB7-2CBA-40F1-AFE0-C55740DD91A0}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\CLSID\{A2D75874-6750-4931-94C1-C99D3BC9D0C7}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\CLSID\{A7C452EF-8E9F-42EB-9F2B-245613CA0DC9}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\CLSID\{DACA056E-216A-4FD1-84A6-C306A017ECEC}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\CLSID\{E3C9166D-1D39-4D4E-A45D-BC7BE9B00578}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\CLSID\{F6976CF5-68A8-436C-975A-40BE53616D59}" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DefenderAuditLogger" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DefenderApiLogger" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tasks\{0ACC9108-2000-46C0-8407-5FD9F89521E8}" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tasks\{1D77BCC8-1D07-42D0-8C89-3A98674DFB6F}" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tasks\{4A9233DB-A7D3-45D6-B476-8C7D8DF73EB5}" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tasks\{B05F34EE-83F2-413D-BC1D-7D5BD6E98300}" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\MsSecCore" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\wscsvc" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\WdNisDrv" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\WdNisSvc" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\WdFilter" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\WdBoot" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\SgrmAgent" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\SgrmBroker" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\WinDefend" /f >nul 2>&1
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\App and Browser protection" /v "DisallowExploitProtectionOverride" /t REG_DWORD /d 1 /f >nul
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\MsSecFlt" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\MsSecWfp" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\whesvc" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\WindowsRuntime\Server\WebThreatDefSvc" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\webthreatdefsvc" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\webthreatdefusersvc" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Svchost\WebThreatDefense" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\PlutonHsp2" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\PlutonHeci" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\Hsp" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\WinDefend" /f >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\Shell\Associations\UrlAssociations\windowsdefender" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Classes\AppUserModelId\Windows.Defender" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Classes\AppUserModelId\Microsoft.Windows.Defender" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\AppX9kvz3rdv8t7twanaezbwfcdgrbg3bck0" /f >nul 2>&1
reg delete "HKCU\Software\Classes\ms-cxh" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\Local Settings\MrtCache\C:%5CWindows%5CSystemApps%5CMicrosoft.Windows.AppRep.ChxApp_cw5n1h2txyewy%5Cresources.pri" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\WindowsDefender" /f >nul 2>&1
reg delete "HKCU\Software\Classes\AppX9kvz3rdv8t7twanaezbwfcdgrbg3bck0" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Classes\WindowsDefender" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Control\Ubpm" /v "CriticalMaintenance_DefenderCleanup" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Control\Ubpm" /v "CriticalMaintenance_DefenderVerification" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\RestrictedServices\Static\System" /v "WindowsDefender-1" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\RestrictedServices\Static\System" /v "WindowsDefender-2" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\RestrictedServices\Static\System" /v "WindowsDefender-3" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Explorer\ShellServiceObjects\{900c0763-5cad-4a34-bc1f-40cd513679d5}" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\ShellServiceObjects\{900c0763-5cad-4a34-bc1f-40cd513679d5}" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows Defender" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\Folder\shell\WindowsDefender" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\DesktopBackground\Shell\WindowsSecurity" /f >nul 2>&1
reg delete "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "Windows Defender" /f >nul 2>&1
reg delete "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "SecurityHealth" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run" /v "Windows Defender" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run" /v "SecurityHealth" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "WindowsDefender" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "SecurityHealth" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\CLSID\{E48B2549-D510-4A76-8A5F-FC126A6215F0}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\WOW6432Node\CLSID\{E48B2549-D510-4A76-8A5F-FC126A6215F0}" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Classes\CLSID\{E48B2549-D510-4A76-8A5F-FC126A6215F0}" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Classes\WOW6432Node\CLSID\{E48B2549-D510-4A76-8A5F-FC126A6215F0}" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\WindowsRuntime\ActivatableClassId\Microsoft.OneCore.WebThreatDefense.Service.UserSessionServiceManager" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\WindowsRuntime\ActivatableClassId\Microsoft.OneCore.WebThreatDefense.ThreatExperienceManager.ThreatExperienceManager" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\WindowsRuntime\ActivatableClassId\Microsoft.OneCore.WebThreatDefense.ThreatResponseEngine.ThreatDecisionEngine" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\WindowsRuntime\ActivatableClassId\Microsoft.OneCore.WebThreatDefense.Configuration.WTDUserSettings" /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\WebThreatDefense\AuditMode" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\WebThreatDefense\NotifyUnsafeOrReusedPassword" /v "value" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\default\WebThreatDefense\ServiceEnabled" /v "value" /t REG_DWORD /d 0 /f >nul
reg delete "HKLM\SOFTWARE\Microsoft\PolicyManager\default\WebThreatDefense" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\webthreatdefsvc" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\webthreatdefusersvc" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Svchost\WebThreatDefense" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Svchost" /v "WebThreatDefense" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\RestrictedServices\Static\System" /v "WebThreatDefSvc_Allow_In" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\RestrictedServices\Static\System" /v "WebThreatDefSvc_Allow_Out" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\RestrictedServices\Static\System" /v "WebThreatDefSvc_Block_In" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\RestrictedServices\Static\System" /v "WebThreatDefSvc_Block_Out" /f >nul 2>&1
)NVRXBAT"
R"NVRXBAT(reg delete "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\RestrictedServices\Configurable\System" /v "{2A5FE97D-01A4-4A9C-8241-BB3755B65EE0}" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\RestrictedServices\Configurable\System" /v "72e33e44-dc4c-40c5-a688-a77b6e988c69" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\RestrictedServices\Configurable\System" /v "b23879b5-1ef3-45b7-8933-554a4303d2f3" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\WTDS" /f >nul 2>&1
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WTDS\Components" /v "NotifyPasswordReuse" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WTDS\Components" /v "NotifyMalicious" /t REG_DWORD /d 0 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v "SettingsPageVisibility" /t REG_SZ /d "hide:windowsdefender;" /f >nul
reg delete "HKLM\SOFTWARE\Microsoft\Windows Security Health" /f >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows Security Health" /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows Security Health\State" /v "Disabled" /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\Windows Security Health\Platform" /v "Registered" /t REG_DWORD /d 0 /f >nul
reg delete "HKEY_CLASSES_ROOT\CLSID\{BB64F8A7-BEE7-4E1A-AB8D-7D8273F7FDB6}" /f >nul 2>&1
reg delete "HKEY_CLASSES_ROOT\WOW6432Node\CLSID\{BB64F8A7-BEE7-4E1A-AB8D-7D8273F7FDB6}" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Classes\CLSID\{BB64F8A7-BEE7-4E1A-AB8D-7D8273F7FDB6}" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Classes\WOW6432Node\CLSID\{BB64F8A7-BEE7-4E1A-AB8D-7D8273F7FDB6}" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{BB64F8A7-BEE7-4E1A-AB8D-7D8273F7FDB6}" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\WOW6432Node\Classes\CLSID\{BB64F8A7-BEE7-4E1A-AB8D-7D8273F7FDB6}" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{BB64F8A7-BEE7-4E1A-AB8D-7D8273F7FDB6}" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\SecurityHealthService" /f >nul 2>&1
for %%f in ("%windir%\System32\smartscreen.exe" "%windir%\System32\smartscreen.dll" "%windir%\System32\smartscreenps.dll") do (
    if exist "%%~f" (
        takeown /f "%%~f" /a >nul 2>&1
        icacls "%%~f" /grant administrators:F >nul 2>&1
        del /f /q "%%~f" 2>nul
        if exist "%%~f" (echo WARNING: could not delete %%~f) else (echo Removed: %%~f)
    )
)
for %%d in (
    "C:\ProgramData\Microsoft\Windows Defender"
    "C:\Program Files\Windows Defender"
    "C:\Program Files (x86)\Windows Defender"
    "C:\Program Files\Windows Defender Advanced Threat Protection"
) do (
    if exist %%d (
        takeown /f %%d /r /d y >nul 2>&1
        icacls %%d /grant administrators:F /t >nul 2>&1
        rd /s /q %%d 2>nul
    )
)
echo [Nvrx] Done: Delete Microsoft Defender
exit /b 0
)NVRXBAT";

static const char* S_sys_print_spooler =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Disable Printer/Spooler
echo [Nvrx] === Disable Printer/Spooler ===
sc config Spooler start= disabled
sc config printworkflowusersvc start= disabled
sc config stisvc start= disabled
sc config PrintNotify start= disabled
sc config usbprint start= disabled
sc config PrintScanBrokerService start= disabled
sc config PrintDeviceConfigurationService start= disabled
sc config LPTEnum start= disabled
sc config Parallel start= disabled
echo [Nvrx] Done: Disable Printer/Spooler
exit /b 0
)NVRXBAT";

static const char* S_sys_bluetooth =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Disable Bluetooth
echo [Nvrx] === Disable Bluetooth ===
sc config BluetoothUserService start= disabled
sc config BthAvctpSvc start= disabled
sc config BthEnum start= disabled
sc config BthHFEnum start= disabled
sc config BthLEEnum start= disabled
sc config BthA2dp start= disabled
sc config BTHMODEM start= disabled
sc config Microsoft_Bluetooth_AvrcpTransport start= disabled
sc config RFCOMM start= disabled
sc config bthserv start= disabled
sc config BTAGService start= disabled
sc config BluetoothAudioSvc start= disabled
sc config BthMini start= disabled
sc config BthRadUsb start= disabled
sc config Microsoft_Bluetooth_AvctpTransport start= disabled
echo [Nvrx] Done: Disable Bluetooth
exit /b 0
)NVRXBAT";

static const char* S_debloat_pchealth =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Remove PC Health Check
echo [Nvrx] === Remove PC Health Check ===
if exist "%ProgramW6432%\PCHealthCheck" (
    rmdir /s /q "%ProgramW6432%\PCHealthCheck"
)
echo [Nvrx] Done: Remove PC Health Check
exit /b 0
)NVRXBAT";

static const char* S_sec_firewall =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Disable Windows Firewall
echo [Nvrx] === Disable Windows Firewall ===
reg add "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile" /v EnableFirewall /t REG_DWORD /d 0 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile" /v EnableFirewall /t REG_DWORD /d 0 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\PublicProfile" /v EnableFirewall /t REG_DWORD /d 0 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile" /v DisableNotifications /t REG_DWORD /d 1 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile" /v DisableNotifications /t REG_DWORD /d 1 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\PublicProfile" /v DisableNotifications /t REG_DWORD /d 1 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile" /v DoNotAllowExceptions /t REG_DWORD /d 1 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile" /v DoNotAllowExceptions /t REG_DWORD /d 1 /f
reg add "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\PublicProfile" /v DoNotAllowExceptions /t REG_DWORD /d 1 /f
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\FirewallRules" /f
echo [Nvrx] Done: Disable Windows Firewall
exit /b 0
)NVRXBAT";

static const char* S_debloat_xbox =
R"NVRXBAT(@echo off
chcp 65001 >nul 2>&1
title Nvrx - Disable XBOX
echo [Nvrx] === Disable XBOX ===
sc config XboxGipSvc start=disabled
sc config XblAuthManager start=disabled
sc config XblGameSave start=disabled
sc config XboxNetApiSvc start=disabled
sc config BcastDVRUserService start=disabled
powershell -Command "$packages = '*Microsoft.Xbox*', '*Microsoft.GamingApp*', '*Microsoft.XboxApp*'; foreach ($p in $packages) { Get-AppxPackage -AllUsers -Name $p | Remove-AppxPackage -ErrorAction SilentlyContinue; Get-AppxProvisionedPackage -Online | Where-Object DisplayName -like $p | Remove-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue }"
powershell -Command "Get-ScheduledTask | Where-Object { $_.TaskPath -match '\\Microsoft\\XblGameSave\\' } | Disable-ScheduledTask -ErrorAction SilentlyContinue"
echo [Nvrx] Done: Disable XBOX
exit /b 0
)NVRXBAT";

const char* tweak_script(const char* id) {
    if (!id || !*id) return nullptr;
    if (std::strcmp(id, "perf_win32priority") == 0) return S_perf_win32priority;
    if (std::strcmp(id, "perf_mmcss") == 0) return S_perf_mmcss;
    if (std::strcmp(id, "perf_fth") == 0) return S_perf_fth;
    if (std::strcmp(id, "perf_hags") == 0) return S_perf_hags;
    if (std::strcmp(id, "perf_gamebar_dvr") == 0) return S_perf_gamebar_dvr;
    if (std::strcmp(id, "perf_fse") == 0) return S_perf_fse;
    if (std::strcmp(id, "perf_gamemode") == 0) return S_perf_gamemode;
    if (std::strcmp(id, "perf_windowed_opt") == 0) return S_perf_windowed_opt;
    if (std::strcmp(id, "perf_nvidia") == 0) return S_perf_nvidia;
    if (std::strcmp(id, "perf_amd") == 0) return S_perf_amd;
    if (std::strcmp(id, "sys_ntfs") == 0) return S_sys_ntfs;
    if (std::strcmp(id, "sys_hibernation") == 0) return S_sys_hibernation;
    if (std::strcmp(id, "sys_power_plan") == 0) return S_sys_power_plan;
    if (std::strcmp(id, "sys_kbm") == 0) return S_sys_kbm;
    if (std::strcmp(id, "sys_xhci_imod") == 0) return S_sys_xhci_imod;
    if (std::strcmp(id, "sys_network") == 0) return S_sys_network;
    if (std::strcmp(id, "sys_device_manager") == 0) return S_sys_device_manager;
    if (std::strcmp(id, "sys_unused_drivers") == 0) return S_sys_unused_drivers;
    if (std::strcmp(id, "priv_telemetry") == 0) return S_priv_telemetry;
    if (std::strcmp(id, "priv_windows_privacy") == 0) return S_priv_windows_privacy;
    if (std::strcmp(id, "priv_tailored") == 0) return S_priv_tailored;
    if (std::strcmp(id, "priv_shared") == 0) return S_priv_shared;
    if (std::strcmp(id, "priv_sync") == 0) return S_priv_sync;
    if (std::strcmp(id, "priv_insider") == 0) return S_priv_insider;
    if (std::strcmp(id, "priv_ads") == 0) return S_priv_ads;
    if (std::strcmp(id, "debloat_apps") == 0) return S_debloat_apps;
    if (std::strcmp(id, "debloat_onedrive") == 0) return S_debloat_onedrive;
    if (std::strcmp(id, "debloat_outlook") == 0) return S_debloat_outlook;
    if (std::strcmp(id, "debloat_ai") == 0) return S_debloat_ai;
    if (std::strcmp(id, "debloat_startup") == 0) return S_debloat_startup;
    if (std::strcmp(id, "debloat_services") == 0) return S_debloat_services;
    if (std::strcmp(id, "app_chrome") == 0) return S_app_chrome;
    if (std::strcmp(id, "app_brave") == 0) return S_app_brave;
    if (std::strcmp(id, "app_edge") == 0) return S_app_edge;
    if (std::strcmp(id, "app_firefox") == 0) return S_app_firefox;
    if (std::strcmp(id, "app_discord") == 0) return S_app_discord;
    if (std::strcmp(id, "app_tiktok") == 0) return S_app_tiktok;
    if (std::strcmp(id, "sec_hardening") == 0) return S_sec_hardening;
    if (std::strcmp(id, "sec_updates") == 0) return S_sec_updates;
    if (std::strcmp(id, "sec_mitigations") == 0) return S_sec_mitigations;
    if (std::strcmp(id, "sec_uac") == 0) return S_sec_uac;
    if (std::strcmp(id, "cust_win11") == 0) return S_cust_win11;
    if (std::strcmp(id, "cust_notifications") == 0) return S_cust_notifications;
    if (std::strcmp(id, "cust_branding") == 0) return S_cust_branding;
    if (std::strcmp(id, "cust_ti_menu") == 0) return S_cust_ti_menu;
    if (std::strcmp(id, "debloat_edge") == 0) return S_debloat_edge;
    if (std::strcmp(id, "sec_defender_delete") == 0) return S_sec_defender_delete;
    if (std::strcmp(id, "sys_print_spooler") == 0) return S_sys_print_spooler;
    if (std::strcmp(id, "sys_bluetooth") == 0) return S_sys_bluetooth;
    if (std::strcmp(id, "debloat_pchealth") == 0) return S_debloat_pchealth;
    if (std::strcmp(id, "sec_firewall") == 0) return S_sec_firewall;
    if (std::strcmp(id, "debloat_xbox") == 0) return S_debloat_xbox;
    return nullptr;
}

}
