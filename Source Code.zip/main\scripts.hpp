#pragma once

namespace nvrx {

const char* tweak_script(const char* id);

}
