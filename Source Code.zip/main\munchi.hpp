#pragma once
#include "imgui.h"
#include <unordered_map>
#include <vector>
#include <string>
#include <algorithm>
#include <cmath>
#include <cstdio>

namespace munchi {

inline ImVec4 col_bg()        { return ImVec4(0.031f, 0.031f, 0.031f, 1.00f); }
inline ImVec4 col_bar()       { return ImVec4(0.051f, 0.051f, 0.051f, 1.00f); }
inline ImVec4 col_card()      { return ImVec4(0.063f, 0.063f, 0.063f, 1.00f); }
inline ImVec4 col_elevated()  { return ImVec4(0.102f, 0.102f, 0.102f, 1.00f); }
inline ImVec4 col_surface()   { return ImVec4(0.078f, 0.078f, 0.078f, 1.00f); }
inline ImVec4 col_detail()    { return ImVec4(0.047f, 0.047f, 0.047f, 1.00f); }
inline ImVec4 col_border()    { return ImVec4(0.149f, 0.149f, 0.149f, 1.00f); }
inline ImVec4 col_text()      { return ImVec4(0.930f, 0.930f, 0.930f, 1.00f); }
inline ImVec4 col_text_dim()  { return ImVec4(0.604f, 0.604f, 0.604f, 1.00f); }
inline ImVec4 col_text_faint(){ return ImVec4(0.361f, 0.361f, 0.361f, 1.00f); }
inline ImVec4 col_accent()    { return ImVec4(0.910f, 0.910f, 0.910f, 1.00f); }
inline ImVec4 col_accent_hi() { return ImVec4(1.000f, 1.000f, 1.000f, 1.00f); }
inline ImVec4 col_on_accent() { return ImVec4(0.031f, 0.031f, 0.031f, 1.00f); }
inline ImVec4 col_ok()        { return ImVec4(0.930f, 0.930f, 0.930f, 1.00f); }
inline ImVec4 col_warn()      { return ImVec4(0.604f, 0.604f, 0.604f, 1.00f); }
inline ImVec4 col_err()       { return ImVec4(1.000f, 1.000f, 1.000f, 1.00f); }
inline ImVec4 col_info()      { return ImVec4(0.800f, 0.800f, 0.800f, 1.00f); }

inline float dt() {
    const float d = ImGui::GetIO().DeltaTime;
    return d > 1e-4f ? d : 1e-4f;
}

inline void ease_to(float& v, float target, float speed) {
    float k = dt() * speed;
    if (k > 1.0f) k = 1.0f;
    v += (target - v) * k;
}
inline void ease_to(ImVec4& v, const ImVec4& target, float speed) {
    float k = dt() * speed;
    if (k > 1.0f) k = 1.0f;
    v.x += (target.x - v.x) * k;
    v.y += (target.y - v.y) * k;
    v.z += (target.z - v.z) * k;
    v.w += (target.w - v.w) * k;
}
inline float quint_in(float t) { return t * t * t * t * t; }
inline float quint_out(float t) {
    const float u = 1.0f - t;
    return 1.0f - u * u * u * u * u;
}

struct ButtonAnim { float hover = 0.0f, active = 0.0f, enter = -1.0f; };
struct CheckAnim { float hover = 0.0f, active = 0.0f, slow = 0.0f, held = 1.0f; };
struct TabAnim { float alpha = 0.0f; ImVec4 text{ 0.6f, 0.6f, 0.6f, 1.0f }; };

inline std::unordered_map<ImGuiID, ButtonAnim>& button_anims() {
    static std::unordered_map<ImGuiID, ButtonAnim> m;
    return m;
}
inline std::unordered_map<ImGuiID, CheckAnim>& check_anims() {
    static std::unordered_map<ImGuiID, CheckAnim> m;
    return m;
}
inline std::unordered_map<ImGuiID, TabAnim>& tab_anims() {
    static std::unordered_map<ImGuiID, TabAnim> m;
    return m;
}

inline void shadow_rect(ImDrawList* dl, const ImVec2& mn, const ImVec2& mx,
                        float rounding, float strength = 1.0f, int layers = 4, float blur = 15.0f) {
    for (int s = 0; s < layers; ++s) {
        const float p = (float)s / (float)layers;
        const float a = (1.0f - p) * 0.15f * strength;
        const float b = blur * p;
        dl->AddRectFilled(ImVec2(mn.x - b, mn.y - b), ImVec2(mx.x + b, mx.y + b),
                          IM_COL32(0, 0, 0, (int)(a * 255.0f)), rounding + b);
    }
}

inline void glow_dot(ImDrawList* dl, const ImVec2& c, float radius, ImU32 col, int layers = 10) {
    for (int i = layers; i > 0; --i) {
        const float p = (float)i / (float)layers;
        const float r = radius * p;
        const int a = (int)(((col >> IM_COL32_A_SHIFT) & 255) * (1.0f - p) * (1.0f - p));
        dl->AddCircleFilled(c, r, (col & ~IM_COL32_A_MASK) | ((ImU32)a << IM_COL32_A_SHIFT), 32);
    }
}

inline void ambience(ImDrawList* dl, const ImVec2& mn, const ImVec2& mx) {
    glow_dot(dl, ImVec2(mx.x - 70.0f, mn.y + 110.0f), 260.0f, IM_COL32(210, 210, 210, 6));
    glow_dot(dl, ImVec2(mn.x + 110.0f, mx.y - 90.0f), 210.0f, IM_COL32(210, 210, 210, 4));
}

inline void backdrop(ImDrawList* dl, const ImVec2& mn, const ImVec2& mx) {
    const float step = 26.0f;
    const ImU32 dot = IM_COL32(255, 255, 255, 9);
    for (float y = mn.y + 14.0f; y < mx.y - 6.0f; y += step)
        for (float x = mn.x + 14.0f; x < mx.x - 6.0f; x += step)
            dl->AddCircleFilled(ImVec2(x, y), 1.0f, dot);
    glow_dot(dl, ImVec2(mx.x - 90.0f, mn.y + 130.0f), 190.0f, IM_COL32(210, 210, 210, 12));
    glow_dot(dl, ImVec2(mn.x + 130.0f, mx.y - 110.0f), 150.0f, IM_COL32(210, 210, 210, 8));
}

inline bool m_button(const char* id, const char* label, const ImVec2& size,
                     ImFont* font, float fsize, bool accent = false, bool enabled = true) {
    ImGui::InvisibleButton(id, size);
    const ImGuiID iid = ImGui::GetItemID();
    const bool hovered = enabled && ImGui::IsItemHovered();
    const bool held = enabled && ImGui::IsItemActive();
    const bool clicked = enabled && ImGui::IsItemClicked(ImGuiMouseButton_Left);

    ButtonAnim& an = button_anims()[iid];
    ease_to(an.hover, hovered ? 1.0f : 0.0f, 20.0f);
    ease_to(an.active, held ? 1.0f : 0.0f, 20.0f);

    ImVec2 mn = ImGui::GetItemRectMin(), mx = ImGui::GetItemRectMax();
    const float shrink = size.x * 0.06f * an.active;
    mn.x += shrink * 0.5f;
    mx.x -= shrink * 0.5f;

    ImDrawList* dl = ImGui::GetWindowDrawList();
    const float rounding = 6.0f;
    shadow_rect(dl, mn, mx, rounding, 0.5f + 0.25f * an.hover);

    ImVec4 base = accent ? col_accent() : col_surface();
    if (!enabled) {
        base.w *= 0.35f;
    } else if (an.hover > 0.0f) {
        const ImVec4 hov = accent ? col_accent_hi() : col_elevated();
        base.x += (hov.x - base.x) * an.hover;
        base.y += (hov.y - base.y) * an.hover;
        base.z += (hov.z - base.z) * an.hover;
    }
    dl->AddRectFilled(mn, mx, ImGui::ColorConvertFloat4ToU32(base), rounding);
    dl->AddLine(ImVec2(mn.x + rounding, mn.y + 1.0f), ImVec2(mx.x - rounding, mn.y + 1.0f),
                accent ? IM_COL32(255, 255, 255, 70) : IM_COL32(255, 255, 255, 16), 1.0f);
    dl->AddRect(mn, mx, IM_COL32(0, 0, 0, 70), rounding);

    const ImVec2 ts = font->CalcTextSizeA(fsize, FLT_MAX, 0.0f, label);
    const ImVec2 tp(mn.x + (mx.x - mn.x - ts.x) * 0.5f, mn.y + (mx.y - mn.y - ts.y) * 0.5f);
    if (accent) {
        ImVec4 tc = col_on_accent();
        if (!enabled) tc.w *= 0.5f;
        dl->AddText(font, fsize, tp, ImGui::ColorConvertFloat4ToU32(tc), label);
    } else {

        ImVec4 tc = col_text_dim();
        tc.x += (col_text().x - tc.x) * an.hover;
        tc.y += (col_text().y - tc.y) * an.hover;
        tc.z += (col_text().z - tc.z) * an.hover;
        if (!enabled) tc.w *= 0.4f;
        dl->AddText(font, fsize, tp, ImGui::ColorConvertFloat4ToU32(tc), label);
        ImVec4 pc = col_accent();
        pc.w *= an.active;
        if (pc.w > 0.01f)
            dl->AddText(font, fsize, tp, ImGui::ColorConvertFloat4ToU32(pc), label);
    }
    return clicked;
}

inline void m_checkbox(const char* id, const char* label, bool* v, ImFont* font, float fsize) {
    const float box = 19.0f, gap = 10.0f;
    const ImVec2 ts = font->CalcTextSizeA(fsize, FLT_MAX, 0.0f, label);
    const ImVec2 size(box + gap + ts.x + 10.0f, box);
    ImGui::InvisibleButton(id, size);
    const ImGuiID iid = ImGui::GetItemID();
    const bool hovered = ImGui::IsItemHovered();
    const bool down = ImGui::IsItemActive();
    if (hovered && ImGui::IsMouseClicked(ImGuiMouseButton_Left))
        *v = !*v;

    CheckAnim& an = check_anims()[iid];
    ease_to(an.hover, (hovered || *v) ? 1.0f : 0.0f, 20.0f);
    ease_to(an.active, *v ? 1.0f : 0.0f, 20.0f);
    ease_to(an.slow, *v ? 1.0f : 0.0f, 10.0f);
    ease_to(an.held, (hovered && down) ? 0.0f : 1.0f, 8.0f);

    ImVec2 mn = ImGui::GetItemRectMin();
    ImVec2 bx0 = mn, bx1 = ImVec2(mn.x + box, mn.y + box);
    ImDrawList* dl = ImGui::GetWindowDrawList();

    shadow_rect(dl, bx0, bx1, 4.0f, 0.5f + 0.2f * an.hover);
    dl->AddRectFilled(ImVec2(bx0.x + 1, bx0.y + 1), bx1,
                      ImGui::ColorConvertFloat4ToU32(col_detail()), 4.0f);
    dl->AddRectFilled(bx0, bx1, ImGui::ColorConvertFloat4ToU32(col_surface()), 4.0f);
    dl->AddRect(bx0, bx1, IM_COL32(0, 0, 0, 77), 4.0f);

    if (an.held < 0.99f) {
        const ImVec2 c((bx0.x + bx1.x) * 0.5f, (bx0.y + bx1.y) * 0.5f);
        const ImVec2 h0(c.x - box * 0.5f * an.held, c.y - box * 0.5f * an.held);
        const ImVec2 h1(c.x + box * 0.5f * an.held, c.y + box * 0.5f * an.held);
        ImVec4 hc(0.039f, 0.039f, 0.055f, 1.0f - an.held);
        dl->AddRectFilled(h0, h1, ImGui::ColorConvertFloat4ToU32(hc), 4.0f);
    }

    if (an.active > 0.01f) {
        const float q = *v ? quint_in(an.active) : quint_out(an.active);
        const ImVec2 c((bx0.x + bx1.x) * 0.5f, (bx0.y + bx1.y) * 0.5f);
        const ImVec2 f0(c.x - box * 0.5f * q, c.y - box * 0.5f * q);
        const ImVec2 f1(c.x + box * 0.5f * q, c.y + box * 0.5f * q);
        ImVec4 fc = col_accent();
        fc.w *= q;
        dl->AddRectFilled(f0, f1, ImGui::ColorConvertFloat4ToU32(fc), 4.0f * (5.0f * (1.0f - q) + 1.0f) / 6.0f + 1.0f);
    }

    if (an.slow > 0.01f) {
        const float q = *v ? quint_in(an.slow) : quint_out(an.slow);
        const float total = 14.0f * (*v ? quint_in(an.active) : (1.0f - quint_out(1.0f - an.active)));
        const ImVec2 c((bx0.x + bx1.x) * 0.5f, (bx0.y + bx1.y) * 0.5f);
        const float cw = total * 0.85f, ch = total * 0.70f;
        const ImVec2 p1(roundf(c.x - cw * 0.35f), roundf(c.y - ch * 0.05f));
        const ImVec2 p2(roundf(c.x - cw * 0.05f), roundf(c.y + ch * 0.35f));
        const ImVec2 p3(roundf(c.x + cw * 0.45f), roundf(c.y - ch * 0.50f));
        ImVec4 cc = col_on_accent();
        cc.w *= q;
        dl->PathLineTo(p1);
        dl->PathLineTo(p2);
        dl->PathLineTo(p3);
        dl->PathStroke(ImGui::ColorConvertFloat4ToU32(cc), ImDrawFlags_None, 2.5f);
    }

    const float slide = gap + roundf((gap * 0.5f) * an.hover);
    const ImVec2 tp(bx1.x + slide, bx0.y + (box - ts.y) * 0.5f);
    const float tq = *v ? quint_in(an.active) : quint_out(an.active);
    ImVec4 dim = col_text_dim();
    dim.w *= 1.0f - tq;
    if (dim.w > 0.01f) dl->AddText(font, fsize, tp, ImGui::ColorConvertFloat4ToU32(dim), label);
    ImVec4 lit = col_text();
    lit.w *= tq;
    if (lit.w > 0.01f) dl->AddText(font, fsize, tp, ImGui::ColorConvertFloat4ToU32(lit), label);
    if (tq <= 0.01f && dim.w <= 0.01f)
        dl->AddText(font, fsize, tp, ImGui::ColorConvertFloat4ToU32(col_text_dim()), label);
}

inline bool m_tab(const char* id, const char* label, bool active, ImFont* font, float fsize, float width) {
    const ImVec2 size(width, 36.0f);
    ImGui::InvisibleButton(id, size);
    const ImGuiID iid = ImGui::GetItemID();
    const bool hovered = ImGui::IsItemHovered();
    const bool clicked = ImGui::IsItemClicked(ImGuiMouseButton_Left);

    TabAnim& an = tab_anims()[iid];
    ease_to(an.alpha, active ? 1.0f : 0.0f, 8.0f);
    ease_to(an.text, active ? ImVec4(1, 1, 1, 1) : ImVec4(0.6f, 0.6f, 0.6f, 1.0f), 16.0f);

    ImVec2 mn = ImGui::GetItemRectMin(), mx = ImGui::GetItemRectMax();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    if (an.alpha > 0.01f) {
        ImVec4 bg = col_accent();
        bg.w *= 0.16f * an.alpha;
        dl->AddRectFilled(mn, mx, ImGui::ColorConvertFloat4ToU32(bg), 8.0f);
    } else if (hovered) {
        dl->AddRectFilled(mn, mx, IM_COL32(255, 255, 255, 10), 8.0f);
    }

    if (active) {
        dl->AddRectFilled(ImVec2(mn.x + 1, mn.y + 12), ImVec2(mn.x + 4, mx.y - 12),
                          ImGui::ColorConvertFloat4ToU32(col_text()), 1.5f);
    }

    const ImVec2 ts = font->CalcTextSizeA(fsize, FLT_MAX, 0.0f, label);
    dl->AddText(font, fsize, ImVec2(mn.x + (size.x - ts.x) * 0.5f, mn.y + (size.y - ts.y) * 0.5f),
                ImGui::ColorConvertFloat4ToU32(an.text), label);
    return clicked;
}

inline bool m_card_begin(const char* id, const ImVec2& size, const char* title, ImFont* fsmall, float small_size) {
    ImVec2 cur = ImGui::GetCursorScreenPos();
    shadow_rect(ImGui::GetWindowDrawList(), cur, ImVec2(cur.x + size.x, cur.y + size.y), 10.0f, 0.8f);
    bool r = ImGui::BeginChild(id, size,
                               ImGuiChildFlags_Borders | ImGuiChildFlags_AlwaysUseWindowPadding,
                               ImGuiWindowFlags_NoScrollbar);
    ImVec2 pos = ImGui::GetWindowPos();
    ImVec2 sz = ImGui::GetWindowSize();
    ImGui::SetCursorPos(ImVec2(18, 12));
    ImGui::PushFont(fsmall);
    ImGui::PushStyleColor(ImGuiCol_Text, col_text_faint());
    ImGui::TextUnformatted(title);
    ImGui::PopStyleColor();
    ImGui::PopFont();
    ImGui::GetWindowDrawList()->AddLine(
        ImVec2(pos.x + 1, pos.y + 37), ImVec2(pos.x + sz.x - 1, pos.y + 37),
        ImGui::ColorConvertFloat4ToU32(col_border()), 1.0f);
    ImGui::SetCursorPos(ImVec2(18, 48));
    return r;
}
inline void m_card_end() { ImGui::EndChild(); }

inline float m_panel_hover(float rounding = 10.0f, bool enabled = true) {
    ButtonAnim& an = button_anims()[ImGui::GetID("##phov")];
    const bool hov = enabled && ImGui::IsWindowHovered(ImGuiHoveredFlags_ChildWindows);
    const float now = (float)ImGui::GetTime();
    if (hov && an.enter < 0.0f) an.enter = now;
    if (!hov) an.enter = -1.0f;
    ease_to(an.hover, hov ? 1.0f : 0.0f, 12.0f);
    if (an.hover > 0.01f) {
        const ImVec2 wp = ImGui::GetWindowPos();
        const ImVec2 ws = ImGui::GetWindowSize();
        const ImVec2 mn(wp.x + 1, wp.y + 1), mx(wp.x + ws.x - 1, wp.y + ws.y - 1);
        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImVec4 tint(1.0f, 1.0f, 1.0f, 0.030f * an.hover);
        dl->AddRectFilled(mn, mx, ImGui::ColorConvertFloat4ToU32(tint), rounding);
        ImVec4 bc = col_border();
        const float k = an.hover;
        bc.x += (0.34f - bc.x) * k;
        bc.y += (0.34f - bc.y) * k;
        bc.z += (0.34f - bc.z) * k;
        dl->AddRect(mn, mx, ImGui::ColorConvertFloat4ToU32(bc), rounding);
        dl->AddRect(ImVec2(mn.x - 2, mn.y - 2), ImVec2(mx.x + 2, mx.y + 2),
                    IM_COL32(255, 255, 255, (int)(10.0f * an.hover)), rounding + 2.0f);
    }

    if (an.enter >= 0.0f) {
        const float st = (now - an.enter) / 0.7f;
        if (st < 1.0f) {
            const ImVec2 wp = ImGui::GetWindowPos();
            const ImVec2 ws = ImGui::GetWindowSize();
            const float e = 1.0f - (1.0f - st) * (1.0f - st);
            const float cx = (wp.x - 60.0f) + (ws.x + 120.0f) * e;
            const float a = 0.085f * sinf(st * 3.14159265f);
            ImDrawList* dl = ImGui::GetWindowDrawList();
            dl->PushClipRect(ImVec2(wp.x + 2, wp.y + 2), ImVec2(wp.x + ws.x - 2, wp.y + ws.y - 2), true);
            dl->AddQuadFilled(ImVec2(cx - 35, wp.y - 6), ImVec2(cx + 35, wp.y - 6),
                              ImVec2(cx + 5, wp.y + ws.y + 6), ImVec2(cx - 65, wp.y + ws.y + 6),
                              IM_COL32(255, 255, 255, (int)(a * 255.0f)));
            dl->PopClipRect();
        }
    }
    return an.hover;
}

inline bool m_panel_begin(const char* id, const ImVec2& size) {
    ImVec2 cur = ImGui::GetCursorScreenPos();
    shadow_rect(ImGui::GetWindowDrawList(), cur, ImVec2(cur.x + size.x, cur.y + size.y), 10.0f, 0.8f);
    ImGui::PushStyleColor(ImGuiCol_ChildBg, col_card());
    const bool r = ImGui::BeginChild(id, size,
                                     ImGuiChildFlags_Borders | ImGuiChildFlags_AlwaysUseWindowPadding,
                                     ImGuiWindowFlags_NoScrollbar);

    const ImVec2 wp = ImGui::GetWindowPos();
    const ImVec2 ws = ImGui::GetWindowSize();
    ImGui::GetWindowDrawList()->AddLine(ImVec2(wp.x + 10, wp.y + 1.0f), ImVec2(wp.x + ws.x - 10, wp.y + 1.0f),
                                        IM_COL32(255, 255, 255, 14), 1.0f);
    return r;
}
inline void m_panel_end() { ImGui::EndChild(); ImGui::PopStyleColor(); }

struct SliderAnim { float hover = 0.0f; };
inline std::unordered_map<ImGuiID, SliderAnim>& slider_anims() {
    static std::unordered_map<ImGuiID, SliderAnim> m;
    return m;
}

inline void m_slider(const char* id, const char* label, float* v, float vmin, float vmax,
                     const char* fmt, ImFont* font, float fsize, ImFont* fsmall) {
    char val[64]{};
    snprintf(val, sizeof(val), fmt, (double)*v);
    const ImVec2 vsz = font->CalcTextSizeA(fsize, FLT_MAX, 0.0f, val);
    const float x0 = 18.0f;
    const float x1 = ImGui::GetWindowContentRegionMax().x - 18.0f;

    ImGui::SetCursorPosX(x0);
    const float row_y = ImGui::GetCursorPosY();
    ImGui::PushFont(fsmall);
    ImGui::PushStyleColor(ImGuiCol_Text, col_text_faint());
    ImGui::TextUnformatted(label);
    ImGui::PopStyleColor();
    ImGui::PopFont();
    ImGui::SetCursorPos(ImVec2(x1 - vsz.x, row_y - 2.0f));
    ImGui::PushFont(font);
    ImGui::PushStyleColor(ImGuiCol_Text, col_text());
    ImGui::TextUnformatted(val);
    ImGui::PopStyleColor();
    ImGui::PopFont();

    const float w = x1 - x0;
    ImGui::SetCursorPosX(x0);
    const ImVec2 tsz(w, 22.0f);
    ImGui::InvisibleButton(id, tsz);
    const ImGuiID iid = ImGui::GetItemID();
    const bool hovered = ImGui::IsItemHovered();
    const bool held = ImGui::IsItemActive();
    if ((hovered && ImGui::IsMouseClicked(ImGuiMouseButton_Left)) || held) {
        const float ix0 = ImGui::GetItemRectMin().x;
        const float t = (ImGui::GetIO().MousePos.x - ix0) / w;
        const float clamped = t < 0.0f ? 0.0f : (t > 1.0f ? 1.0f : t);
        *v = vmin + clamped * (vmax - vmin);
        *v = roundf(*v * 10.0f) / 10.0f;
    }

    SliderAnim& an = slider_anims()[iid];
    ease_to(an.hover, (hovered || held) ? 1.0f : 0.0f, 14.0f);

    ImVec2 mn = ImGui::GetItemRectMin();
    const float cy = mn.y + tsz.y * 0.5f;
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(ImVec2(mn.x, cy - 3), ImVec2(mn.x + w, cy + 3),
                      ImGui::ColorConvertFloat4ToU32(col_detail()), 3.0f);
    const float f = (*v - vmin) / (vmax - vmin);
    if (f > 0.0f) {
        dl->AddRectFilled(ImVec2(mn.x, cy - 3), ImVec2(mn.x + w * f, cy + 3),
                          ImGui::ColorConvertFloat4ToU32(col_text()), 3.0f);
        const ImVec2 kc(mn.x + w * f, cy);
        ImVec4 halo = col_text();
        halo.w *= 0.18f;
        dl->AddCircleFilled(kc, 9.0f, ImGui::ColorConvertFloat4ToU32(halo), 20);
        dl->AddCircleFilled(kc, 6.0f, ImGui::ColorConvertFloat4ToU32(col_text()), 20);
        dl->AddCircleFilled(kc, 6.0f, IM_COL32(0, 0, 0, 60), 20);
    } else {
        dl->AddCircleFilled(ImVec2(mn.x, cy), 6.0f, ImGui::ColorConvertFloat4ToU32(col_text_dim()), 20);
    }
    if (an.hover > 0.01f) {
        ImVec4 hc = col_text();
        hc.w *= 0.10f * an.hover;
        dl->AddRectFilled(ImVec2(mn.x, cy - 3), ImVec2(mn.x + w, cy + 3),
                          ImGui::ColorConvertFloat4ToU32(hc), 3.0f);
    }
}

inline void m_progress(float frac, const ImVec2& size, const char* overlay, ImFont* font, float fsize) {
    ImVec2 p0 = ImGui::GetCursorScreenPos();
    ImVec2 p1(p0.x + size.x, p0.y + size.y);
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(p0, p1, ImGui::ColorConvertFloat4ToU32(col_detail()), size.y * 0.5f);
    float f = frac;
    if (f < 0.0f) f = (float)(ImGui::GetTime() * 0.45 - floor(ImGui::GetTime() * 0.45));
    f = f < 0.0f ? 0.0f : (f > 1.0f ? 1.0f : f);
    if (f > 0.0f) {
        ImVec2 f1(p0.x + size.x * f, p1.y);
        dl->AddRectFilled(p0, f1, ImGui::ColorConvertFloat4ToU32(col_accent()), size.y * 0.5f);
        dl->AddCircleFilled(ImVec2(f1.x - 2, (p0.y + p1.y) * 0.5f), 5.0f,
                            ImGui::ColorConvertFloat4ToU32(ImVec4(col_accent().x, col_accent().y, col_accent().z, 0.25f)), 16);
    }
    if (overlay && overlay[0]) {
        const ImVec2 ts = font->CalcTextSizeA(fsize, FLT_MAX, 0.0f, overlay);
        dl->AddText(font, fsize, ImVec2(p0.x + (size.x - ts.x) * 0.5f, p0.y + (size.y - ts.y) * 0.5f),
                    ImGui::ColorConvertFloat4ToU32(col_text()), overlay);
    }
    ImGui::Dummy(size);
}

enum class NotifyType { Success, Warning, Info };

struct Notify {
    std::string title;
    std::string sub;
    NotifyType type = NotifyType::Info;
    float alpha = 0.0f;
    float y = 0.0f;
    float timer = 0.0f;
    bool active = true;
};

inline std::vector<Notify>& notifies() {
    static std::vector<Notify> v;
    return v;
}
inline void notify_add(const std::string& title, NotifyType type, const std::string& sub = {}) {
    auto& v = notifies();
    if (v.size() > 5) v.erase(v.begin());
    v.push_back({ title, sub, type, 0.0f, 0.0f, 0.0f, true });
}

inline void notify_render(ImFont* font, float fsize, ImFont* fsub, const ImVec2& anchor_tr) {
    auto& v = notifies();
    v.erase(std::remove_if(v.begin(), v.end(),
                           [](const Notify& n) { return n.alpha <= 0.002f && !n.active; }),
            v.end());
    ImDrawList* dl = ImGui::GetForegroundDrawList();
    const float w = 320.0f, pad = 12.0f;
    float stack = 0.0f;
    for (auto& n : v) {
        if (n.active) n.timer += dt();
        if (n.timer >= 5.0f) n.active = false;
        ease_to(n.alpha, n.active ? 1.0f : 0.0f, 8.0f);
        if (n.alpha <= 0.002f) continue;
        ease_to(n.y, stack + pad, 12.0f);

        const bool has_sub = !n.sub.empty();
        const float h = has_sub ? 62.0f : 50.0f;
        const float slide = (1.0f - n.alpha) * 90.0f;
        ImVec2 p0(anchor_tr.x - w + slide, anchor_tr.y + n.y);
        ImVec2 p1(p0.x + w, p0.y + h);

        shadow_rect(dl, p0, p1, 10.0f, n.alpha, 6, 12.0f);
        ImVec4 bg(0.063f, 0.063f, 0.063f, 0.84f * n.alpha);
        dl->AddRectFilled(p0, p1, ImGui::ColorConvertFloat4ToU32(bg), 10.0f);
        ImVec4 bd = col_border();
        bd.w *= n.alpha;
        dl->AddRect(p0, p1, ImGui::ColorConvertFloat4ToU32(bd), 10.0f);

        ImVec4 dot_c = (n.type == NotifyType::Warning) ? col_text_dim() : col_text();
        dot_c.w *= n.alpha;
        const ImVec2 dc(p0.x + 22.0f, p0.y + (has_sub ? 21.0f : h * 0.5f));
        ImVec4 halo = dot_c;
        halo.w *= 0.18f;
        dl->AddCircleFilled(dc, 7.0f, ImGui::ColorConvertFloat4ToU32(halo), 20);
        dl->AddCircleFilled(dc, 3.5f, ImGui::ColorConvertFloat4ToU32(dot_c), 20);

        dl->PushClipRect(ImVec2(p0.x + 38, p0.y), ImVec2(p1.x - 12, p1.y), true);
        ImVec4 tx = col_text();
        tx.w *= n.alpha;
        const float ty = has_sub ? p0.y + 12.0f : p0.y + (h - fsize) * 0.5f - 1.0f;
        dl->AddText(font, fsize, ImVec2(p0.x + 38, ty),
                    ImGui::ColorConvertFloat4ToU32(tx), n.title.c_str());
        if (has_sub) {
            ImVec4 sx = col_text_dim();
            sx.w *= n.alpha;
            dl->AddText(fsub, 12.0f, ImVec2(p0.x + 38, ty + fsize + 3.0f),
                        ImGui::ColorConvertFloat4ToU32(sx), n.sub.c_str());
        }
        dl->PopClipRect();
        stack += h + 10.0f;
    }
}

}
