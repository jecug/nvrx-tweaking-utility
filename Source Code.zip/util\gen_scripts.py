#!/usr/bin/env python3
# Generates main/scripts.cpp from Nvrx.bat.
# Every "::<section>" header in Nvrx.bat becomes one embedded batch script,
# keyed by the tweak id it maps to (same table as main/tweaks.cpp).
#
# Regenerations rules:
#   - "if !errorlevel! equ 0" (which needs EnableDelayedExpansion inside a
#     for-loop) is rewritten to "if not errorlevel 1" so no script needs
#     delayed expansion - literal "!" chars in registry/PS lines stay intact.
#   - "timeout /t 1" pacing lines and all bare "pause" waits are dropped
#     (a pause would block the headless staged run forever)
#   - scripts longer than ~12k chars are emitted as several adjacent
#     R"..." literals (MSVC caps a single literal at ~16,384 chars).
import re
import sys
from collections import OrderedDict

MAX_LITERAL = 12000

BAT = r"C:\Users\13\Desktop\jecug\Nvrx Tweaking\Nvrx.bat"
# new tweak batches written as a numbered plain-text checklist; sections headed
# "1. Some Title:" become the same :: sections as Nvrx.bat, and a section whose
# normalized title already exists in Nvrx.bat replaces that script body
WTA = r"C:\Users\13\Desktop\jecug\Nvrx Tweaking\what to add.txt"
OUT = r"C:\Users\13\Desktop\jecug\Nvrx Tweaking\Nvrx PC Tweaking Utility v3.0\main\scripts.cpp"

# section title in Nvrx.bat  ->  tweak id
SECTION_TO_ID = OrderedDict([
    # Performance (10)
    ("Win32Priority",                        "perf_win32priority"),
    ("Optimize MMCSS",                       "perf_mmcss"),
    ("Disable FTH",                          "perf_fth"),
    ("Enable HAGS",                          "perf_hags"),
    ("Disable Gamebar and GameDVR",          "perf_gamebar_dvr"),
    ("Enable FSE",                           "perf_fse"),
    ("Enable GameMode",                      "perf_gamemode"),
    ("Enable Windowed Game Optimizations",   "perf_windowed_opt"),
    ("Nvidia GPU Optimization",              "perf_nvidia"),
    ("AMD GPU Optimization",                 "perf_amd"),
    # System (8)
    ("NTFS Tweaks",                          "sys_ntfs"),
    ("Disable Hibernation",                  "sys_hibernation"),
    ("Import Nvrx Power Plan",               "sys_power_plan"),
    ("Apply KBM Tweaks",                     "sys_kbm"),
    ("Disable xHCI-IMOD",                    "sys_xhci_imod"),
    ("Apply Network Tweaks",                 "sys_network"),
    ("Device Manager Tweaks",                "sys_device_manager"),
    ("Disable Unused Drivers",               "sys_unused_drivers"),
    # Privacy (7)
    ("Disable Windows Telemetry",            "priv_telemetry"),
    ("Windows Privacy Settings",             "priv_windows_privacy"),
    ("Disable Tailored Experiences",         "priv_tailored"),
    ("Disable Shared Experiences",           "priv_shared"),
    ("Disable Microsoft Setting Synchronization", "priv_sync"),
    ("Disable Windows Insider Experiments",  "priv_insider"),
    ("Disable Ads, Tips And Consumer Content", "priv_ads"),
    # Debloat (6)
    ("Delete Unnecessary Apps",              "debloat_apps"),
    ("Delete OneDrive",                      "debloat_onedrive"),
    ("Delete New Outlook For Windows",       "debloat_outlook"),
    ("Remove Windows AI",                    "debloat_ai"),
    ("Disable Startup Apps",                 "debloat_startup"),
    ("Disable Unneeded Services",            "debloat_services"),
    # Apps (6)
    ("Debloat Google Chrome",                "app_chrome"),
    ("Debloat Brave",                        "app_brave"),
    ("Debloat Microsoft Edge",               "app_edge"),
    ("Debloat Mozilla Firefox",              "app_firefox"),
    ("Debloat Discord",                      "app_discord"),
    ("Debloat Tiktok LIVE Studio",           "app_tiktok"),
    # Security (5)
    ("Make Your System more Secure",         "sec_hardening"),
    ("Configure Windows Updates",            "sec_updates"),
    ("Disable Mitigations",                  "sec_mitigations"),
    ("Disable UAC",                          "sec_uac"),
    # Customization (4)
    ("Customize your Windows 11",            "cust_win11"),
    ("Disable Notifications",                "cust_notifications"),
    ("Apply Nvrx Branding",                  "cust_branding"),
    ("Enable Run As TrustedInstaller Context Menu", "cust_ti_menu"),
    # delivered through what to add.txt
    ("Delete Microsoft Edge",                "debloat_edge"),
    ("Delete Microsoft Defender",            "sec_defender_delete"),
    ("Disable Printer/Spooler",              "sys_print_spooler"),
    ("Disable Bluetooth",                    "sys_bluetooth"),
    ("Remove PC Health Check",               "debloat_pchealth"),
    ("Disable Windows Firewall",             "sec_firewall"),
    ("Disable XBOX",                         "debloat_xbox"),
])

# titles consumed elsewhere, must never become their own script:
#   Disable Windows Defender - replaced by the delete-only script
#   Graphics settings - its three GraphicsDrivers dwords are injected
#     into both GPU optimization scripts below
#   Remove Paint 3D context menu entries - injected into Customize your
#     Windows 11 below
#   Improve Branding - injected into Apply Nvrx Branding below
WTA_SKIP = {"Disable Windows Defender", "Graphics settings",
            "Remove Paint 3D context menu entries", "Improve Branding"}

# appended to both GPU scripts (from what to add.txt "Graphics settings")
GPU_LINES = [
    r'reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v MiracastForceDisable /t REG_DWORD /d 1 /f',
    r'reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v HwSchMode /t REG_DWORD /d 2 /f',
    r'reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v EnableRuntimePowerManagement /t REG_DWORD /d 0 /f',
]
# appended to Customize your Windows 11 (from what to add.txt Paint 3D section)
PAINT3D_LINES = [
    r'reg delete "HKLM\SOFTWARE\Classes\SystemFileAssociations\.bmp\Shell\3D Edit" /f',
    r'reg delete "HKLM\SOFTWARE\Classes\SystemFileAssociations\.jpeg\Shell\3D Edit" /f',
    r'reg delete "HKLM\SOFTWARE\Classes\SystemFileAssociations\.jpe\Shell\3D Edit" /f',
    r'reg delete "HKLM\SOFTWARE\Classes\SystemFileAssociations\.jpg\Shell\3D Edit" /f',
    r'reg delete "HKLM\SOFTWARE\Classes\SystemFileAssociations\.png\Shell\3D Edit" /f',
    r'reg delete "HKLM\SOFTWARE\Classes\SystemFileAssociations\.gif\Shell\3D Edit" /f',
    r'reg delete "HKLM\SOFTWARE\Classes\SystemFileAssociations\.tif\Shell\3D Edit" /f',
    r'reg delete "HKLM\SOFTWARE\Classes\SystemFileAssociations\.tiff\Shell\3D Edit" /f',
]
# appended to Apply Nvrx Branding (from what to add.txt "Improve Branding")
BRANDING_LINES = [
    r'reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v EditionSubVersion /t REG_SZ /d "Nvrx Tweaking" /f',
    r'reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v RegisteredOrganization /t REG_SZ /d "Nvrx Tweaking" /f',
    r'reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v RegisteredOwner /t REG_SZ /d "Nvrx Tweaking" /f',
    r'reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v DisplayVersion /t REG_SZ /d "Nvrx Tweaking" /f',
    r'reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation" /v Manufacturer /t REG_SZ /d "Nvrx Tweaking" /f',
    r'reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation" /v Model /t REG_SZ /d "Nvrx Tweaking" /f',
    r'reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation" /v SupportURL /t REG_SZ /d "https://discord.gg/zCkcdZar5w" /f',
]
INJECT_AFTER = {
    "Nvidia GPU Optimization":   GPU_LINES,
    "AMD GPU Optimization":      GPU_LINES,
    "Customize your Windows 11": PAINT3D_LINES,
    "Apply Nvrx Branding":       BRANDING_LINES,
}

WTA_ALIAS = {"Fixed Disable UAC": "Disable UAC"}

ID_TO_TITLE = {tid: title for title, tid in SECTION_TO_ID.items()}

PACING = re.compile(r"^timeout /t 1 /nobreak > NUL$", re.IGNORECASE)
# a bare "pause" inside a section would block the headless staged run forever
PAUSE = re.compile(r"^pause(\s*>.*)?$", re.IGNORECASE)
# curls without any timeout stall the run forever (e.g. the two NVIDIA
# downloads); give them sane connection and transfer limits
CURL_FIX = re.compile(r"^curl -g -L -# (?=\S)", re.IGNORECASE)


def parse_sections(text):
    lines = text.replace("\r\n", "\n").split("\n")
    sections = OrderedDict()
    current = None
    for ln in lines:
        m = re.match(r"^:: (.+?)\s*$", ln)
        if m:
            current = m.group(1)
            if current in sections:
                sys.exit(f"duplicate section header: {current}")
            sections[current] = []
        elif current is not None:
            sections[current].append(ln)
        else:
            continue  # the @echo off / chcp / setlocal head is dropped
    return sections


def parse_wta(text):
    heads = re.compile(r"^\d+\.\s*(.+?):\s*$")
    lines = text.replace("\r\n", "\n").split("\n")
    sections = OrderedDict()
    current = None
    for ln in lines:
        m = heads.match(ln)
        if m:
            current = m.group(1)
            if current in sections:
                sys.exit(f"duplicate what-to-add section: {current}")
            sections[current] = []
        elif current is not None:
            sections[current].append(ln)
    out = OrderedDict()
    for title, body in sections.items():
        while body and body[0].strip() == "":
            body.pop(0)
        while body and body[-1].strip() == "":
            body.pop()
        if body:
            out[title] = body
    return out


# substrings of lines to remove from a section body (source file stays untouched):
#   Disable Unneeded Services - DispBrokerDesktopSvc is the Display Policy
#     Broker; disabling it makes Windows fall back to the default 60Hz
#     monitor mode after every display re-enumeration
DROP_SUBSTR = {
    "Disable Unneeded Services": ["DispBrokerDesktopSvc"],
}

# per-section whole-line fixes; the key is the fully stripped source
# line and a value of False deletes the line while a string replaces
# it wholesale (the body indent is preserved):
#   Debloat Discord - its settings.json powershell command spans six
#     caret-continued quoted lines inside a cmd if-block and cmd
#     cannot parse that shape ("{$j was unexpected at this time"),
#     so it must collapse into one balanced single-line command
DISCORD_SETTINGS_PS = (
    "powershell -NoProfile -Command "
    "\"$p='%APPDATA%\\discord\\settings.json'; "
    "$j=Get-Content -LiteralPath $p -Raw | ConvertFrom-Json; "
    "if(-not $j.PSObject.Properties['settings'])"
    "{$j | Add-Member -NotePropertyName settings "
    "-NotePropertyValue ([pscustomobject]@{})}; "
    "if(-not $j.settings.PSObject.Properties['overlay'])"
    "{$j.settings | Add-Member -NotePropertyName overlay "
    "-NotePropertyValue ([pscustomobject]@{})}; "
    "$j.settings.overlay | Add-Member -NotePropertyName enabled "
    "-NotePropertyValue $false -Force; "
    "$j | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $p "
    "-Encoding UTF8\""
)
REWRITE_LINE = {
    "Debloat Discord": {
        "powershell -NoProfile -Command ^": False,
        "\"$p='%APPDATA%\\discord\\settings.json'; ^": DISCORD_SETTINGS_PS,
        "$j=Get-Content $p -Raw | ConvertFrom-Json; ^": False,
        "if(-not $j.settings){$j | Add-Member settings @{} -Force}; ^": False,
        "if(-not $j.settings.overlay){$j.settings.overlay=@{} }; ^": False,
        "$j.settings.overlay.enabled=$false; ^": False,
        "$j | ConvertTo-Json -Depth 10 | Set-Content $p -Encoding UTF8\"": False,
    },
}


def clean_body(title, raw):
    body = []
    for ln in raw:
        drop = False
        for sub in DROP_SUBSTR.get(title, []):
            if sub.lower() in ln.lower():
                drop = True
                break
        if drop:
            continue
        fixes = REWRITE_LINE.get(title)
        key = ln.strip()
        if fixes is not None and key in fixes:
            fix = fixes[key]
            if fix is False:
                continue
            indent = ln[:len(ln) - len(ln.lstrip())]
            ln = indent + fix
        if PACING.match(ln.strip()):
            continue
        if PAUSE.match(ln.strip()):
            continue
        if CURL_FIX.match(ln.strip()):
            ln = ln[:len(ln) - len(ln.lstrip())] + CURL_FIX.sub(
                "curl -g -L -# --fail --connect-timeout 20 --retry 2 --max-time 120 ",
                ln.strip())
        # delayed-expansion rewrite: works inside for-loops without setlocal
        stripped = ln.strip()
        if stripped == "if !errorlevel! equ 0 (":
            indent = ln[:len(ln) - len(ln.lstrip())]
            ln = indent + "if not errorlevel 1 ("
        body.append(ln.rstrip())
    # trim leading/trailing blank lines
    while body and body[0].strip() == "":
        body.pop(0)
    while body and body[-1].strip() == "":
        body.pop()
    if not body:
        sys.exit(f"section '{title}' has no usable lines")
    return body


def build_script(title, body):
    out = ["@echo off",
           "chcp 65001 >nul 2>&1",
           f"title Nvrx - {title}",
           f"echo [Nvrx] === {title} ==="]
    out.extend(body)
    out.append(f"echo [Nvrx] Done: {title}")
    out.append("exit /b 0")
    return out


def emit_script_literal(script):
    """One or more adjacent raw-string literals forming the script text.
    MSVC truncates a single string literal around 16,384 chars (C2026), so
    scripts longer than MAX_LITERAL are split at line boundaries; adjacent
    literals concatenate to the exact same byte string."""
    parts = [[]]
    size = 0
    for ln in script:
        if size and size + len(ln) + 1 > MAX_LITERAL:
            parts.append([])
            size = 0
        parts[-1].append(ln)
        size += len(ln) + 1
    out = []
    for p in parts:
        body = "".join(ln + "\n" for ln in p)
        out.append('R"NVRXBAT(' + body + ')NVRXBAT"')
    return "\n".join(out) + ";"


def main():
    with open(BAT, "r", encoding="utf-8", errors="replace") as f:
        text = f.read()
    sections = parse_sections(text)

    with open(WTA, "r", encoding="utf-8", errors="replace") as f:
        wta_text = f.read()
    added = parse_wta(wta_text)
    for title, body in added.items():
        target = WTA_ALIAS.get(title, title)
        if target not in SECTION_TO_ID:
            if target in WTA_SKIP:
                continue
            sys.exit(f"what-to-add section not mapped to a tweak id: '{title}'")
        sections[target] = body

    for title in WTA_SKIP:
        sections.pop(title, None)

    seen = set()
    for title in sections:
        if title not in SECTION_TO_ID:
            sys.exit(f"unmapped Nvrx.bat section: '{title}'")
        seen.add(title)
    missing = [t for t in SECTION_TO_ID if t not in seen]
    if missing:
        sys.exit(f"Nvrx.bat sections missing: {missing}")

    ids = [None] * len(SECTION_TO_ID)
    chunks = []
    for title, tid in SECTION_TO_ID.items():
        script = build_script(title, clean_body(title, sections[title])
                              + list(INJECT_AFTER.get(title, [])))
        chunks.append((tid, title, script))

    w = chunks.append
    out = []
    out.append('#include "scripts.hpp"')
    out.append("#include <cstring>")
    out.append("")
    out.append("namespace nvrx {")
    out.append("")
    for tid, title, script in chunks:
        out.append(f"static const char* S_{tid} =")
        out.append(emit_script_literal(script))
        out.append("")
        out.append("")
    out.append("const char* tweak_script(const char* id) {")
    out.append("    if (!id || !*id) return nullptr;")
    for tid, title, script in chunks:
        out.append(f'    if (std::strcmp(id, "{tid}") == 0) return S_{tid};')
    out.append("    return nullptr;")
    out.append("}")
    out.append("")
    out.append("}")

    with open(OUT, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(out))
    print(f"OK: {len(chunks)} scripts -> {OUT}")


if __name__ == "__main__":
    main()
