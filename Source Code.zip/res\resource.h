#pragma once
#define IDI_MAIN       100
#define IDR_PNG_TAB_OVERVIEW 201
#define IDR_PNG_TAB_TWEAKS   202
#define IDR_PNG_CURSOR       206
#define IDR_PNG_GEAR         207
#define IDR_FT_SORA_REG 301
#define IDR_FT_SORA_MED 302
#define IDR_FT_SYMBOL   303
