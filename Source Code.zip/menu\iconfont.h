#pragma once

#include "imgui.h"

#define ICON_CLOSE      "\xef\x80\x8d"  
#define ICON_MINIMIZE   "\xef\x81\xa8"  

#define ICON_APPS       "\xef\x91\xa8"  
#define ICON_MEMORY     "\xef\x8b\x9b"  
#define ICON_SECURITY   "\xef\x8f\xad"  
#define ICON_SHIELD     "\xef\x80\xa3"  
#define ICON_SPEED      "\xef\x98\xa5"  
#define ICON_UPDATE     "\xef\x80\xa1"  
#define ICON_TUNE       "\xef\x87\x9e"  
#define ICON_SETTINGS   "\xef\x87\x9e"  
#define ICON_SEARCH     "\xef\x80\x82"  
#define ICON_STORAGE    "\xef\x87\x80"  
#define ICON_USB        "\xef\x8a\x87"  
#define ICON_WIFI       "\xef\x87\xab"  
#define ICON_BOARD      "\xef\x94\xb8"  
#define ICON_GAMEPAD    "\xef\x91\x9b"  
#define ICON_DASHBOARD  "\xef\x82\x85"  
#define ICON_PALETTE    "\xef\x94\xbf"  
#define ICON_SWEEP      "\xef\x87\xb8"  
#define ICON_GEARS      "\xef\x82\x85"  

namespace UI::Icons
{
    const ImWchar* SymbolRanges();
    const ImWchar* BrandRanges();
}
