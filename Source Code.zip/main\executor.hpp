#pragma once
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <string>
#include <functional>
#include <atomic>

namespace nvrx::exec {

enum Level { L_INFO = 0, L_OK = 1, L_WARN = 2, L_ERR = 3, L_DIM = 4 };
using LogCb = std::function<void(int level, const std::string& line)>;

std::wstring exe_dir();
bool is_admin();

void create_restore_point(LogCb cb);
void reboot_now(LogCb );
void open_folder(const std::wstring& path);

std::string utf8_from_oem(const char* data, size_t len);
std::string utf8_from_wide(const std::wstring& w);

bool run_script(const char* id, const char* script, LogCb cb);

}
